/*
 * Map2d.java
 *
 * @author Dennis Chao
 * @version
 * @created February 2002
 *
 * Maps a group of Populations to a plane based on inter-string distances.
 * First, antigens are placed on a plane such that their distances on the
 * plane reflect their inter-string distances.
 * Next, T cells are arranged around the antigens based on the distances 
 * between T cells and antigens.  Inter-T cell distances are not considered.
 */

package lib;

import java.util.ArrayList;
import sim.*;

public class Map2d {
  private MatchRule _mr;
  private KnuthRandom _random;
  private ArrayList<Antigen> _antigens;    // input points
  private ArrayList<TCell> _tcells;      // input points
  private ArrayList<double[]> _xyAntigens;  // points on plane
  private ArrayList<double[]> _xyTCells;    // points on plane

  public Map2d(MatchRule mr) {
    _mr = mr;
    _random = new KnuthRandom();
    _random.seedRandom(-1);
    _antigens = new ArrayList<Antigen>();
    _tcells = new ArrayList<TCell>();
  }

  public void addAntigen(Antigen p) {
    _antigens.add(p);
  }

  public void addTCell(TCell p) {
    _tcells.add(p);
  }

  public ArrayList<double[]> getXYAntigens() { 
    return _xyAntigens;
  }

  public ArrayList<double[]> getXYTCells() { 
    return _xyTCells;
  }

  static private double sqr(double x) {
    return x*x;
  }

  public void compute() {
    _xyAntigens = new ArrayList<double[]>();
    _xyTCells = new ArrayList<double[]>();
    int maxdist = _mr.getMaxDistance();
    int cutoffdist = _mr.getNegativeCutoff();

    // first arrange epitopes
    int nNumEpitopes = 0;
    ArrayList<TCRString> szEpitopes = new ArrayList<TCRString>();

    // store epitopes
    for (int a=0; a<_antigens.size(); a++) {
      Antigen p1 = (Antigen)_antigens.get(a);
      for (int e=0; e<p1.getStrings().length; e++) {
        boolean bFound = false;
        TCRString s1 = p1.getStrings()[e];
        for (int i=0; i<szEpitopes.size(); i++) {
          TCRString s2 = (TCRString)(szEpitopes.get(i));
          if (_mr.getDistance(s1, s2)==0) {
            bFound=true;
            break;
          }
        }
        if (!bFound) {
          szEpitopes.add(s1);
          nNumEpitopes++;
        }
      }
    }
    double[] ex=new double[nNumEpitopes];
    double[] ey=new double[nNumEpitopes];

    // put first epitope at the origin
    ex[0]=ey[0]=0.0;

    int nearestind[] = new int[2];
    int nearestdist[] = new int[2];

    if (szEpitopes.size()>1) {
      // place second epitope
      ex[1]=_mr.getDistance((TCRString)(szEpitopes.get(0)),(TCRString)(szEpitopes.get(1)));
      ey[1]=0.0;
      
      // initial placement of other epitopes
      for (int i=2; i<szEpitopes.size(); i++) {
        TCRString e = (TCRString)(szEpitopes.get(i));
        for (int j=i-1; j>=0; j--) {
          int d=_mr.getDistance(e,(TCRString)(szEpitopes.get(j)));
          if (d<cutoffdist || j==0) {
            double angle = _random.randomDouble()*2*Math.PI;
            ex[i] = ex[j]+d*Math.cos(angle);
            ey[i] = ey[j]+d*Math.sin(angle);
            break;
          }
        }
      }

      // adjust epitope locations
      final int maxiter = 70;
      for (int iteration=0; iteration<maxiter; iteration++) {
        for (int j=0; j<szEpitopes.size(); j++) {
          TCRString e = (TCRString)(szEpitopes.get(j));
          for (int i=2; i<szEpitopes.size(); i++) {
            if (i!=j) {
              int d=_mr.getDistance(e,(TCRString)(szEpitopes.get(i)));
              double dxy = Math.sqrt(sqr(ex[i]-ex[j])+sqr(ey[i]-ey[j]));
              if (d<cutoffdist*1.5 || (d>=cutoffdist && dxy<cutoffdist*2)) {
                if (dxy>0.0) {
                  double targetx = ex[j] + (ex[i]-ex[j])*d/dxy;
                  double targety = ey[j] + (ey[i]-ey[j])*d/dxy;
                  ex[i] += (targetx-ex[i])*(maxiter-iteration)/(2.0*maxiter);
                  ey[i] += (targety-ey[i])*(maxiter-iteration)/(2.0*maxiter);
                } else {
                  ex[i] += _random.randomDouble();
                  ey[i] += _random.randomDouble();
                }
              }
            }
          }
        }
      }
    }

    // now arrange T cells around antigens
    double[] tx=new double[_tcells.size()];
    double[] ty=new double[_tcells.size()];

    for (int i=0; i<_tcells.size(); i++) {
      TCRString t = ((TCell)_tcells.get(i)).getString();
      for (int j=0; j<szEpitopes.size(); j++) {
        int d=_mr.getDistance(t,(TCRString)(szEpitopes.get(j)));
        if (d<cutoffdist) {
          double angle = _random.randomDouble()*2*Math.PI;
          tx[i] = ex[j]+d*Math.cos(angle);
          ty[i] = ey[j]+d*Math.sin(angle);
          break;
        }
      }
      if (szEpitopes.size()>1) {
        final int maxiter = 70;
        for (int iteration=0; iteration<maxiter; iteration++) {
          for (int j=0; j<szEpitopes.size(); j++) {
            int d=_mr.getDistance(t,(TCRString)(szEpitopes.get(j)));
            double dxy = Math.sqrt(sqr(tx[i]-ex[j])+sqr(ty[i]-ey[j]));
            if (d<cutoffdist || (d>=cutoffdist && dxy<cutoffdist*1.1)) {
              if (dxy>0.0) {
                double targetx = ex[j] + (tx[i]-ex[j])*d/dxy;
                double targety = ey[j] + (ty[i]-ey[j])*d/dxy;
                tx[i] += (targetx-tx[i])*(maxiter-iteration)/(2.0*maxiter);
                ty[i] += (targety-ty[i])*(maxiter-iteration)/(2.0*maxiter);
              } else {
                tx[i] += _random.randomDouble();
                ty[i] += _random.randomDouble();
              }
            }
          }
        }
      }
    }
    System.out.println();
    // center and rescale results
    double xmin=tx[0];
    double ymin=ty[1];
    double xmax=xmin;
    double ymax=ymin;
    for (int a=0; a<_antigens.size(); a++) {
      Antigen antigen = (Antigen)_antigens.get(a);
      double[] xy=new double[antigen.getStrings().length*2];
      for (int e=0; e<antigen.getStrings().length; e++) {
        boolean bFound = false;
        TCRString s1 = antigen.getStrings()[e];
        for (int i=0; i<szEpitopes.size(); i++) {
          TCRString s2 = (TCRString)(szEpitopes.get(i));
          if (_mr.getDistance(s1, s2)==0) {
            xy[e*2+0] = ex[i];
            xy[e*2+1] = ey[i];
            xmin = Math.min(xmin, ex[i]);
            ymin = Math.min(ymin, ey[i]);
            xmax = Math.max(xmax, ex[i]);
            ymax = Math.max(ymax, ey[i]);
            break;
          }
        }
      }
      _xyAntigens.add(xy);
    }
    for (int t=0; t<_tcells.size(); t++) {
      double[] xy=new double[2];
      xy[0] = tx[t];
      xy[1] = ty[t];
      _xyTCells.add(xy);
      xmin = Math.min(xmin, tx[t]);
      ymin = Math.min(ymin, ty[t]);
      xmax = Math.max(xmax, tx[t]);
      ymax = Math.max(ymax, ty[t]);
    }

    for (int i=0; i<_antigens.size(); i++) {
      double[] xy = (double[])(_xyAntigens.get(i));
      for (int e=0; e<xy.length/2; e++) {
	xy[e*2+0] = (xy[e*2+0]-xmin);
	xy[e*2+1] = (xy[e*2+1]-ymin);
      }
    }
    for (int i=0; i<_tcells.size(); i++) {
      double[] xy = (double[])(_xyTCells.get(i));
      xy[0] = (xy[0]-xmin);
      xy[1] = (xy[1]-ymin);
    }
  }

  /*
   * main - a little test program
   */
  public static void main(String[] args) {
    KnuthRandom r = new KnuthRandom();
    r.seedRandom(-1);
    int nAlphabetSize = 4;
    int nTCRLength = 8;
    TCRString mhc = new TCRString(nAlphabetSize, nTCRLength);
    TCRString epitope = new TCRString(nAlphabetSize, nTCRLength);
    TCRString epitope2 = new TCRString(nAlphabetSize, nTCRLength);
    TCRString epitope3 = new TCRString(nAlphabetSize, nTCRLength);
    epitope2.Randomize(r);
    epitope3.Randomize(r);
    ArrayList antigens = new ArrayList();
    MatchRule mr = null;
    //    MatchRule mr = new HammingMatchRule(nAlphabetSize, nTCRLength, 50);
    //    System.out.println(mr.getDistance(epitope, epitope2));

    //    antigens.add(new Antigen("A1", 50, 0.0, 0.0, epitope, mhc));
    //    antigens.add(new Antigen("A2", 50, 0.0, 0.0, epitope, mhc));
    //    antigens.add(new Antigen("A3", 50, 0.0, 0.0, epitope, mhc));

    Map2d m = new Map2d(mr);
    //    for (int i=0; i<antigens.size(); i++)
    //      m.addAntigen((Population)(antigens.get(i)));
    //    m.compute();
  }
}
