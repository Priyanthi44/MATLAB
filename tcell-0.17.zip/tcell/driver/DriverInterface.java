/*
 * DriverInterface.java
 *
 * @author Dennis Chao
 * @version
 * @created Feb 2004
 *
 * Interface for Driver in immune simulation.
 */

package driver;

public interface DriverInterface {
  // called by Driver for every simulation hour
  public void update();
}
