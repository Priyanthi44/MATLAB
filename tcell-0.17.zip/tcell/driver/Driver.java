/*
 * Driver.java
 *
 * @author Dennis Chao
 * @version
 * @created Jan 2002
 *
 * Control loop for immune simulation
 */

package driver;

import java.util.*;
import java.io.*;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

import lib.KnuthRandom;
import lib.Probability;
import sim.*;

public class Driver {
  private MatchRule _mr;
  private int _nAlphabetSize;
  private int _nMHCLength;
  private int _nPeptideLength;
  private Date _date;
  private KnuthRandom _r;
  private long _nRandomSeed;
  private ArrayList<DriverEvent> _eventLog;
  private long _nTimeStep;
  private long _nNumClones;
  private int _nMatchRule;
  //  private long _nMutation;
  private boolean _bChronic;

  private Uninfected _uninfected;
  private ArrayList<Antigen> _antigens;
  private ArrayList<SelfAntigen> _self;
  private ArrayList<TCell> _tcells;
  private DriverInterface view;
  private TCRString[] _szMHC;

  public Driver() {
    _r=null;
    _nRandomSeed=-1;
    _nTimeStep=-1;
    _nMatchRule=0;
    //    _nMutation=-1;
    _mr=null;
    _bChronic=false;
    _eventLog = new ArrayList<DriverEvent>();
    System.out.println("# T cell simulation version " + Constants.VERSIONMAJOR + "." + Constants.VERSIONMINOR + ", Copyright (C) 2005 Dennis L. Chao");
    System.out.println("# This code comes with ABSOLUTELY NO WARRANTY");
    System.out.println("# This is free software, and you are welcome to redistribute it under certain conditions");
    System.out.println("# It has been licensed under the GNU General Public License");
    System.out.println("# see http://www.gnu.org/licenses/licenses.html#GPL for details");
    System.out.println();
    if (Constants.TIMESTEPSPERHOUR * Constants.TIMESTEPMINUTES != 60) {
      System.err.println("ERROR: TIMESTEPMINUTES (" + 
                         Constants.TIMESTEPMINUTES +
                         ") times Constants.TIMESTEPSPERHOUR ("+
                         Constants.TIMESTEPSPERHOUR +
                         ") must equal 60.");
      System.exit(-1);
    }
  }

  public void init() {
    _date = new Date();
    DateFormat fmt = DateFormat.getInstance();
    System.out.println("# Run on " + fmt.format(_date));
    _nTimeStep = 0;
    if (_r==null) {
      _r = new KnuthRandom();
      DriverEvent event = new DriverEvent();
      event.nEventType = DriverEvent.SETRANDOMSEED;
      event.nParam[0] = _nRandomSeed;
      processEvent(event);
    }

    int nNumMHC=Constants.NUMMHC;
    int nNumSelf=Constants.NUMSELF;
    _szMHC = new TCRString[nNumMHC];

    _uninfected = new Uninfected("uninfected", Constants.T_0,
                                 Constants.LAMBDA, Constants.DELTA_T);
    if (_nMatchRule==0) {
      // Hamming
      _nNumClones = 8*(long)Math.pow(10,7);
      _nAlphabetSize = 3;
      _nMHCLength = 32;
      _nPeptideLength = 48;
      _mr = new HammingMatchRule(_nAlphabetSize,
				 _nMHCLength,
				 nNumMHC,
				 _nPeptideLength,
				 nNumSelf,
				 _nNumClones);
    } else if (_nMatchRule==1) {
      // Manhattan
      _nNumClones = 25*(long)Math.pow(10,7);
      _nAlphabetSize = 32;
      _nMHCLength = 4;
      _nPeptideLength = 6;
      _mr = new ManhattanMatchRule(_nAlphabetSize,
                                   _nMHCLength,
                                   nNumMHC,
                                   _nPeptideLength,
                                   nNumSelf,
                                   _nNumClones);
    } else {
      // Xor
      _nNumClones = 25*(long)Math.pow(10,7);
      _nAlphabetSize = 128;
      _nMHCLength = 4;
      _nPeptideLength = 6;
      _mr = new XorMatchRule(_nAlphabetSize,
			     _nMHCLength,
			     nNumMHC,
			     _nPeptideLength,
			     nNumSelf,
			     _nNumClones);
    }

    _antigens = new ArrayList<Antigen>();
    _self = new ArrayList<SelfAntigen>();
    _tcells = new ArrayList<TCell>();
    System.out.println("# " + _mr.getClass());
    System.out.println("# negative cutoff = " + _mr.getNegativeCutoff());
    System.out.println("# positive cutoff = " + _mr.getPositiveCutoff());

    // make random MHC strings
    for (int i=0; i<_szMHC.length; i++) {
      _szMHC[i] = new TCRString(_nAlphabetSize, _nMHCLength);
      _szMHC[i].Randomize(_r);
    }

    // make random self strings and assign MHC to each
    for (int i=0; i<nNumSelf; i++) {
      TCRString s = new TCRString(_nAlphabetSize, _nPeptideLength);
      s.Randomize(_r);
      _self.add(new SelfAntigen("Self"+i, 0, 0.0, 0.0, s, _szMHC[i%_szMHC.length]));
    }
  }

  public long getRandomSeed() { return _nRandomSeed; }
  public KnuthRandom getKnuth() { return _r; }
  public MatchRule getMatchRule() { return _mr; }
  public Date getDate() { return _date; }
  public long getHour() { return _nTimeStep/Constants.TIMESTEPSPERHOUR; }
  public ArrayList getAntigens() { return _antigens; }
  public ArrayList getTCells() { return _tcells; }
  public int getCrossReactivity() { return _mr.getNegativeCutoff(); }
  /*  public double getMutationRate() {
    if (_nMutation<=0)
      return 0.0;
    else
      return 1.0/_nMutation;
      }*/
  public void registerView(DriverInterface d) {
    view = d;
  }

  // if the Controller needs to talk to the Driver...
  public void processEvent(DriverEvent event) {
    DriverEvent e = event.getCopy();
    Antigen epop = null;
    if (e.nPopulationNum>=0)
      epop = (Antigen)_antigens.get(e.nPopulationNum);
    switch (e.nEventType) {
    case DriverEvent.SETRANDOMSEED:
      if (_r!=null) {
        _r = new KnuthRandom();
        _r.seedRandom(e.nParam[0]);
        _nRandomSeed = _r.getSeed();  // just in case seed was -1
        e.nParam[0] = _nRandomSeed;      // just in case seed was -1
        System.out.println("# random seed = " + _nRandomSeed);
      } else {
        _nRandomSeed = e.nParam[0];
        return;
      }
      //      e.population=null;
      break;
    case DriverEvent.SETCHRONIC:
      if (e.nParam[0]==0) {
        _bChronic = false;
        System.out.println("# CTL exhaustion = false");
      } else {
        _bChronic = true;
        System.out.println("# CTL exhaustion = true");
      }
      break;
    case DriverEvent.SETMATCHRULE:
      if (_mr==null)
        _nMatchRule=(int)e.nParam[0];
      else {
        System.err.println("ERROR: Distance match rule set after initialization");
        System.exit(-1);
      }
      break;
    case DriverEvent.CREATEVIRUS:
    case DriverEvent.CREATESLOWVIRUS:
    case DriverEvent.CREATEVACCINE:
    case DriverEvent.CREATENEWVIRUS:
      if (_mr==null)
        init();
      String name = null;
      int nProductionRate=0;
      double nInfectionRate=2.0*Math.pow(10, -7);
      switch (e.nEventType) {
      case DriverEvent.CREATEVIRUS: 
        name=new String("LCMV");
        if (e.nPopulationNum>=0)
          name += ":v"+getHour();
        nProductionRate=100;
        break;
      case DriverEvent.CREATESLOWVIRUS: 
        name=new String("slow_virus");
        nProductionRate=65;
        nInfectionRate=1.0*Math.pow(10, -7);
        break;
      case DriverEvent.CREATEVACCINE: 
        name=new String("vaccine");
        nProductionRate=0; 
        break;
      case DriverEvent.CREATENEWVIRUS: 
        name=new String("Virus");
        nProductionRate=100;
        break;
      }
      System.out.println("# "+name);
      if (e.nPopulationNum<0 || e.nEventType==DriverEvent.CREATENEWVIRUS) {
        int nEpitopes=(int)(e.nParam[1]);
        TCRString[] ags = new TCRString[nEpitopes];
        TCRString[] mhcs = new TCRString[nEpitopes];
        double[] levels = new double[nEpitopes];
        for (int i=0; i<nEpitopes; i++) {
          ags[i] = new TCRString(_nAlphabetSize, _nPeptideLength);
          if (e.nEventType==DriverEvent.CREATENEWVIRUS) {
            mhcs[i] = _szMHC[_r.randomInt(_szMHC.length)];
            ags[i].Randomize(_r);
          } else {
            mhcs[i] = _szMHC[i%(_szMHC.length)];
            if (i>0)
              ags[i].Randomize(_r);
          }
          levels[i] = (e.nParam[2]/100.0)/Math.pow(100,i);
          System.out.println("# epitope: " + ags[i].toString());
          System.out.println("# MHC:     " + mhcs[i].toString());
          System.out.println("# density: " + levels[i]);
        }
        
        double mutation = 0.0;
        if (e.nParam[3]>0) {
          mutation = 1.0/e.nParam[3];
        }
        // LCMV
        Antigen antigen = new Antigen(name, 
                                      e.nParam[0],
                                      nInfectionRate,
                                      nProductionRate,
                                      2.3,                // viral decay rate
                                      0.8,                // infected cell death rate
                                      ags, mhcs, levels,
                                      mutation,
                                      _uninfected,
                                      this);
        _antigens.add(antigen);

        ///////////////////////////
        TCRString es = antigen.getString();
        TCRString ep = antigen.getPeptideStrings()[0];
        int mindist = _mr.getMaxDistance();
        int mindistp = _mr.getMaxDistance();
        for (int i=0; i<_self.size(); i++) {
          TCRString s = ((SelfAntigen)(_self.get(i))).getString();
          int dist = _mr.getDistance(s, es);
          if (dist<mindist) {
            mindist = dist;
            TCRString sp = ((SelfAntigen)(_self.get(i))).getPeptideString();
            mindistp = _mr.getDistance(sp, ep);
          }
        }
        System.out.println("# distance to nearest self peptide: " + mindist + " " + mindistp);
        ///////////////////////////
      } else {
        double mutation = 0.0;
        if (e.nParam[3]>0) {
          mutation = 1.0/e.nParam[3];
        }
        Antigen antigen = new Antigen(name,
                                      e.nParam[0],
                                      epop.getInfectionRate(),
                                      nProductionRate,
                                      epop.getViralDecayRate(),
                                      epop.getInfectedDeathRate(),
                                      epop.getPeptideStrings(),
                                      epop.getMHCStrings(),
                                      epop.getPeptideLevels(),
                                      mutation,
                                      _uninfected,
                                      this);
        _antigens.add(antigen);
      }
      break;
    case DriverEvent.CREATEUSERMUTANTVIRUS:
    case DriverEvent.CREATEMUTANTVIRUS:
      if (_mr==null)
        init();
      if (e.nPopulationNum<0) {
        System.err.println("ERROR: Can not create a variant virus without a reference virus");
        System.exit(-1);
      }
      String variantname = new String(epop.getName());
      if (variantname.indexOf(":v")>=0) {
        variantname += ":v"+getHour();
      } else {
        variantname += ":v"+getHour();
      }
      System.out.println("# "+variantname);
      TCRString[] ags1 = epop.getPeptideStrings();
      TCRString[] mhc1 = epop.getMHCStrings();
      double[] levels1 = epop.getPeptideLevels();
      TCRString[] ags = new TCRString[ags1.length];
      TCRString[] mhcs = new TCRString[ags1.length];
      double[] levels = new double[ags1.length];
      for (int i=0; i<ags1.length; i++) {
        if (i==0) {
          ags[i] = ags1[i];
          mhcs[i] = mhc1[i];
          // change one digit in the epitope
          int l = _mr.getMutationUnit();
          if (l==1) {
            int rdig = _r.randomInt(ags[i].getLength());
            int rval = _r.randomInt(ags[i].getAlphabetSize()-1);
            ags[i].setDigit(rdig, 
                            (byte)((ags[i].getDigit(rdig)+rval+1)%ags[i].getAlphabetSize()));
          } else {
            int rdig = _r.randomInt(ags[i].getLength()/l);
            for (int j=0; j<l; j++) {
              int rval = _r.randomInt(ags[i].getAlphabetSize());
              ags[i].setDigit(rdig*l+j, (byte)rval);
            }
          }
        } else {
          ags[i] = ags1[i];
          mhcs[i] = mhc1[i];
        }
        levels[i] = levels1[i];
        System.out.println("# epitope: " + ags[i].toString());
        System.out.println("# MHC:     " + mhcs[i].toString());
        System.out.println("# density: " + levels[i]);
      }
      double mutation = 0.0;
      if (e.nParam[3]>0) {
        mutation = 1.0/e.nParam[3];
      }
      Antigen antigen = new Antigen(variantname, 
                                    e.nParam[0],
                                    2*Math.pow(10, -7), // infection rate
                                    100,                // production rate
                                    2.3,                // viral decay rate
                                    0.7,                // infected cell death rate
                                    ags, mhcs, levels,
                                    mutation,
                                    _uninfected,
                                    this);
      antigen.setInfectedSize(e.nParam[1]);
      ///////////////////////////
    TCRString es = antigen.getString();
    TCRString ep = antigen.getPeptideStrings()[0];
    int mindist = _mr.getMaxDistance();
    int mindistp = _mr.getMaxDistance();
    for (int i=0; i<_self.size(); i++) {
      TCRString s = ((SelfAntigen)(_self.get(i))).getString();
      int dist = _mr.getDistance(s, es);
      if (dist<mindist) {
        mindist = dist;
        TCRString sp = ((SelfAntigen)(_self.get(i))).getPeptideString();
        mindistp = _mr.getDistance(sp, ep);
      }
    }
    System.out.println("# distance to nearest self peptide: " + mindist + " " + mindistp);
      ///////////////////////////

      if (_tcells.size()>0) {
        ArrayList tcrstrings = TCRGenerator.addAntigen(antigen, 
                                                       _szMHC, _self, _antigens,
                                                       _nNumClones, _mr, _r);
        System.out.print("# ");
        for (int i=0; i<tcrstrings.size(); i++) {
          _tcells.add(new TCell("TCR" + i,
                                10,
                                (TCRString)(tcrstrings.get(i)),
                                _antigens,
                                _tcells,
                                _mr,
                                _bChronic));
          System.out.print(" "+
                           _mr.getDistance((TCRString)tcrstrings.get(i),
                                           ((Antigen)_antigens.get(0)).getString()));
        }
        System.out.println();
      }

      _antigens.add(antigen);
      break;
    case DriverEvent.CREATEHIGHAVIDITYTCELL:
      if (_mr==null)
        init();
      for (int a=0; a<_antigens.size(); a++)
        for (int i=0; i<(((Antigen)_antigens.get(a)).getStrings()).length; i++)
          _tcells.add(new TCell("high_avidity_CTL_to_" +
                                ((Antigen)_antigens.get(a)).getName(),
                                e.nParam[0],
                                _mr.getRandomStringAt(((Antigen)_antigens.get(a)).getStrings()[i],
                                                      _mr.getNegativeCutoff()-30,
                                                      _r), 
                                _antigens,
                                _tcells,
                                _mr,
                                _bChronic));
      break;
    case DriverEvent.CREATELOWAVIDITYTCELL:
      if (_mr==null)
        init();
      for (int a=0; a<_antigens.size(); a++)
        for (int i=0; i<(((Antigen)_antigens.get(a)).getStrings()).length; i++)
          _tcells.add(new TCell("low_avidity_CTL_to_" +
                                ((Antigen)_antigens.get(a)).getName(),
                                e.nParam[0],
                                _mr.getRandomStringAt(((Antigen)_antigens.get(a)).getStrings()[i],
                                                      _mr.getNegativeCutoff()-1,
                                                      _r), 
                                _antigens,
                                _tcells,
                                _mr,
                                _bChronic));
      break;
    case DriverEvent.CREATEALLAVIDITYTCELL:
      if (_mr==null)
        init();
      ArrayList tcrstrings = TCRGenerator.lazyt(_szMHC, _self, _antigens,
                                                _nNumClones, _mr, _r);
      for (int i=0; i<tcrstrings.size(); i++)
        _tcells.add(new TCell("TCR_" + i,
                              e.nParam[0],
                              (TCRString)(tcrstrings.get(i)),
                              _antigens,
                              _tcells,
                              _mr,
                              _bChronic));

      for (int a=0; a<_antigens.size(); a++) {
        for (int en=0; en<((Antigen)_antigens.get(a)).getStrings().length; en++) {
          System.out.print("# ");
          for (int i=0; i<tcrstrings.size(); i++) {
            System.out.print(" "+
                             _mr.getDistance((TCRString)tcrstrings.get(i),
                                             ((Antigen)_antigens.get(a)).getStrings()[en]));
          }
          System.out.println();
          System.out.print("# ");
          for (int i=0; i<tcrstrings.size(); i++) {
            System.out.print(" "+_mr.DistToAffinity(_mr.getDistance((TCRString)tcrstrings.get(i),
                                                                    ((Antigen)_antigens.get(a)).getStrings()[en])));
          }
          System.out.println();
        }
      }
      break;
    case DriverEvent.INJECTVIRUS:
      epop.incVirusSize(e.nParam[0]);
      break;
    case DriverEvent.INJECTTCELL:  
      // NOT IMPLEMENTED
      break;
    case DriverEvent.ANTIBIOTIC:
      epop.setInfectedSize(0);
      epop.setVirusSize(0);
      break;
    }
    e.nTime = getHour();
    _eventLog.add(e);
  }
  
  // if the Controller needs to talk to the Driver...
  public void Save(String filename) {
    try {
      PrintWriter o = new PrintWriter(new BufferedWriter(new FileWriter(filename)));
      for (int i=0; i<_eventLog.size(); i++) {
        DriverEvent e = (DriverEvent)_eventLog.get(i);
        o.println("#"+DriverEvent.szEventName[e.nEventType]);
        o.println(e.nTime);
        for (int j=0; j<e.nParam.length; j++)
          o.println(e.nParam[j]);
        o.println(e.nPopulationNum);
      }
      o.println("#"+DriverEvent.szEventName[DriverEvent.END]);
      o.println(getHour());
      o.println("0\n0\n0\n0\n-1");
      o.close();
    } catch (Exception ex) {
      System.err.println("ERROR: File problem " + ex);
      System.exit(-1);
    }
  }
  
  public void run() {
    if (_mr==null)
      init();
    int[] apermute = new int[0];
    int[] tpermute = new int[0];
    while (true) {
      view.update();
      double aviditysum = 0.0;
      int aviditycount = 0;
      for (int j=0; j<_tcells.size(); j++) {
        TCell p = (TCell)(_tcells.get(j));
        Antigen a = (Antigen)(_antigens.get(0));
        aviditycount += p.getSize();
        aviditysum += (p.getSize() * _mr.getAffinity(p.getString(),
                                                     a.getString()));
      }

      do {
        _nTimeStep++;
        _uninfected.clock(_r);
        if (apermute.length==_antigens.size()) {
          Probability.getPermutation(apermute, _r);
        } else {
          apermute = Probability.getPermutation(_antigens.size(), _r);
        }
        for (int j=0; j<apermute.length; j++) {
          Antigen p = (Antigen)(_antigens.get(apermute[j]));
          p.clock(_r);
        }
        
        if (tpermute.length==_tcells.size()) {
          Probability.getPermutation(tpermute, _r);
        } else {
          tpermute = Probability.getPermutation(_tcells.size(), _r);
        }
        for (int j=0; j<tpermute.length; j++) {
          TCell p = (TCell)(_tcells.get(tpermute[j]));
          p.clock(_r);
        }
      } while ((_nTimeStep%Constants.TIMESTEPSPERHOUR) != 0);
    }
  }

  /*
   * main - a little test program
   */
  public static void main(String[] args) {
    Driver d = new Driver();
    d.run();
  }
}
