/*
 * DriverEvent.java
 *
 * @author Dennis Chao
 * @version
 * @created Feb 2002
 *
 * note: CREATEMUTANTVIRUS is called when a new virus is created by random
 * mutation.  Therefore, CREATEMUTANTVIRUS in savefiles will be ignored.
 * Users should call CREATEUSERMUTANTVIRUS when they want to create a new 
 * mutant virus at a certain time point.
 */

package driver;

import java.util.*;
import java.io.*;

import lib.KnuthRandom;
import sim.*;

public class DriverEvent {
  public int nEventType;
  public long nTime;
  public long[] nParam;
  public static final int NUMPARMS=4;
  public int nPopulationNum;
  public static final int NULL = 0, // no event
    SETRANDOMSEED = 1,              // set random number seed
    SETMATCHRULE = 2,               // set match rule
    SETCHRONIC = 3,                 // set chronic
    CREATEVIRUS = 10,               // create new virus (LCMV?)
    CREATEVACCINE = 11,             // create new vaccine based on virus
    CREATESLOWVIRUS = 12,           // create new slow-growing virus
    CREATENEWVIRUS = 13,            // create new virus
    CREATEUSERMUTANTVIRUS = 14,     // user creates new mutated virus
    CREATEMUTANTVIRUS = 15,         // automatically created new mutated virus
    CREATEHIGHAVIDITYTCELL = 20,    // create high avidity T cell clone
    CREATELOWAVIDITYTCELL = 21,     // create low avidity T cell clone
    CREATEALLAVIDITYTCELL = 22,     // create whole repertoire of T cells
    INJECTVIRUS = 30,               // inject virus into sim
    INJECTTCELL = 31,               // inject T cell into sim
    ANTIBIOTIC = 40,                // clear virus and infected cells
    END = 100;                      // end the simulation
  public static final String[] szEventName = {"",
    "SETRANDOMSEED","SETMATCHRULE","SETCHRONIC",
    "","","","","","",
    "CREATEVIRUS","CREATEVACCINE","CREATESLOWVIRUS","CREATENEWVIRUS",
    "CREATEUSERMUTANTVIRUS","CREATEMUTANTVIRUS","","","","",
    "CREATEHIGHAVIDITYTCELL","CREATELOWAVIDITYTCELL","CREATEALLAVIDITYTCELL","","",
                                              "","","","","",
    "INJECTVIRUS","INJECTTCELL","","","","","","","","",
    "ANTIBIOTIC","","","","","","","","","",  //40-49
    "","","","","","","","","","",
    "","","","","","","","","","",
    "","","","","","","","","","",
    "","","","","","","","","","",
    "","","","","","","","","","",
    "END"};
  
  public DriverEvent() {
    nParam = new long[NUMPARMS];
    nPopulationNum = -1;
  }
  public DriverEvent getCopy() {
    DriverEvent e = new DriverEvent();
    e.nEventType = nEventType;
    e.nTime = nTime;
    for (int i=0; i<nParam.length; i++)
      e.nParam[i] = nParam[i];
    e.nPopulationNum = nPopulationNum;
    return e;
  }
}

/*
Parameters for the event types:

SETRANDOMSEED
nParam[0] = >=0 for seed value, -1 for timer-based seed

SETMATCHRULE
nParam[0] = 0 - Hamming
            1 - modified Manhattan
            2 - xor

SETCHRONIC
nParam[0] = 0 - T cell acute dynamics
            1.. - T cell exhaustion model

CREATEVIRUS,CREATESLOWVIRUS,CREATEVACCINE,CREATENEWVIRUS
nParam[0] = number of virus particles
nParam[1] = number of epitopes
nParam[2] = maximum epitope expression level * 100
nParam[3] = mutation rate

CREATEUSERMUTANTVIRUS,CREATEMUTANTVIRUS
nParam[0] = number of virus particles
nParam[1] = number of infected cells
nParam[3] = mutation rate

CREATEHIGHAVIDITYTCELL
nParam[0] = number of T cells

CREATELOWAVIDITYTCELL
nParam[0] = number of T cells

CREATEALLAVIDITYTCELL
nParam[0] = number of T cells per clone

INJECTVIRUS
nParam[0] = number of virus particles to inject
nPopulation = which virus

INJECTTCELL
nParam[0] = number of T cells to inject
nPopulation = which T cell

ANTIBIOTIC
 */
