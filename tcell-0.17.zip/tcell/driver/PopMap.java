/*
 * PopMap.java
 *
 * @author Dennis Chao
 * @version
 * @created Jan 2002
 *
 * A graph widget that draws a 2d map of Population strings.
 */

package driver;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import sim.Population;
import sim.Antigen;
import sim.TCell;
import sim.MatchRule;
import lib.Map2d;
import lib.KnuthRandom;

class PopMap extends JFrame {
  private PopMapPanel _panelMap;
  private DriverView _d;

  public PopMap(DriverView d) {
    _d = d;
    setTitle("2D antigenic distance map");
    setSize(550,560);
    Container contentPane = getContentPane();
    
    _panelMap = new PopMapPanel(_d);
    contentPane.add(_panelMap, "Center");
  }

  //  public void show() {
  //    super.show();
  //  }

  public void update() {
    _panelMap.update();
  }
}

class PopMapPanel extends JPanel 
  implements MouseListener {
  private ArrayList _antigens;        // Populations
  private ArrayList _antigenColors;
  private ArrayList _tcells;        // Populations
  private ArrayList _tcellColors;
  private ArrayList _xyAntigens;      // stored Population locations for plot
  private ArrayList _xyTCells;      // stored Population locations for plot
  private ArrayList<int[]> _xyPanelTCells; // stored Population locations for plot
  private ArrayList<int[]> _xyPanelAntigens; // stored Population locations for plot
  private double _xyPanelScale;   // scaling factor for plot
  private int _nSelectedPoint;    // point selected by mouse click
  private int _nSelectedType;     // 0 for epitope, 1 for T cell
  private PopInfo _info;          // Population information window
  private DriverView _d;
  private KnuthRandom _random;
  private int _nCrossReactivity;

  public PopMapPanel(DriverView d) {
    _d = d;
    _nCrossReactivity = _d.getCrossReactivity();
    _antigens = new ArrayList();
    _tcells = new ArrayList();
    setBackground(Color.black);
    addPops();
    addMouseListener(this);
    _nSelectedPoint=-1;
    _nSelectedType=-1;
    _random = new KnuthRandom();
    _random.seedRandom(-1);
  }

  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    FontMetrics fm = g.getFontMetrics();
    
    // compute xy-coordinates of populations
    if (_xyPanelAntigens==null) {
      Dimension d = getSize();
      _xyPanelAntigens = new ArrayList<int[]>();
      //      System.out.println("size = " + d.width + "," + d.height);      
      double xscale = (d.width/(double)(_d.getMatchRule()).getMaxDistance())*1.0;
      double yscale = (d.height/(double)(_d.getMatchRule()).getMaxDistance())*1.0;
      xscale = Math.min(xscale,yscale);
      yscale = xscale;
      _xyPanelScale = xscale*2;
      for (int i=0; i<_xyAntigens.size(); i++) {
	int[] xy = new int[((double[])(_xyAntigens.get(i))).length];
	for (int e=0; e<xy.length/2; e++) {
	  xy[e*2+0] = d.width/4+(int)(((double[])(_xyAntigens.get(i)))[e*2]*xscale);
	  xy[e*2+1] = d.height/4+(int)(((double[])(_xyAntigens.get(i)))[e*2+1]*yscale);
	}
	_xyPanelAntigens.add(xy);
      }

      _xyPanelTCells = new ArrayList<int[]>();
      for (int i=0; i<_xyTCells.size(); i++) {
	int[] xy = new int[((double[])(_xyTCells.get(i))).length];
	for (int e=0; e<xy.length/2; e++) {
	  xy[e*2+0] = d.width/4+(int)(((double[])(_xyTCells.get(i)))[e*2]*xscale);
	  xy[e*2+1] = d.height/4+(int)(((double[])(_xyTCells.get(i)))[e*2+1]*yscale);
	  // add noise to T cells if there are many clones
          /*	  if (_pops.size()>4 && 
	      ((Population)_pops.get(i)).getClass()==sim.TCell.class) {  
	    xy[e*2] += (int)(0.75*xscale*(_random.randomDouble()-0.5));
	    xy[e*2+1] += (int)(0.75*yscale*(_random.randomDouble()-0.5));
            }*/
	}
	_xyPanelTCells.add(xy);
      }
    }

    // draw antigens
    for (int j=0; j<_antigenColors.size(); j++) {
      if (j==_nSelectedPoint && _nSelectedType==0)
	g.setColor(Color.white);
      else 
	g.setColor((Color)_antigenColors.get(j));
      Population p = (Population)(_antigens.get(j));

      // draw legend
      g.drawString(p.getName(), 0, fm.getAscent()*(j+1));

      // draw epitopes
      int w;
      if (p.getSize()<=0)
	w=1;
      else {
	w=(int)Math.log(p.getSize())-1;
	if (w<1) w=1;
	if (w>20) w=20;
      }
      int[] xy = (int[])(_xyPanelAntigens.get(j));
      // draw connecting lines for multi-epitope antigens
      for (int e=1; e<xy.length/2; e++)
        g.drawLine(xy[e*2-2], xy[e*2-1], xy[e*2+0], xy[e*2+1]);

      for (int e=0; e<xy.length/2; e++) {
        // plot epitope position
        if (j==_nSelectedPoint && _nSelectedType==0) {
          g.drawRect(xy[e*2+0]-w-2, xy[e*2+1]-w-2, w*2+4, w*2+4);
        }
        g.drawLine(xy[e*2+0]-w, xy[e*2+1]-w, xy[e*2+0]+w, xy[e*2+1]+w);
        g.drawLine(xy[e*2+0]+w, xy[e*2+1]-w, xy[e*2+0]-w, xy[e*2+1]+w);

        // show cross-reactive cutoff
        g.drawOval((int)(xy[e*2+0]-_xyPanelScale*_nCrossReactivity/2),
                   (int)(xy[e*2+1]-_xyPanelScale*_nCrossReactivity/2),
                   (int)(_xyPanelScale*_nCrossReactivity), 
                   (int)(_xyPanelScale*_nCrossReactivity));
        // show iso-distance lines
        if (j==_nSelectedPoint && _nSelectedType==0) {
          int d = (int)Math.pow(10.0, Math.floor(Math.log(_xyPanelScale*
                                                          _nCrossReactivity)/Math.log(10)));
          d /= 10;
          if (d>1) {
            Color c = g.getColor();
            Color c2 = (Color)_antigenColors.get(j);
            g.setColor(new Color(c2.getRed()/3, c2.getGreen()/3, c2.getBlue()/3));
            for (int k=1; k<10 && 2*k*d<_nCrossReactivity; k++) {
              int r = (int)(d*_xyPanelScale*k);
              g.drawOval((int)(xy[e*2+0]-r),
                         (int)(xy[e*2+1]-r),
                         2*r, 2*r);
            }
            g.setColor(c);
          }
        }
      }
    }

    // draw T cells
    for (int j=0; j<_tcellColors.size(); j++) {
      if (j==_nSelectedPoint && _nSelectedType==1)
	g.setColor(Color.white);
      else 
	g.setColor((Color)_tcellColors.get(j));
      Population p = (Population)(_tcells.get(j));

      // draw legend
      g.drawString(p.getName(), 
                   0, fm.getAscent()*(j+1+(_antigens.size())));

      // draw "shape space"
      int w;
      if (p.getSize()<=0)
	w=1;
      else {
	w=(int)Math.log(p.getSize())-1;
	if (w<1) w=1;
	if (w>20) w=20;
      }
      int[] xy = (int[])(_xyPanelTCells.get(j));
      //      if (p.getSize()>0) {
        g.drawOval(xy[0]-w, xy[1]-w, w*2, w*2);
        g.drawOval(xy[0], xy[1], 0, 0);
        if (j==_nSelectedPoint && _nSelectedType==1) {
          g.drawOval(xy[0]-w-2, xy[1]-w-2, w*2+4, w*2+4);
        }
        //      }
    }
  }

  // addPops - gets Population array from DriverView to track
  public void addPops() {
    Map2d m = new Map2d(_d.getMatchRule());
    _antigens = (ArrayList)(_d.getAntigens().clone());
    for (int i=0; i<_antigens.size(); i++)
      m.addAntigen((Antigen)(_antigens.get(i)));
    _tcells = (ArrayList)(_d.getTCells().clone());
    for (int i=0; i<_tcells.size(); i++)
      m.addTCell((TCell)(_tcells.get(i)));
    m.compute();
    _xyAntigens = m.getXYAntigens();
    _xyTCells = m.getXYTCells();
    _xyPanelAntigens = null;
    _xyPanelTCells = null;
    _antigenColors = _d.getAntigenColors();
    _tcellColors = _d.getTCellColors();
  }

  // update - grab current population levels and update graph
  public void update() {
    if (_antigens.size() != _d.getAntigens().size() ||
      _tcells.size() != _d.getTCells().size())    
      addPops();

    repaint();
    if (_info!=null)
      _info.setSelection(_nSelectedPoint,_nSelectedType);
  }

  public void mousePressed(MouseEvent e) {
    int x = e.getX();
    int y = e.getY();
  }

  public void mouseReleased(MouseEvent e) {
  }

  public void mouseClicked(MouseEvent e) {
    int x = e.getX();
    int y = e.getY();
    _nSelectedPoint = 0;
    _nSelectedType = 0;
    int closestdist = 100000;
    for (int i=0; i<_xyPanelAntigens.size(); i++) {
      int[] xy = (int[])(_xyPanelAntigens.get(i));
      for (int j=0; j<xy.length; j+=2) {
	int dist = (x-xy[j+0])*(x-xy[j+0]) + (y-xy[j+1])*(y-xy[j+1]);
	if (dist<closestdist) {
	  closestdist=dist;
	  _nSelectedPoint = i;
          _nSelectedType = 0;
	}
      }
    }
    for (int i=0; i<_xyPanelTCells.size(); i++) {
      int[] xy = (int[])(_xyPanelTCells.get(i));
      int dist = (x-xy[0])*(x-xy[0]) + (y-xy[1])*(y-xy[1]);
      if (dist<closestdist) {
        closestdist=dist;
        _nSelectedPoint = i;
        _nSelectedType = 1;
      }
    }
    //    System.out.println("closest: " + _nSelectedPoint);
    repaint();
    if (_info==null)
      _info = new PopInfo(_d);
    _info.setSelection(_nSelectedPoint,_nSelectedType);
    _info.setVisible(true);
  }

  public void mouseEntered(MouseEvent e) {
    //    System.out.println("mouse entered");
    setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
  }

  public void mouseExited(MouseEvent e) {
    //    System.out.println("mouse exited");
  }
}

class PopInfo extends JFrame 
  implements ActionListener {
  private JButton _buttonClose;
  private JButton _buttonInject;
  private JTextArea _text;
  private DriverView _d;
  private SpinnerNumberModel _popamount;
  private int _nSelected;
  private int _nSelectedType;

  public PopInfo(DriverView d) {
    _d = d;
    _nSelected = -1;
    _nSelectedType = -1;
    setTitle("population info");
    setSize(400,225);
    Container contentPane = getContentPane();
    Panel controlPanel = new Panel();
    controlPanel.setLayout(new FlowLayout());

    // controls
    _popamount = 
      new SpinnerNumberModel(100, 0, 100000, 1);
    controlPanel.add(new JSpinner(_popamount));
    
    // Buttons
    _buttonInject = new JButton("inject");
    _buttonInject.setActionCommand("inject");
    _buttonInject.addActionListener(this);
    _buttonClose = new JButton("close");
    _buttonClose.setActionCommand("ok");
    _buttonClose.addActionListener(this);
    controlPanel.add(_buttonInject);
    controlPanel.add(_buttonClose);

    contentPane.add(controlPanel, "South");
    _text = new JTextArea(30,30);
    _text.setEditable(false);
    contentPane.add(_text, "Center");
    getRootPane().setDefaultButton(_buttonClose);
  }

  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equals("ok")) {
      dispose();
    } else if (e.getActionCommand().equals("inject")) {
      DriverEvent de = new DriverEvent();
      if (_nSelectedType==0)
        de.nEventType = DriverEvent.INJECTVIRUS;
      else
        de.nEventType = DriverEvent.INJECTTCELL;
      de.nPopulationNum = _nSelected;
      de.nParam[0] = _popamount.getNumber().intValue();
      _d.processEvent(de);
      /*      _d.addHelpMessage("Injecting " + de.nParam + " units of " + 
			de.population.getName() + " at hour " +
			_d.getHour() + "\n"); */
      setSelection(_nSelected,_nSelectedType);
      _d.refresh();
    }
  }
  
  public void setSelection(int num, int nType) {
    ArrayList pops = null;
    if (nType==0)
      pops = (ArrayList)(_d.getAntigens());
    else
      pops = (ArrayList)(_d.getTCells());
    
    Population pop = (Population)(pops.get(num));
    _nSelected = num;
    _text.setText("");
    _text.setBackground(Color.black);
    if (pop.getClass()==sim.Antigen.class) {
      _text.setForeground((Color)(_d.getAntigenColors().get(num)));
      _text.append("Antigen #" + num + "\n");
      _text.append(pop.getName() + "\n");
      for (int i=0; i<((Antigen)pop).getStrings().length; i++)
	_text.append(" " + i + ":" + ((Antigen)pop).getStrings()[i] + "\n");
      _text.append(pop.getSize() + " infected cells\n");
    } else {
      _text.setForeground((Color)(_d.getTCellColors().get(num)));
      _text.append("T cell clone #" + num + "\n");
      _text.append(pop.getName() + "\n");
      _text.append(pop.getString() + "\n");
      _text.append(pop.getSize() + " T cells\n");
    }
    if (pop.getClass()==sim.TCell.class) {
      TCell tpop = (TCell)pop;
      _text.append("[" + tpop.getSizeNaive() + " naive, " +
		   tpop.getSizeEffector() + " effector, " +
		   tpop.getSizeMemory() + " memory]\n");
    }
    _text.append("Distances:\n");
    ArrayList antigens = (ArrayList)(_d.getAntigens());             
    for (int i=0; i<antigens.size(); i++) {
      if (i!=num || nType==1) {
        Antigen p = (Antigen)antigens.get(i);
        for (int e=0; e<p.getStrings().length; e++) {
          int d = _d.getMatchRule().getDistance(p.getStrings()[e], 
                                                pop.getString());
          _text.append(""+d);
          if (pop.getClass()==sim.TCell.class)
            if (d<_d.getMatchRule().getNegativeCutoff())
              _text.append("[" + (long)(_d.getMatchRule().DistToAffinity(d)) + "]");
            else
              _text.append("[-]");
          _text.append(" = " + p.getName() + ":" + e + " " + p.getStrings()[e] + "\n");
        }
      }
    }
    repaint();
  }
}
