/*
 * StartScreen.java
 *
 * @author Dennis Chao
 * @version
 * @created September 2003
 *
 * A dialog used by DriverView to get initial parameters from the user.
 */

package driver;

import java.util.ArrayList;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.BorderFactory; 
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import java.text.*;

import sim.*;
import driver.Driver;

class StartScreen extends JDialog
  implements ActionListener,
             ItemListener {
  private SpinnerNumberModel _seed;
  private SpinnerNumberModel _primaryamount;
  private JFormattedTextField _primarymutation;
  private SpinnerNumberModel _secondaryamount;
  private JFormattedTextField _secondarymutation;
  private SpinnerNumberModel _epitopedensity;
  private ArrayList _pops;
  private int _nMetric = 2;
  private int _nNumClones = -1;
  private int _nNumEpitopes = 1;
  private boolean _bTimerSeed = false;
  private int _nPrimaryType = 1;
  private int _nSecondaryType = 1;

  private ButtonGroup SeedButtons;
  private JRadioButton buttonTimerSeed;
  private JRadioButton buttonUserSeed;
  private JSpinner spinnerSeed;
  private JSpinner spinnerDensity;
  private JRadioButton buttonMetricHamming;
  private JRadioButton buttonMetricL1;
  private JRadioButton buttonMetricXor;
  private JRadioButton buttonTCellOneClone;
  private JRadioButton buttonTCellOneBigClone;
  private JRadioButton buttonTCellTwoClones;
  private JRadioButton buttonTCellAllClones;
  private JRadioButton buttonOneEpitope;
  private JRadioButton buttonTwoEpitopes;
  private JRadioButton buttonPrimaryVaccine;
  private JRadioButton buttonPrimaryVirus;
  private JRadioButton buttonPrimarySlowVirus;
  private JSpinner     spinnerPrimary;
  private JSpinner     spinnerPrimaryMutation;
  private JRadioButton buttonSecondaryVaccine;
  private JRadioButton buttonSecondaryVirus;
  private JRadioButton buttonSecondarySlowVirus;
  private JRadioButton buttonSecondaryVariantVirus;
  private JRadioButton buttonSecondaryNewVirus;
  private JSpinner     spinnerSecondary;
  private JSpinner     spinnerSecondaryMutation;
  private JCheckBox    buttonAntibiotic;
  private JCheckBox    buttonReseedRandom;
  private JCheckBox    buttonJTB;
  private JCheckBox    buttonExhaustion;

  public StartScreen(Frame owner, String title, boolean modal) {
    super(owner, true);

    setTitle("Initialize T cell simulation");
    setSize(640,560);
    Container contentPane = getContentPane();
    contentPane.setLayout(new GridLayout(3,3));
    JPanel RandomPanel = new JPanel();
    RandomPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Random number seed"));
    RandomPanel.setLayout(new GridLayout(4,1));
    //    RandomPanel.setLayout(new BoxLayout(RandomPanel,BoxLayout.Y_AXIS));
    buttonTimerSeed = new JRadioButton("Random seed",_bTimerSeed);
    buttonUserSeed = new JRadioButton("Specified seed:",!_bTimerSeed);
    buttonTimerSeed.setActionCommand("timerseed");
    buttonUserSeed.setActionCommand("userseed");
    buttonTimerSeed.addActionListener(this);
    buttonUserSeed.addActionListener(this);
    SeedButtons = new ButtonGroup();
    SeedButtons.add(buttonTimerSeed);
    SeedButtons.add(buttonUserSeed);
    _seed = new SpinnerNumberModel(221659697, 0, 1000000000, 1);
    RandomPanel.add(buttonTimerSeed);
    RandomPanel.add(buttonUserSeed);
    spinnerSeed = new JSpinner(_seed);
    RandomPanel.add(spinnerSeed);
    buttonReseedRandom = new JCheckBox("Reseed generator", false);
    RandomPanel.add(buttonReseedRandom);
    contentPane.add(RandomPanel);

    JPanel MetricPanel = new JPanel();
    MetricPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Distance metric"));
    MetricPanel.setLayout(new BoxLayout(MetricPanel,BoxLayout.Y_AXIS));
    buttonMetricHamming = new JRadioButton("Hamming", _nMetric==0);
    buttonMetricL1 = new JRadioButton("L1'", _nMetric==1);
    buttonMetricXor = new JRadioButton("xor", _nMetric==2);
    ButtonGroup MetricButtons = new ButtonGroup();
    MetricButtons.add(buttonMetricHamming);
    MetricButtons.add(buttonMetricL1);
    MetricButtons.add(buttonMetricXor);
    MetricPanel.add(buttonMetricHamming);
    MetricPanel.add(buttonMetricL1);
    MetricPanel.add(buttonMetricXor);
    buttonMetricHamming.setActionCommand("hamming");
    buttonMetricL1.setActionCommand("l1");
    buttonMetricXor.setActionCommand("xor");
    buttonMetricHamming.addActionListener(this);
    buttonMetricL1.addActionListener(this);
    buttonMetricXor.addActionListener(this);
    contentPane.add(MetricPanel);

    JPanel TCellPanel = new JPanel();
    TCellPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Clones"));
    TCellPanel.setLayout(new BoxLayout(TCellPanel,BoxLayout.Y_AXIS));
    buttonTCellOneClone = new JRadioButton("One clone");
    buttonTCellOneBigClone = new JRadioButton("One big clone");
    buttonTCellTwoClones = new JRadioButton("Two clones");
    buttonTCellAllClones = new JRadioButton("All clones",true);
    ButtonGroup TCellButtons = new ButtonGroup();
    TCellButtons.add(buttonTCellOneClone);
    TCellButtons.add(buttonTCellOneBigClone);
    TCellButtons.add(buttonTCellTwoClones);
    TCellButtons.add(buttonTCellAllClones);
    TCellPanel.add(buttonTCellOneClone);
    TCellPanel.add(buttonTCellOneBigClone);
    TCellPanel.add(buttonTCellTwoClones);
    TCellPanel.add(buttonTCellAllClones);
    buttonTCellOneClone.setActionCommand("oneclone");
    buttonTCellOneBigClone.setActionCommand("onebigclone");
    buttonTCellTwoClones.setActionCommand("twoclones");
    buttonTCellAllClones.setActionCommand("allclones");
    buttonTCellOneClone.addActionListener(this);
    buttonTCellOneBigClone.addActionListener(this);
    buttonTCellTwoClones.addActionListener(this);
    buttonTCellAllClones.addActionListener(this);
    contentPane.add(TCellPanel);

    JPanel EpitopePanel = new JPanel();
    EpitopePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Epitope"));
    EpitopePanel.setLayout(new BoxLayout(EpitopePanel,BoxLayout.Y_AXIS));
    buttonOneEpitope = new JRadioButton("One epitope", (_nNumEpitopes==1));
    buttonTwoEpitopes = new JRadioButton("Two epitopes", (_nNumEpitopes==1));
    ButtonGroup EpitopeButtons = new ButtonGroup();
    EpitopeButtons.add(buttonOneEpitope);
    EpitopeButtons.add(buttonTwoEpitopes);
    EpitopePanel.add(buttonOneEpitope);
    EpitopePanel.add(buttonTwoEpitopes);
    buttonOneEpitope.setActionCommand("oneepitope");
    buttonTwoEpitopes.setActionCommand("twoepitopes");
    buttonOneEpitope.addActionListener(this);
    buttonTwoEpitopes.addActionListener(this);

    EpitopePanel.add(new JLabel("Epitope density:"));
    _epitopedensity = new SpinnerNumberModel(1.0, 0.0, 1.0, 0.05);
    spinnerDensity = new JSpinner(_epitopedensity);
    EpitopePanel.add(spinnerDensity);
    contentPane.add(EpitopePanel);

    JPanel Antigen1Panel = new JPanel();
    Antigen1Panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Primary exposure"));
    //    Antigen1Panel.setLayout(new BoxLayout(Antigen1Panel,BoxLayout.Y_AXIS));
    Antigen1Panel.setLayout(new GridLayout(5,1));
    ButtonGroup Antigen1Buttons = new ButtonGroup();
    JPanel Antigen1AmountPanel = new JPanel();
    Antigen1AmountPanel.setLayout(new BoxLayout(Antigen1AmountPanel,BoxLayout.X_AXIS));
    Antigen1AmountPanel.add(new JLabel("Amount:"));
    _primaryamount = new SpinnerNumberModel(1000, 0, 999999999l, 1);
    spinnerPrimary = new JSpinner(_primaryamount);
    Antigen1AmountPanel.add(spinnerPrimary);
    Antigen1Panel.add(Antigen1AmountPanel);
    buttonPrimaryVaccine = new JRadioButton("Vaccine",_nPrimaryType==0);
    buttonPrimaryVirus = new JRadioButton("Virus",_nPrimaryType==1);
    buttonPrimarySlowVirus = new JRadioButton("Slow virus",_nPrimaryType==2);
    buttonPrimaryVaccine.setActionCommand("primaryvaccine");
    buttonPrimaryVirus.setActionCommand("primaryvirus");
    buttonPrimarySlowVirus.setActionCommand("primaryslowvirus");
    Antigen1Buttons.add(buttonPrimaryVaccine);
    Antigen1Buttons.add(buttonPrimaryVirus);
    Antigen1Buttons.add(buttonPrimarySlowVirus);
    Antigen1Panel.add(buttonPrimaryVaccine);
    Antigen1Panel.add(buttonPrimaryVirus);
    Antigen1Panel.add(buttonPrimarySlowVirus);
    buttonPrimaryVaccine.addActionListener(this);
    buttonPrimaryVirus.addActionListener(this);
    buttonPrimarySlowVirus.addActionListener(this);
    JPanel Antigen1MutatePanel = new JPanel();
    Antigen1MutatePanel.setLayout(new BoxLayout(Antigen1MutatePanel,BoxLayout.X_AXIS));
    Antigen1MutatePanel.add(new JLabel("Mutation:"));
    NumberFormat mutationFormat = NumberFormat.getNumberInstance();
    mutationFormat.setMinimumFractionDigits(8);
    _primarymutation = new JFormattedTextField(mutationFormat);
    _primarymutation.setValue(new Double(0.0));
    _primarymutation.setColumns(8);
    Antigen1MutatePanel.add(_primarymutation);
    Antigen1Panel.add(Antigen1MutatePanel);
    contentPane.add(Antigen1Panel);

    JPanel Antigen2Panel = new JPanel();
    Antigen2Panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Secondary exposure"));
    //    Antigen2Panel.setLayout(new BoxLayout(Antigen2Panel,BoxLayout.Y_AXIS));
    Antigen2Panel.setLayout(new GridLayout(6,1));
    JPanel Antigen2AmountPanel = new JPanel();
    Antigen2AmountPanel.setLayout(new BoxLayout(Antigen2AmountPanel,BoxLayout.X_AXIS));
    Antigen2AmountPanel.add(new JLabel("Amount:"));
    _secondaryamount = new SpinnerNumberModel(0, 0, 999999999l, 1);
    spinnerSecondary = new JSpinner(_secondaryamount);
    Antigen2AmountPanel.add(spinnerSecondary);
    Antigen2Panel.add(Antigen2AmountPanel);
    ButtonGroup Antigen2Buttons = new ButtonGroup();
    buttonSecondaryVaccine = new JRadioButton("Vaccine",_nSecondaryType==0);
    buttonSecondaryVirus = new JRadioButton("Virus",_nSecondaryType==1);
    buttonSecondarySlowVirus = new JRadioButton("Slow virus",_nSecondaryType==2);
    buttonSecondaryNewVirus = new JRadioButton("New virus",_nSecondaryType==3);
    buttonSecondaryVariantVirus = new JRadioButton("Variant virus",_nSecondaryType==4);
    buttonSecondaryVaccine.setActionCommand("secondaryvaccine");
    buttonSecondaryVirus.setActionCommand("secondaryvirus");
    buttonSecondarySlowVirus.setActionCommand("secondaryslowvirus");
    buttonSecondaryNewVirus.setActionCommand("secondarynewvirus");
    buttonSecondaryVariantVirus.setActionCommand("secondaryvariantvirus");
    Antigen2Buttons.add(buttonSecondaryVaccine);
    Antigen2Buttons.add(buttonSecondaryVirus);
    Antigen2Buttons.add(buttonSecondaryNewVirus);
    Antigen2Buttons.add(buttonSecondaryVariantVirus);
    Antigen2Panel.add(buttonSecondaryVaccine);
    Antigen2Panel.add(buttonSecondaryVirus);
    Antigen2Panel.add(buttonSecondaryNewVirus);
    Antigen2Panel.add(buttonSecondaryVariantVirus);
    buttonSecondaryVaccine.addActionListener(this);
    buttonSecondaryVirus.addActionListener(this);
    buttonSecondarySlowVirus.addActionListener(this);
    buttonSecondaryNewVirus.addActionListener(this);
    buttonSecondaryVariantVirus.addActionListener(this);
    JPanel Antigen2MutatePanel = new JPanel();
    Antigen2MutatePanel.setLayout(new BoxLayout(Antigen2MutatePanel,BoxLayout.X_AXIS));
    Antigen2MutatePanel.add(new JLabel("Mutation:"));
    _secondarymutation = new JFormattedTextField(mutationFormat);
    _secondarymutation.setValue(new Double(0.0));
    _secondarymutation.setColumns(8);
    Antigen2MutatePanel.add(_secondarymutation);
    Antigen2Panel.add(Antigen2MutatePanel);
    contentPane.add(Antigen2Panel);

    JPanel AntibioticPanel = new JPanel();
    AntibioticPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Antibiotic"));
    AntibioticPanel.setLayout(new BoxLayout(AntibioticPanel,BoxLayout.Y_AXIS));
    buttonAntibiotic = new JCheckBox("Antibiotic (hour 36)",false);
    AntibioticPanel.add(buttonAntibiotic);
    contentPane.add(AntibioticPanel);

    JPanel FigurePanel = new JPanel();
    FigurePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Reproduce figures"));
    FigurePanel.setLayout(new GridLayout(3,1));
    String[] szFigs = {"",
                       "ICB Fig 2", "ICB Fig 5a", "ICB Fig 5b",
                       "JTB Fig 5", "JTB Fig 6", "JTB Fig 7",
                       "JTB Fig 8a", "JTB Fig 8b", "JTB Fig 9a", "JTB Fig 9b",
                       "Diss Fig 5.7", "Diss Fig 5.8a", "Diss Fig 5.8b",
                       "Diss Fig 5.9a", "Diss Fig 5.9b",
                       "Diss Fig 5.10", "Diss Fig 5.11", 
                       "Diss Fig 5.14a", "Diss Fig 5.14b", 
                       "Diss Fig 6.1a","Diss Fig 6.1b",
                       "Diss Fig 6.1c","Diss Fig 6.1d",
                       "Diss Fig 6.2a","Diss Fig 6.2b","Diss Fig 6.2c",
                       "Diss Fig 6.4a","Diss Fig 6.4b","Diss Fig 6.4c"};
    JComboBox comboFigure = new JComboBox(szFigs);
    comboFigure.setSelectedIndex(0);
    comboFigure.addItemListener(this);
    FigurePanel.add(comboFigure);
    buttonJTB = new JCheckBox("JTB/ICB version",false);
    FigurePanel.add(buttonJTB);
    buttonExhaustion = new JCheckBox("CTL exhaustion",false);
    FigurePanel.add(buttonExhaustion);
    contentPane.add(FigurePanel);

    Panel buttonPanel = new Panel();
    buttonPanel.setLayout(new FlowLayout());
    JButton buttonOK = new JButton("ok");
    buttonOK.setActionCommand("ok");
    buttonOK.addActionListener(this);
    buttonPanel.add(buttonOK);
    contentPane.add(buttonPanel);

    setDefaultCloseOperation(HIDE_ON_CLOSE);
  }

  public long getRandomSeed() {
    if (_bTimerSeed)
      return -1;
    else 
      return _seed.getNumber().intValue();
  }

  public boolean getReseedRandom() {
    return buttonReseedRandom.isSelected();
  }
  public int getMetric() {
    return _nMetric;
  }
  public int getTCellClones() {
    return _nNumClones;
  }
  public int getNumEpitopes() {
    return _nNumEpitopes;
  }
  public double getEpitopeDensity() {
    return _epitopedensity.getNumber().doubleValue();
  }
  public int getPrimaryType() {
    return _nPrimaryType;
  }
  public int getPrimarySize() {
    return _primaryamount.getNumber().intValue();
  }
  public double getPrimaryMutationRate() {
    return ((Number)_primarymutation.getValue()).doubleValue();
  }
  public int getSecondaryType() {
    return _nSecondaryType;
  }
  public int getSecondarySize() {
    return _secondaryamount.getNumber().intValue();
  }
  public double getSecondaryMutationRate() {
    return ((Number)_secondarymutation.getValue()).doubleValue();
  }
  public boolean getAntibiotic() {
    return buttonAntibiotic.isSelected();
  }
  public boolean getJTB() {
    return buttonJTB.isSelected();
  }
  public boolean getExhaustion() {
    return buttonExhaustion.isSelected();
  }

  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equals("hamming"))
      _nMetric = 0;
    else if (e.getActionCommand().equals("l1"))
      _nMetric = 1;
    else if (e.getActionCommand().equals("xor"))
      _nMetric = 2;
    else if (e.getActionCommand().equals("oneclone"))
      _nNumClones = 1;
    else if (e.getActionCommand().equals("onebigclone"))
      _nNumClones = 50000;
    else if (e.getActionCommand().equals("twoclones"))
      _nNumClones = 2;
    else if (e.getActionCommand().equals("allclones"))
      _nNumClones = -1;
    else if (e.getActionCommand().equals("oneepitope"))
      _nNumEpitopes = 1;
    else if (e.getActionCommand().equals("twoepitopes"))
      _nNumEpitopes = 2;
    else if (e.getActionCommand().equals("primaryvaccine"))
      _nPrimaryType=0;
    else if (e.getActionCommand().equals("primaryvirus"))
      _nPrimaryType=1;
    else if (e.getActionCommand().equals("primaryslowvirus"))
      _nPrimaryType=2;
    else if (e.getActionCommand().equals("secondaryvaccine"))
      _nSecondaryType=0;
    else if (e.getActionCommand().equals("secondaryvirus"))
      _nSecondaryType=1;
    else if (e.getActionCommand().equals("secondaryslowvirus"))
      _nSecondaryType=2;
    else if (e.getActionCommand().equals("secondarynewvirus"))
      _nSecondaryType=3;
    else if (e.getActionCommand().equals("secondaryvariantvirus"))
      _nSecondaryType=4;
    else if (e.getActionCommand().equals("timerseed"))
      _bTimerSeed=true;
    else if (e.getActionCommand().equals("userseed"))
      _bTimerSeed=false;
    else if (e.getActionCommand().equals("ok"))
      setVisible(false);
  }

  public void itemStateChanged(ItemEvent e) {
    if (e.getStateChange() == ItemEvent.SELECTED) {
      JComboBox cb = (JComboBox)e.getSource();
      String szName = (String)cb.getSelectedItem();

      if (szName.startsWith("ICB") || 
          szName.startsWith("JTB")) {
        buttonJTB.setSelected(true);
        _primarymutation.setValue(new Double(0.0));
        _secondarymutation.setValue(new Double(0.0));
        spinnerSecondary.setValue(new Long(0));
        buttonAntibiotic.setSelected(false);
        buttonExhaustion.setSelected(false);
      }
      if (szName.startsWith("Diss")) {
        buttonJTB.setSelected(false);
        _primarymutation.setValue(new Double(0.0));
        _secondarymutation.setValue(new Double(0.0));
        spinnerSecondary.setValue(new Long(0));
        buttonAntibiotic.setSelected(false);
        buttonExhaustion.setSelected(false);
      }

      if (szName.equals("ICB Fig 2")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(535523716));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(5000));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(5000));
      } else if (szName.equals("ICB Fig 3")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(535523716));
        buttonReseedRandom.setSelected(false);
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimarySlowVirus.doClick();
        spinnerPrimary.setValue(new Long(5000));
        buttonSecondarySlowVirus.doClick();
        spinnerSecondary.setValue(new Long(5000));
      } else if (szName.equals("ICB Fig 5a")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(535523716));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVaccine.doClick();
        spinnerPrimary.setValue(new Long(2000000));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(5000));
      } else if (szName.equals("ICB Fig 5b")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(535523716));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVaccine.doClick();
        spinnerPrimary.setValue(new Long(40000));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(5000));
      } else if (szName.equals("JTB Fig 5")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(961236256));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellOneClone.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(500));
      } else if (szName.equals("JTB Fig 6")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(961505835));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellTwoClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(500));
      } else if (szName.equals("JTB Fig 7")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(961719184));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(500));
      } else if (szName.equals("JTB Fig 8a")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(962065446));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellOneClone.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(10000));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(0));
        buttonAntibiotic.setSelected(true);
      } else if (szName.equals("JTB Fig 8b")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(962065446));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellOneClone.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(10000));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(0));
      } else if (szName.equals("JTB Fig 9a")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(962353825));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellOneBigClone.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(0));
      } else if (szName.equals("JTB Fig 9b")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(962390062));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellOneClone.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(0));
      } else if (szName.equals("Diss Fig 5.7")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(961236256));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellOneClone.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(500));
      } else if (szName.equals("Diss Fig 5.8a")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(962065449));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellOneClone.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(10000));
        buttonSecondaryVirus.doClick();
        buttonAntibiotic.setSelected(true);
      } else if (szName.equals("Diss Fig 5.8b")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(962065449));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellOneClone.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(10000));
        buttonSecondaryVirus.doClick();
      } else if (szName.equals("Diss Fig 5.9a")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(962353825));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellOneBigClone.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
      } else if (szName.equals("Diss Fig 5.9b")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(962390062));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellOneClone.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
      } else if (szName.equals("Diss Fig 5.10")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(961505835));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellTwoClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(500));
      } else if (szName.equals("Diss Fig 5.11")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(961719184));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(5000));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(5000));
      } else if (szName.equals("Diss Fig 5.14a")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(535523716));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVaccine.doClick();
        spinnerPrimary.setValue(new Long(2000000));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(500));
      } else if (szName.equals("Diss Fig 5.14b")) {
        buttonUserSeed.doClick();
        spinnerSeed.setValue(new Long(535523716));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVaccine.doClick();
        spinnerPrimary.setValue(new Long(40000));
        buttonSecondaryVirus.doClick();
        spinnerSecondary.setValue(new Long(500));
      } else if (szName.equals("Diss Fig 6.1a")) {
        buttonTimerSeed.doClick();
        spinnerSeed.setValue(new Long(229520161));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimarySlowVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        buttonExhaustion.setSelected(true);
      } else if (szName.equals("Diss Fig 6.1b")) {
        buttonTimerSeed.doClick();
        spinnerSeed.setValue(new Long(229088927));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimarySlowVirus.doClick();
        spinnerPrimary.setValue(new Long(10000000));
        buttonSecondaryVirus.doClick();
        buttonExhaustion.setSelected(true);
      } else if (szName.equals("Diss Fig 6.1c")) {
        buttonTimerSeed.doClick();
        spinnerSeed.setValue(new Long(229253551));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        buttonExhaustion.setSelected(true);
      } else if (szName.equals("Diss Fig 6.1d")) {
        buttonTimerSeed.doClick();
        spinnerSeed.setValue(new Long(229083915));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimaryVirus.doClick();
        spinnerPrimary.setValue(new Long(10000000));
        buttonSecondaryVirus.doClick();
        buttonExhaustion.setSelected(true);
      } else if (szName.equals("Diss Fig 6.2a")) {
        buttonTimerSeed.doClick();
        spinnerSeed.setValue(new Long(312409356));
        buttonReseedRandom.setSelected(false);
        buttonMetricHamming.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimarySlowVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        buttonExhaustion.setSelected(true);
        _primarymutation.setValue(new Double(0.00001));
      } else if (szName.equals("Diss Fig 6.2b")) {
        buttonTimerSeed.doClick();
        spinnerSeed.setValue(new Long(312439707));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimarySlowVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        buttonExhaustion.setSelected(true);
        _primarymutation.setValue(new Double(0.00001));
      } else if (szName.equals("Diss Fig 6.2c")) {
        buttonTimerSeed.doClick();
        spinnerSeed.setValue(new Long(312598641));
        buttonReseedRandom.setSelected(false);
        buttonMetricL1.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimarySlowVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        buttonExhaustion.setSelected(true);
        _primarymutation.setValue(new Double(0.00001));
      } else if (szName.equals("Diss Fig 6.4a")) {
        buttonTimerSeed.doClick();
        spinnerSeed.setValue(new Long(824646634));
        buttonReseedRandom.setSelected(false);
        buttonMetricHamming.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimarySlowVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        buttonExhaustion.setSelected(true);
        _primarymutation.setValue(new Double(0.0001));
      } else if (szName.equals("Diss Fig 6.4b")) {
        buttonTimerSeed.doClick();
        spinnerSeed.setValue(new Long(824518154));
        buttonReseedRandom.setSelected(false);
        buttonMetricXor.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimarySlowVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        buttonExhaustion.setSelected(true);
        _primarymutation.setValue(new Double(0.0001));
      } else if (szName.equals("Diss Fig 6.4c")) {
        buttonTimerSeed.doClick();
        spinnerSeed.setValue(new Long(824405275));
        buttonReseedRandom.setSelected(false);
        buttonMetricL1.doClick();
        buttonTCellAllClones.doClick();
        buttonOneEpitope.doClick();
        spinnerDensity.setValue(new Double(1.0));
        buttonPrimarySlowVirus.doClick();
        spinnerPrimary.setValue(new Long(500));
        buttonSecondaryVirus.doClick();
        buttonExhaustion.setSelected(true);
        _primarymutation.setValue(new Double(0.0001));
      }
    }
  }
}
