/*
 * DriverView.java
 *
 * @author Dennis Chao
 * @version
 * @created Jan 2002
 *
 * Graphical interface for Driver in immune simulation.
 */

package driver;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import sim.*;
import driver.StartScreen;

class DriverView extends JFrame 
                 implements ActionListener, DriverInterface {
  private int       _runstate;
  private int RUN = 1,             // run at full speed
    STOP = 2,                      // stop and wait
    STEP = 3;                      // clock one cycle and wait
  private Vector<Vector<Long>> _tcellLevels;     // stored Population sizes for plot
  private Vector<Long> _popLevelsHour;   // stored hours for plot
  private Vector<Vector<Long>> _antigenLevels;   // stored Population sizes for plot
  private long _nPopLevelsMax;     // maximum antigen/T cell level seen so far
  private Driver _d;
  private StartScreen startscreen;
  private boolean _bAntibiotic=false;  // administer antibiotic at hour 36?
  private long _nSecondarySize=0;
  private int  _nSecondaryType=0;
  private double _fSecondaryMutation=0;

  // _bBackwardsCompatible should be set to true to replicate results
  // from the JTB and ICB papers.  This affects only the way in which
  // the secondary infection is instantiated in this class file.  
  // This flag should be set to false otherwise, in part because it
  // will handle mutating pathogens correctly and in part because the
  // old code for creating the secondary infection was kind of dumb.
  private boolean _bBackwardsCompatible = false;

  // UI elements
  private PopGraph  _popGraph;
  private PopMap    _popMap;
  private ArrayList<Color> _antigenColors;// colors to use in _popGraph and _popMap
  private ArrayList<Color> _tcellColors;  // colors to use in _popGraph and _popMap
  private JButton _buttonRun;
  private JLabel  _labelClock;
  private SpinnerNumberModel _watchtime;
  private JSpinner spinnerWatch;

  public DriverView(Driver d) {
    _d = d;
    _d.registerView(this);
    _runstate = STOP;

    // initialize
    startscreen = new StartScreen(this, "start", true);
    startscreen.setVisible(true);

    // seed random number generator
    DriverEvent event = new DriverEvent();
    event.nEventType = DriverEvent.SETRANDOMSEED;
    event.nParam[0] = startscreen.getRandomSeed();
    event.nParam[1] = 0;
    event.nParam[2] = 0;
    event.nParam[3] = 0;
    event.nPopulationNum = -1;
    _d.processEvent(event);

    // match rule
    event.nEventType = DriverEvent.SETMATCHRULE;
    event.nParam[0] = startscreen.getMetric();
    _d.processEvent(event);

    // create primary
    if (startscreen.getPrimaryType()==0) 
      event.nEventType = DriverEvent.CREATEVACCINE;
    else if (startscreen.getPrimaryType()==1) 
      event.nEventType = DriverEvent.CREATEVIRUS;
    else if (startscreen.getPrimaryType()==2) 
      event.nEventType = DriverEvent.CREATESLOWVIRUS;
    event.nPopulationNum = -1;
    event.nParam[0] = startscreen.getPrimarySize();
    event.nParam[1] = startscreen.getNumEpitopes();
    event.nParam[2] = (long)(startscreen.getEpitopeDensity()*100);
    double mutate = startscreen.getPrimaryMutationRate();
    if (mutate==0.0)
      event.nParam[3] = 0;
    else
      event.nParam[3] = (long)(1/mutate);
    _d.processEvent(event);

    _bAntibiotic = startscreen.getAntibiotic();
    _bBackwardsCompatible = startscreen.getJTB();

    // Exhaustion dynamics
    event.nEventType = DriverEvent.SETCHRONIC;
    event.nPopulationNum = -1;
    if (startscreen.getExhaustion())
      event.nParam[0] = 1;
    else
      event.nParam[0] = 0;
    event.nParam[1] = 0;
    event.nParam[2] = 0;
    event.nParam[3] = 0;
    _d.processEvent(event);

    // create T cells
    switch (startscreen.getTCellClones()) {
    case 1:
      event.nEventType = DriverEvent.CREATEHIGHAVIDITYTCELL;
      event.nPopulationNum = -1;
      event.nParam[0] = 50;
      _d.processEvent(event);
      break;
    case 2:
      event.nEventType = DriverEvent.CREATEHIGHAVIDITYTCELL;
      event.nPopulationNum = -1;
      event.nParam[0] = 50;
      _d.processEvent(event);
      event.nEventType = DriverEvent.CREATELOWAVIDITYTCELL;
      event.nParam[0] = 50;
      _d.processEvent(event);
      break;
    case 50000:
      event.nEventType = DriverEvent.CREATEHIGHAVIDITYTCELL;
      event.nPopulationNum = -1;
      event.nParam[0] = 50000;
      _d.processEvent(event);
      break;
    case -1:
      event.nEventType = DriverEvent.CREATEALLAVIDITYTCELL;
      event.nPopulationNum = -1;
      event.nParam[0] = 10;
      _d.processEvent(event);
      break;
    }

    // create secondary
    _nSecondaryType = startscreen.getSecondaryType();
    _nSecondarySize = startscreen.getSecondarySize();  
    _fSecondaryMutation = startscreen.getSecondaryMutationRate();
    
    if (_bBackwardsCompatible) {
      if (startscreen.getSecondaryType()==0)
        event.nEventType = DriverEvent.CREATEVACCINE;
      else if (startscreen.getSecondaryType()==1)
        event.nEventType = DriverEvent.CREATEVIRUS;
      else if (startscreen.getSecondaryType()==2)
        event.nEventType = DriverEvent.CREATESLOWVIRUS;
      else {
        event.nEventType = DriverEvent.CREATEUSERMUTANTVIRUS;
      }
      event.nParam[0] = 0;
      event.nPopulationNum = ((Antigen)(_d.getAntigens().get(0))).getID();
      
      _d.processEvent(event);
    }

    // reseed random number generator
    if (startscreen.getReseedRandom()) {
      event.nPopulationNum = -1;
      event.nEventType = DriverEvent.SETRANDOMSEED;
      event.nParam[0] = -1;
      event.nParam[1] = 0;
      event.nParam[2] = 0;
      event.nParam[3] = 0;
      _d.processEvent(event);
    }

    ArrayList antigens = _d.getAntigens();
    ArrayList tcells = _d.getTCells();
    _tcellLevels = new Vector<Vector<Long>>();
    for (int i=0; i<tcells.size(); i++) 
      _tcellLevels.add(new Vector<Long>());
    _antigenLevels = new Vector<Vector<Long>>();
    for (int i=0; i<antigens.size(); i++) 
      _antigenLevels.add(new Vector<Long>());
    _popLevelsHour = new Vector<Long>();
    //    _nPopLevelsMax = 0;

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
	System.exit(0);
      }
    });
    setTitle("T cell simulation");
    setSize(200,320);
    Container contentPane = getContentPane();
    contentPane.setLayout(new BoxLayout(contentPane,BoxLayout.Y_AXIS));

    // Buttons
    Panel buttonPanel = new Panel();
    buttonPanel.setLayout(new GridLayout(9,1));
    _buttonRun = new JButton("go");
    _buttonRun.setActionCommand("run");
    _buttonRun.setBackground(Color.green);
    _buttonRun.addActionListener(this);

    JButton buttonStep = new JButton("step");
    buttonStep.setActionCommand("step");
    buttonStep.setBackground(Color.yellow);
    buttonStep.addActionListener(this);

    JButton buttonInject = new JButton("Inject");
    buttonInject.setMnemonic(KeyEvent.VK_I); 
    buttonInject.setActionCommand("inject");
    buttonInject.setBackground(Color.white);
    buttonInject.addActionListener(this);

    JButton buttonSave = new JButton("Save");
    buttonSave.setActionCommand("save");
    buttonSave.addActionListener(this);

    JButton buttonGraph = new JButton("Graph");
    buttonGraph.setActionCommand("graph");
    buttonGraph.addActionListener(this);

    JButton buttonMap = new JButton("<html><u>M</u>ap</html>");
    buttonMap.setMnemonic(KeyEvent.VK_M); 
    buttonMap.setActionCommand("map");
    buttonMap.addActionListener(this);

    JButton buttonTextOutput = new JButton("dump output");
    buttonTextOutput.setActionCommand("dump");
    buttonTextOutput.addActionListener(this);

    JButton buttonClose = new JButton("Quit");
    buttonClose.setMnemonic(KeyEvent.VK_ESCAPE);
    buttonClose.setActionCommand("close");
    buttonClose.addActionListener(this);

    buttonPanel.add(_buttonRun);
    buttonPanel.add(buttonStep);
    buttonPanel.add(buttonInject);
    buttonPanel.add(buttonGraph);
    buttonPanel.add(buttonMap);
    buttonPanel.add(buttonTextOutput);
    buttonPanel.add(buttonSave);
    buttonPanel.add(buttonClose);
    contentPane.add(buttonPanel, "West");

    Panel clockPanel = new Panel();
    clockPanel.setLayout(new GridLayout(1,4));
    clockPanel.add(new JLabel("day:"));
    _labelClock = new JLabel("-");
    clockPanel.add(_labelClock);
    buttonPanel.add(clockPanel);
    clockPanel.add(new JLabel("break:"));
    _watchtime = new SpinnerNumberModel(50, 0, 10000, 1);
    spinnerWatch = new JSpinner(_watchtime);
    clockPanel.add(spinnerWatch);

    assignColors();

    getRootPane().setDefaultButton(buttonClose);
    setVisible(true);
    _d.run();
  }

  public void assignColors() {
    // assign colors to antigens
    _antigenColors = new ArrayList<Color>();
    double si = (getAntigens()).size();
    for (int j=0; j<si; j++) {
      Color hsb = Color.getHSBColor((float)(((j)/si)*0.95), 
                                    (float)((j%2==0)?1.0:0.75),
                                    1.0f);
      _antigenColors.add(hsb);
    }

    // assign colors to T cells
    _tcellColors = new ArrayList<Color>();
    si = (getTCells()).size();
    if (getAntigens().size()==1) {
      for (int j=0; j<si; j++) {
        Color hsb = Color.getHSBColor((float)((j/si)*0.95), 
                                      (float)((j%2==0)?1.0:0.85),
                                      (float)((j%2==0)?1.0:0.7));
        _tcellColors.add(hsb);
      }
    } else {
      int anum = 0;
      int en = 0;
      int cnum = 0;
      int tnum = 0;
      TCRString s = ((Antigen)getAntigens().get(anum)).getStrings()[en];
      Color c = (Color)(_antigenColors.get(cnum));
      for (int j=0; j<si; j++) {
        while (getMatchRule().getDistance(s,((TCell)getTCells().get(j)).getString()) >=
               getMatchRule().getNegativeCutoff()) {
          tnum=0;
          cnum++;
          en++;
          if (en >= ((Antigen)getAntigens().get(anum)).getStrings().length) {
            anum++;
            en=0;
          }
          s = ((Antigen)getAntigens().get(anum)).getStrings()[en];
          c = (Color)(_antigenColors.get(cnum));
        }
        float[] hsbarray = Color.RGBtoHSB(c.getRed(),
                                          c.getGreen(),
                                          c.getBlue(),
                                          null);
        Color hsb = Color.getHSBColor(hsbarray[0],
                                      hsbarray[1],
                                      (float)(hsbarray[2]*(0.2+0.8*Math.pow(0.8,tnum))));
        _tcellColors.add(hsb);
        tnum++;
      }
    }
  }

  public long getRandomSeed() { return _d.getRandomSeed(); }
  public MatchRule getMatchRule() { return _d.getMatchRule(); }
  public Date getDate() { return _d.getDate(); }
  public long getHour() { return _d.getHour(); }
  public void processEvent(DriverEvent e) { _d.processEvent(e); }
  public int getCrossReactivity() { return _d.getCrossReactivity(); }
  public ArrayList getTCells() { return _d.getTCells(); }
  public ArrayList getTCellColors() { return _tcellColors; }
  public Vector getTCellLevels() { return _tcellLevels; }
  public ArrayList getAntigens() { return _d.getAntigens(); }
  public ArrayList getAntigenColors() { return _antigenColors; }
  public Vector<Vector<Long>> getAntigenLevels() { return _antigenLevels; }
  public Vector<Long> getPopulationHours() { return _popLevelsHour; }
  public Vector<Vector<Long>> getTCellPopulationLevels() { return _tcellLevels; }
  public long getPopulationMax() { return _nPopLevelsMax; }

  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equals("run")) {
      if (_runstate==RUN) {
	_runstate = STOP;
	_buttonRun.setBackground(Color.green);
	_buttonRun.setText("go");
      } else {
	_runstate = RUN;
	_buttonRun.setBackground(Color.red);
	_buttonRun.setText("stop");
      }
    } else if (e.getActionCommand().equals("step")) {
      if (_runstate==RUN) {
	_buttonRun.setBackground(Color.green);
	_buttonRun.setText("go");
      }
      _runstate = STEP;
    } else if (e.getActionCommand().equals("inject")) {
      (new Inject(this)).setVisible(true);
    } else if (e.getActionCommand().equals("save")) {
      FileDialog fd = new FileDialog(this, "Save file", FileDialog.SAVE);
      fd.setVisible(true);
      if (fd.getFile()!=null)
        _d.Save(fd.getFile());
    } else if (e.getActionCommand().equals("dump")) {
      try {
        FileDialog fd = new FileDialog(this, "Output population data", FileDialog.SAVE);
        fd.setVisible(true);
        if (fd.getFile()!=null) {
          File file = new File(fd.getFile());
          PrintWriter pw = new PrintWriter(new FileWriter(file)); 
          Date date = getDate();
          DateFormat fmt = DateFormat.getInstance();
          pw.println("#T cell simulation version " + Constants.VERSIONMAJOR + "." + Constants.VERSIONMINOR);
          pw.println("#Run on " + fmt.format(date));
          pw.println("#Random seed = " + _d.getRandomSeed());

          // affinities
          pw.print("#antigen epitope ");
          for (int j=0; j<getTCells().size(); j++)
            pw.print(((TCell)(getTCells().get(j))).getName() + " ");
          pw.println();
          for (int anum=0; anum<getAntigens().size(); anum++) {
            pw.print("#");
            Antigen ant = (Antigen)getAntigens().get(anum);
            for (int en=0; en<ant.getStrings().length; en++) {
              pw.print(anum + " " + en + " ");
              for (int tnum=0; tnum<getTCells().size(); tnum++) {
                TCRString ep = ant.getStrings()[en];
                pw.print(getMatchRule().getAffinity(ep,((TCell)getTCells().get(tnum)).getString()) + " ");
              }
            }
            pw.println();
          }

          // populations over time
          pw.print("#day ");
          ArrayList antigens = _d.getAntigens();
          ArrayList tcells = _d.getTCells();
          for (int j=0; j<antigens.size(); j++)
            pw.print(((Antigen)(antigens.get(j))).getName() + " ");
          for (int j=0; j<tcells.size(); j++)
            pw.print(((TCell)(tcells.get(j))).getName() + " ");
          pw.println();
          long asize = _antigenLevels.size();
          long tsize = _tcellLevels.size();
          for (int i=0; i<_popLevelsHour.size(); i++) {
            pw.print(((Long)(_popLevelsHour.get(i))).longValue()/24.0 + " ");
            for (int j=0; j<asize; j++)
              pw.print((Long)((Vector)_antigenLevels.get(j)).get(i) + " ");
            for (int j=0; j<tsize; j++)
              pw.print((Long)((Vector)_tcellLevels.get(j)).get(i) + " ");
            pw.println();
          }
          pw.close();
        }
      }
      catch(IOException exception) {
        System.err.println("Could not create output file");
      }
    } else if (e.getActionCommand().equals("graph")) {
      if (_popGraph==null)
	_popGraph = new PopGraph(this);
      _popGraph.setVisible(true);
    } else if (e.getActionCommand().equals("map")) {
      if (_popMap==null)
	_popMap = new PopMap(this);
      _popMap.setVisible(true);
    } else if (e.getActionCommand().equals("close")) {
      System.exit(0);
    }
  }

  public void refresh() {
    if (_popMap!=null)
      _popMap.update();
  }
  
  // called by Driver for every simulation hour
  public void update() {
    if (_runstate==RUN || _runstate==STEP || _d.getHour()==0) {
      ArrayList antigens = _d.getAntigens();
      if (_bAntibiotic && _d.getHour()==36) {
        DriverEvent event = new DriverEvent();
        event.nEventType = DriverEvent.ANTIBIOTIC;
        event.nParam[0] = 0;
        for (int j=0; j<antigens.size(); j++) {
          event.nPopulationNum = ((Antigen)(antigens.get(j))).getID();
          _d.processEvent(event);
        }
      }
      if (_nSecondarySize>0 && _d.getHour()==28*24) {
        if (_bBackwardsCompatible) {
          DriverEvent event = new DriverEvent();
          event.nEventType = DriverEvent.INJECTVIRUS;
          event.nPopulationNum = ((Antigen)(_d.getAntigens().get(1))).getID();
          event.nParam[0] = _nSecondarySize;
          if (_fSecondaryMutation==0.0)
            event.nParam[3] = 0;
          else
            event.nParam[3] = (long)(1/_fSecondaryMutation);
          _d.processEvent(event);
        } else {
          DriverEvent event = new DriverEvent();
          switch (_nSecondaryType) {
          case 0: event.nEventType = DriverEvent.CREATEVACCINE; break;
          case 1: event.nEventType = DriverEvent.CREATEVIRUS; break;
          case 2: event.nEventType = DriverEvent.CREATESLOWVIRUS; break;
          case 3: event.nEventType = DriverEvent.CREATENEWVIRUS; break;
          case 4: event.nEventType = DriverEvent.CREATEUSERMUTANTVIRUS; break;
          }
          event.nPopulationNum = ((Antigen)(_d.getAntigens().get(0))).getID();
          event.nParam[0] = _nSecondarySize;
          event.nParam[1] = 0;
          event.nParam[2] = 0;
          if (_fSecondaryMutation==0.0)
            event.nParam[3] = 0;
          else
            event.nParam[3] = (long)(1/_fSecondaryMutation);
          _d.processEvent(event);
        }
      }

      boolean bChangeColors=false;

      // record antigen levels
      while (_antigenLevels.size() < antigens.size()) {
        Vector<Long> v = new Vector<Long>();
        while (v.size()<(int)_popLevelsHour.size())
          v.add(0,new Long(-1));
        _antigenLevels.add(v);
        bChangeColors=true;
      }
      for (int j=0; j<antigens.size(); j++) {
        long n = ((Antigen)(antigens.get(j))).getVirusSize();
        (_antigenLevels.get(j)).add(new Long(n));
	if (n>_nPopLevelsMax)
	  _nPopLevelsMax = n;
      }

      // record T cell levels
      ArrayList tcells = _d.getTCells();
      while (_tcellLevels.size() < tcells.size()) {
        Vector<Long> v = new Vector<Long>();
        while (v.size()<(int)_popLevelsHour.size())
          v.add(0,new Long(-1));
        _tcellLevels.add(v);
        bChangeColors=true;
      }
      for (int j=0; j<tcells.size(); j++) {
        long n = ((Population)(tcells.get(j))).getSize();
        (_tcellLevels.get(j)).add(new Long(n));
	if (n>_nPopLevelsMax)
	  _nPopLevelsMax = n;
      }

      _popLevelsHour.add(new Long(_d.getHour()));

      if (bChangeColors)
        assignColors();

      if (_popGraph!=null)
	_popGraph.update();
      if (_popMap!=null) 
	_popMap.update();
      repaint();
      _labelClock.repaint();
      if (_runstate==STEP)
	_runstate=STOP;
      if (_d.getHour()==24*_watchtime.getNumber().intValue()+1) 
        if (_runstate==RUN)
          _buttonRun.doClick();
    }

    _labelClock.setText(String.valueOf(_d.getHour()/24) + ":" + 
			String.valueOf(_d.getHour()%24) + " ");

    // wait for the user
    while (_runstate==STOP) {
      Thread.yield();
    }
  }

  /*
   * main - the real program
   */
  public static void main(String[] args) {
    Driver driver = new Driver();
    DriverView view = new DriverView(driver);
  }
}
