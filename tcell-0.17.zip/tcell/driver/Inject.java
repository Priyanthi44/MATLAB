/*
 * Inject.java
 *
 * @author Dennis Chao
 * @version
 * @created Feb 2002
 */

package driver;

import java.util.ArrayList;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.BorderFactory; 
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;

import sim.*;

class Inject extends JFrame
  implements ActionListener {
  private JButton _buttonOK;
  private JButton _buttonCancel;
  private DriverView _d;
  private JComboBox _popchoice;
  private SpinnerNumberModel _popamount;  
  private ArrayList _antigens;

  private JRadioButton _buttonClone;
  private JRadioButton _buttonVaccine;
  private JRadioButton _buttonVirus;
  private JRadioButton _buttonVariantVirus;
  private JRadioButton _buttonNewVirus;
  private int _nAntigenType;

  public Inject(DriverView d) {
    _d = d;
    _nAntigenType = DriverEvent.INJECTVIRUS;
    setTitle("inject");
    setSize(400,300);
    Container contentPane = getContentPane();
    contentPane.setLayout(new BoxLayout(contentPane,BoxLayout.Y_AXIS));

    // controls
    _antigens = _d.getAntigens();
    _popchoice = new JComboBox();
    for (int i=0; i<_antigens.size(); i++) {
      Population p = (Population)(_antigens.get(i));
      _popchoice.addItem(p.getName() + "\t(" + p.getString() + ")");
    }
    _popchoice.setSelectedIndex(0);
    contentPane.add(_popchoice);

    JPanel AntigenPanel = new JPanel();
    AntigenPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Antigen type"));
    AntigenPanel.setLayout(new BoxLayout(AntigenPanel,BoxLayout.Y_AXIS));
    ButtonGroup AntigenButtons = new ButtonGroup();
    _buttonClone = new JRadioButton("Clone",_nAntigenType==DriverEvent.INJECTVIRUS);
    _buttonVaccine = new JRadioButton("Vaccine",_nAntigenType==DriverEvent.CREATEVACCINE);
    _buttonVirus = new JRadioButton("Virus",_nAntigenType==DriverEvent.CREATEVIRUS);
    _buttonNewVirus = new JRadioButton("New virus",_nAntigenType==DriverEvent.CREATENEWVIRUS);
    _buttonVariantVirus = new JRadioButton("Variant virus",_nAntigenType==DriverEvent.CREATEUSERMUTANTVIRUS);
    _buttonClone.setActionCommand("clone");
    _buttonVaccine.setActionCommand("vaccine");
    _buttonVirus.setActionCommand("virus");
    _buttonNewVirus.setActionCommand("newvirus");
    _buttonVariantVirus.setActionCommand("variantvirus");
    _buttonClone.addActionListener(this);
    _buttonVaccine.addActionListener(this);
    _buttonVirus.addActionListener(this);
    _buttonNewVirus.addActionListener(this);
    _buttonVariantVirus.addActionListener(this);
    AntigenButtons.add(_buttonClone);
    AntigenButtons.add(_buttonVaccine);
    AntigenButtons.add(_buttonVirus);
    AntigenButtons.add(_buttonNewVirus);
    AntigenButtons.add(_buttonVariantVirus);
    AntigenPanel.add(_buttonClone);
    AntigenPanel.add(_buttonVaccine);
    AntigenPanel.add(_buttonVirus);
    AntigenPanel.add(_buttonNewVirus);
    AntigenPanel.add(_buttonVariantVirus);
    contentPane.add(AntigenPanel);

    _popamount = new SpinnerNumberModel(500, 0, 100000, 1);
    contentPane.add(new JSpinner(_popamount));

    // buttons
    Panel buttonPanel = new Panel();
    buttonPanel.setLayout(new FlowLayout());

    _buttonOK = new JButton("inject");
    _buttonOK.setActionCommand("inject");
    _buttonOK.addActionListener(this);
    _buttonCancel = new JButton("cancel");
    _buttonCancel.setActionCommand("cancel");
    _buttonCancel.addActionListener(this);

    buttonPanel.add(_buttonOK);
    buttonPanel.add(_buttonCancel);
    contentPane.add(buttonPanel);
  }

  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equals("inject")) {
      DriverEvent de = new DriverEvent();
      de.nEventType = _nAntigenType;
      de.nPopulationNum = _popchoice.getSelectedIndex();
      de.nParam[0] = _popamount.getNumber().intValue();
      _d.processEvent(de);
      dispose();
    } else if (e.getActionCommand().equals("cancel")) {
      dispose();
    } else if (e.getActionCommand().equals("clone")) {
      _nAntigenType = DriverEvent.INJECTVIRUS;
    } else if (e.getActionCommand().equals("vaccine")) {
      _nAntigenType = DriverEvent.CREATEVACCINE;
    } else if (e.getActionCommand().equals("virus")) {
      _nAntigenType = DriverEvent.CREATEVIRUS;
    } else if (e.getActionCommand().equals("newvirus")) { 
      _nAntigenType = DriverEvent.CREATENEWVIRUS;
    } else if (e.getActionCommand().equals("variantvirus")) {
      _nAntigenType = DriverEvent.CREATEUSERMUTANTVIRUS;
    }
  }
}
