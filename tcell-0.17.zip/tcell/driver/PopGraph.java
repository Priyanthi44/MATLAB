/*
 * PopGraph.java
 *
 * @author Dennis Chao
 * @version
 * @created Jan 2002
 *
 * A graph widget that draws Population levels
 */

package driver;

import java.util.ArrayList;
import java.util.Vector;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import sim.Population;

class PopGraph extends JFrame {
  private PopGraphPanel _panelGraph;
  private DriverView _d;

  public PopGraph(DriverView d) {
    _d = d;
    setTitle("Population levels");
    setSize(500,350);
    Container contentPane = getContentPane();

    _panelGraph = new PopGraphPanel(_d);
    contentPane.add(_panelGraph, "Center");
  }

  //  public void show() {
  //    super.show();
  //  }

  public void update() {
    _panelGraph.update();
  }
}

class PopGraphPanel extends JPanel {
  private DriverView _d;

  public PopGraphPanel(DriverView d) {
    _d = d;
    setBackground(Color.black);
  }

  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Dimension d = getSize();
    long nMax = (int)Math.ceil(Math.log(_d.getPopulationMax())/Math.log(10));
    double yscale = d.height/(double)nMax;
    int tickscale = 1;
    FontMetrics fm = g.getFontMetrics();
    
    // draw horizontal tick marks
    g.setColor(Color.darkGray);
    for (int i=0; i<=nMax; i++) {
      int y = d.height-(int)(i*yscale);
      g.drawLine(0, y, d.width, y);
      g.drawString("10^" + String.valueOf(i), 0, y);
    }

    // draw vertical (date) tick marks
    long lastday = -1;
    Vector hours = _d.getPopulationHours();
    int end = d.width;
    if (hours.size()<d.width)
      end = hours.size();
    for (int i=0; i<end; i++) {
      if (lastday != (((Long)(hours.get(hours.size()-i-1))).longValue())/24) {
	lastday = ((Long)(hours.get(hours.size()-i-1))).longValue()/24;
	g.drawLine(d.width-i,
		   0,
		   d.width-i,
		   d.height);
        g.drawString(String.valueOf(lastday+1), d.width-i+1, 11);
      }
    }

    // draw antigen level curves
    ArrayList pops = _d.getAntigens();
    ArrayList popcolors = _d.getAntigenColors();
    int s = _d.getAntigenLevels().size();
    for (int j=0; j<s; j++) {
      g.setColor((Color)popcolors.get(j));
      
      // draw legend
      g.drawString(((Population)(pops.get(j))).getName(), 
                   0, fm.getAscent()*(j+1));

      // draw curves
      Vector data = (Vector)(_d.getAntigenLevels().get(j));
      end = d.width;
      if (data.size()<d.width)
	end = data.size();
      for (int i=0; i<end; i+=2)  // just plot every other hour
        if (((Long)(data.get(data.size()-i-1))).longValue()>0)
          g.drawRect(d.width-i-1,
                     d.height-1-(int)
                     (Math.log(((Long)(data.get(data.size()-i-1))).longValue())/Math.log(10)*yscale),
                     2,
                     2);
    }

    // draw T cell level curves
    pops = _d.getTCells();
    popcolors = _d.getTCellColors();
    s = popcolors.size();
    for (int j=0; j<s; j++) {
      g.setColor((Color)popcolors.get(j));
      
      // draw legend
      if (pops.size()<10)
	g.drawString(((Population)(pops.get(j))).getName(), 
		     0, fm.getAscent()*(j+1+(_d.getAntigens().size())));

      // draw curves
      Vector data = (Vector)(_d.getTCellLevels().get(j));
      end = d.width;
      if (data.size()<d.width)
	end = data.size();
      for (int i=0; i<end-1; i++)
        if (((Long)(data.get(data.size()-i-1))).longValue()>0 &&
            ((Long)(data.get(data.size()-i-2))).longValue()>0)
          g.drawLine(d.width-i-1,
                     d.height-(int)
                     (Math.log(((Long)(data.get(data.size()-i-2))).longValue())/Math.log(10)*yscale),
                     d.width-i,
                     d.height-(int)
                     (Math.log(((Long)(data.get(data.size()-i-1))).longValue())/Math.log(10)*yscale));
    }
  }

  // update - grab current population levels and update graph
  public void update() {
    repaint();
  }
}
