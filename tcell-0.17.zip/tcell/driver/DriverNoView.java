/*
 * DriverNoView.java
 *
 * @author Dennis Chao
 * @version
 * @created Feb 2004
 *
 * Batch interface for Driver in immune simulation.
 */

package driver;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import sim.*;
import driver.StartScreen;

class DriverNoView implements DriverInterface {
  private Driver _d;
  private LinkedList<DriverEvent> _events;
  private Vector<Vector<Long>> _tcellLevels;     // stored Population sizes for plot
  private Vector<Vector<Long>> _antigenLevels;   // stored Population sizes for plot
  private boolean _bTerse;         // set to true for weird output format
  
  public DriverNoView(Driver d, String filename) {
    _bTerse = false;
    _d = d;
    _d.registerView(this);
    _events = new LinkedList<DriverEvent>();
    if (!_bTerse) {
      _tcellLevels = new Vector<Vector<Long>>();
      _antigenLevels = new Vector<Vector<Long>>();
    }
    Load(filename);
    _d.run();
  }

  public void Load(String filename) {
    try {
      BufferedReader in = new BufferedReader(new FileReader(filename));
      String s;
      while((s = in.readLine()) != null) {
        DriverEvent event = new DriverEvent();
        for (int i=0; i<DriverEvent.szEventName.length; i++) {
          if (s.compareTo("#"+DriverEvent.szEventName[i])==0) {
            event.nEventType = i;
            break;
          }
        }
        s = in.readLine();
        event.nTime = Long.parseLong(s);
        for (int i=0; i<event.nParam.length; i++) {
          s = in.readLine();
          event.nParam[i] = Long.parseLong(s);
        }
        s = in.readLine();
        event.nPopulationNum = Integer.parseInt(s);

        // If a mutant was created through a random event, then do not
        // record this event - let them mutate on their own.
        if (event.nEventType!=DriverEvent.CREATEMUTANTVIRUS)
          _events.addLast(event);
      }
      in.close();
    } catch (IOException ex) {
      System.err.println("ERROR: file '" + filename + "' does not exist");
      System.exit(-1);
    }
    ProcessEvents();
  }

  // ProcessEvents - send events to driver for processing
  public boolean ProcessEvents() {
    DriverEvent event;
    event = (DriverEvent)(_events.getFirst());
    while (event.nTime<=_d.getHour() || event.nTime<=0) {
      System.err.println("Event " + DriverEvent.szEventName[event.nEventType]);
      _d.processEvent(event);
      _events.removeFirst();

      // print final results
      if (event.nEventType==DriverEvent.END) {
        ArrayList antigens = _d.getAntigens();
        ArrayList tcells = _d.getTCells();
        if (_bTerse)
          System.out.print("#hour CTLs ");
        else
          System.out.print("#hour ");
        for (int j=0; j<antigens.size(); j++)
          System.out.print(((Antigen)(antigens.get(j))).getName() + " ");
        if (!_bTerse) {
          for (int j=0; j<tcells.size(); j++)
            System.out.print(((TCell)(tcells.get(j))).getName() + " ");
          System.out.println();
          for (int i=0; i<((Vector)_antigenLevels.get(0)).size(); i++) {
            System.out.print(i + " ");
            for (int j=0; j<_antigenLevels.size(); j++)
              System.out.print((Long)((Vector)_antigenLevels.get(j)).get(i) + " ");
            for (int j=0; j<_tcellLevels.size(); j++)
              System.out.print((Long)((Vector)_tcellLevels.get(j)).get(i) + " ");
            System.out.println();
          }
        } else {
          System.out.println();
        }
        return false;
      }
      event = (DriverEvent)(_events.getFirst());
    }
    return true;
  }

  // called by Driver for every simulation hour
  public void update() {
    DriverEvent event;
    if (_events.size()==0)
      System.exit(0);

    ArrayList antigens = _d.getAntigens();
    ArrayList tcells = _d.getTCells();

    // save antigen and T cell levels for this hour
    if (!_bTerse) {
      int a=(int)_d.getHour();
      while (_antigenLevels.size() < antigens.size()) {
        Vector<Long> v = new Vector<Long>();
        while (v.size()<a) 
          v.add(0,new Long(-1));
        _antigenLevels.add(v);
      }
      for (int j=0; j<antigens.size(); j++) {
        long n = ((Antigen)(antigens.get(j))).getVirusSize();
        ((Vector<Long>)_antigenLevels.get(j)).add(a,new Long(n));
      }
      while (_tcellLevels.size() < tcells.size()) {
        Vector<Long> v = new Vector<Long>();
        while (v.size()<a)
          v.add(0,new Long(-1));
        _tcellLevels.add(v);
      }
      for (int j=0; j<tcells.size(); j++) {
        long n = ((Population)(tcells.get(j))).getSize();
        ((Vector<Long>)_tcellLevels.get(j)).add(new Long(n));
      }
    } else if (_d.getHour()%24==0) {
      long sum = 0;
      for (int j=0; j<tcells.size(); j++) {
        long n = ((Population)(tcells.get(j))).getSize();
        sum += n;
      }
      System.out.print(_d.getHour() + " " + sum);
      for (int j=0; j<antigens.size(); j++) {
        long n = ((Antigen)(antigens.get(j))).getVirusSize();
        System.out.print(" " + n);
      }
      System.out.println();
    }
    // process events
    if (ProcessEvents()==false || _events.size()==0)
      System.exit(0);
    else
      event = (DriverEvent)(_events.getFirst());
  }

  /*
   * main - the real program
   */
  public static void main(String[] args) {
    Driver driver = new Driver();
    String filename = new String("savefile");
    if (args.length>0) {
      filename = args[0];
    } else {
      System.err.println("Usage: java DriverNoView [savefile]");
      System.exit(-1);
    }

    DriverNoView view = new DriverNoView(driver, filename);
  }
}
