/*
 * XorMatchRule.java
 * by Dennis Chao (5/01)
 * Xor distance match rule for TCRString.
 */

package sim;

import java.util.ArrayList;
import sim.MatchRule;
import sim.TCRString;
import sim.BitCompositionSet;
import lib.KnuthRandom;
import lib.Probability;

public class XorMatchRule extends MatchRule {
  private int _nNumBits;              // the number of bits per digit
  private BitCompositionSet[][] _bcs; // bit composition sets
                                      // first index is # of digits
                                      // second is radius
  public XorMatchRule(int nAlphabetSize, 
		      int nLengthMHC,
		      int nNumMHC,
		      int nLengthPeptide,
		      int nNumPeptide,
		      long nNumClones) {
    super(nAlphabetSize, nLengthMHC, nNumMHC, nLengthPeptide, nNumPeptide, nNumClones);
    _nNumBits = (int)(Math.round(Math.log(nAlphabetSize)/Math.log(2)));
  }

  public int getMutationUnit() { return 1; }

  public double[] getDigitMatchScores() {
    double[] p = new double[_nAlphabetSize];
    for (int i=0; i<_nAlphabetSize; i++)
      p[i] = 1.0/(double)(_nAlphabetSize);
    return p;
  }

  // getExpectedNumClones - returns expected # of clones at given distance.
  // caching results might be better, but I don't think it's important.
  public double getExpectedNumClones(int nDistance) {
    double[] d1 = new double[_nAlphabetSize];
    for (int i=0; i<_nAlphabetSize; i++)
      d1[i] = 1/(double)_nAlphabetSize;
    double sum=0.0;
    for (int i=0; i<_nAlphabetSize; i++) {
      sum += d1[i];
    }

    double[] d2 = NConvolve(d1, _nStringLength);
    //    for (int i=0; i<d2.length; i++) {
    //      System.out.println(i + " " + d2[i]);
    //    }
    return _nNumClones*d2[nDistance];
  }

  public int getMaxDistance() { return (_nAlphabetSize-1)*_nStringLength; }

  public int getDistance(TCRString a, TCRString b) {
    int dist = 0;
    for (int i=0; i<a.getLength(); i++)
      dist += a.getDigit(i) ^ b.getDigit(i);
    return dist;
  }

  public int getDistance(TCRString a, TCRString b, int len) {
    int dist = 0;
    for (int i=len-1; i>=0; i--)
      dist += a.getDigit(i) ^ b.getDigit(i);
    return dist;
  }

  public double DistToAffinity(int nDistance) {
    // this is hard-coded and will not work if parameters are changed
    double d = nDistance - 115;
    return 5000+15000*Math.exp(d/3.0);
  }

  public TCRString getRandomStringAt(TCRString center, 
				     int dist, 
				     KnuthRandom random) {
    TCRString s = new TCRString(center.getAlphabetSize(), center.getLength());
    int nNumDigits = center.getLength();
    if (dist==0)
      return center;

    // if needed, allocate room for number of digits in center
    // note: I do not allocate extra space beyond nNumDigits
    // this can be changed to allocating extra space if desired
    if (_bcs==null || _bcs.length<nNumDigits) {
      BitCompositionSet[][] newbcs = new BitCompositionSet[nNumDigits][];
      if (_bcs!=null)
	for (int i=0; i<_bcs.length; i++) {
	  newbcs[i] = _bcs[i];
	}
      _bcs = newbcs;
    }

    // if needed, allocate room for nRadius in _bcs[center.length]
    if (_bcs[nNumDigits-1]==null || _bcs[nNumDigits-1].length<dist) {
      BitCompositionSet[] newbcs = new BitCompositionSet[dist*2];
      if (_bcs[nNumDigits-1]!=null)
	for (int i=0; i<_bcs[nNumDigits-1].length; i++) {
	  newbcs[i] = _bcs[nNumDigits-1][i];
	}
      _bcs[nNumDigits-1] = newbcs;
    }

    // if needed, compute bcs for nRadius
    if (_bcs[nNumDigits-1][dist-1]==null) {
      _bcs[nNumDigits-1][dist-1] = new BitCompositionSet(_nNumBits, 
							 nNumDigits, 
							 dist);
      //System.out.println("Allocating bcs for " + nNumDigits + " digits, " + nRadius + " radius");
    }

    byte[] bc = _bcs[nNumDigits-1][dist-1].getRandomBitComposition(random);

    if (bc==null) {
      System.err.println("No BCS for radius " + dist);
      return null;
    }
    //    int[] nResult = new int[nNumDigits];
    int[] nBit = new int[nNumDigits];

    for (int i=0; i<bc.length; i++) {
      // turn on the right number of bits
      for (int j=0; j<bc[i]; j++)
	nBit[j] = 1;

      // permute bit order
      for (int j=0; j<nNumDigits; j++) {
	int randnum = random.randomInt(nNumDigits);
	int temp = nBit[j];
	nBit[j] = nBit[randnum];
	nBit[randnum] = temp;
      }

      // add bit to current random string
      for (int j=0; j<nNumDigits; j++) {
	if (nBit[j]!=0) {
	  s.setDigit(j, (byte)(s.getDigit(j) | (1<<i)));
	  //	  nResult[j] |= (1<<i);
	  nBit[j]=0;
	}
      }
    }

    // xor random string with center
    for (int i=0; i<nNumDigits; i++)
      s.setDigit(i,(byte)(s.getDigit(i) ^ center.getDigit(i)));

    return s;
  }

  /*
   * getNumClonesAt - 
   */
  public long getNumClonesAt(int nDistance, 
			     KnuthRandom random) {
    double[] d1 = new double[_nAlphabetSize];
    for (int i=0; i<_nAlphabetSize; i++)
      d1[i] = 1/(double)_nAlphabetSize;
    double sum=0.0;
    for (int i=0; i<_nAlphabetSize; i++)
      sum += d1[i];

    double[] d2 = NConvolve(d1, _nStringLength);
    return Probability.RandomFromBinomial(_nNumClones,d2[nDistance],random);
  }

  /*
   * NConvolve - convolves a vector with itself "n" times
   */
  private double[] NConvolve(double[] a, int n) {
    double[] result = a;
    for (int i=0; i<n-1; i++)
      result = Convolve(a, result);
    return result;
  }

  /*
   * Convolve - convolves to vectors and returns the result.
   */
  private double[] Convolve(double[] a, double[] b) {
    double[] result = new double[a.length + b.length - 1];
    for (int i=0; i<a.length; i++)
      for (int j=0; j<b.length; j++)
	result[i+j] += a[i]*b[j];
    return result;
  }

  /*
   * main - a little test program
   */
  public static void main(String[] args) {
    int nAlphabetSize = 16;
    int nStringLength = 4;
    long nNumClones = (long)Math.pow(10,9);
    KnuthRandom random = new KnuthRandom();
    random.seedRandom(467773953);
    MatchRule m = new XorMatchRule(nAlphabetSize, 5, 1, 5, 1, nNumClones);
    TCRString origin = new TCRString(nAlphabetSize, nStringLength);

    int setdist = 10;

    long hist[] = new long[10000];
    for (int i=0; i<hist.length; i++)
      hist[i]=0;
    int maxhist = 0;
    for (int i=0; i<10000; i++) {
      TCRString t = m.getRandomStringAt(origin, 15, random);
      int icount=0;
      for (int radius=0; radius<=setdist; radius++) {
        long numclones = m.getNumClonesAt(radius, random);
        for (int j=0; j<numclones; j++) {
          TCRString s = m.getRandomStringAt(origin, radius, random);
          if (m.getDistance(t, s)<=setdist)
            icount++;
        }
      }
      hist[icount]++;
      if (icount>maxhist)
        maxhist = icount;
    }
    for (int i=0; i<=maxhist; i++) {
      System.out.println(i + " " + hist[i]);
    }

    /*
    int nAlphabetSize = 128;
    int nStringLength = 10;
    long nNumClones = (long)Math.pow(10,8);
    KnuthRandom random = new KnuthRandom();
    random.seedRandom(467773953);
    MatchRule m=null;
    //    MatchRule m = new XorMatchRule(nAlphabetSize, nStringLength, nNumClones);
    TCRString t = new TCRString(nAlphabetSize, nStringLength);
    TCRString origin = new TCRString(nAlphabetSize, nStringLength);
    TCRString s; // = new TCRString(nAlphabetSize, nStringLength);

    double d = m.getExpectedNumClones(255);
    System.out.println("expected = " + d);

    for (int i=0; i<10; i++)
    System.out.println("# clones at 255 = " + m.getNumClonesAt(255, random));
    
    //    s = m.getRandomStringAt(origin, 10, random);
    //    System.out.println(s.toString());
    //    System.out.println("# clones at 500 = " + m.getNumClonesAt(500, random));
    */
  }
}
