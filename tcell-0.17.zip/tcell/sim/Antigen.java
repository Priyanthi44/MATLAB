/*
 * Antigen.java
 *
 * @author Dennis Chao
 * @version
 * @created Jan 2002
 *
 * An Antigen consists of two populations: the virus and the infected cell.
 * Both populations have intrinsic death/decay rates.
 * The virus population behaves as: dv/dt = ky-uv
 * The infected cell population as: dy/dt = Bxv-ay
 * There should be a pointer to an uninfected population x.
 * The infected cell expresses multiple epitopes.
 */

package sim;

import lib.KnuthRandom;
import lib.Probability;
import driver.Driver;
import driver.DriverEvent;

public class Antigen extends Population {
  private TCRString[] _epitopes, _mhcs, _complexes;
  private double[] _levels;
  private double _fInfectionRate, 
    _fProductionRate,
    _fViralDecayRate,
    _fMutationRate,
    _fInfectedDeathRate;
  private Population _popVirus, _popInfected, _popBody;
  private Driver _d;
  private int _nID;              // unique population object id number
  private static int _nCurrentID = 0; // counter to assign ids

  public Antigen(String name, 
		 long nPopulation, 
		 double fInfectionRate, 
		 double fProductionRate,
		 double fViralDecayRate,
		 double fInfectedDeathRate,
		 TCRString[] szEpitopes, TCRString[] szMHCs,
                 double[] fLevels,
                 double fMutationRate,
		 Population popBody,
                 Driver d) {
    super(name, 0, 0.0, 0.0);
    _nID = _nCurrentID++;
    _d = d;
    _fInfectionRate = fInfectionRate;
    _fProductionRate = fProductionRate;
    _fViralDecayRate = fViralDecayRate;
    _fInfectedDeathRate = fInfectedDeathRate;
    _fMutationRate = fMutationRate;
    if (_fMutationRate>1.0) {
      throw new Error ("Antigen mutation rate can not be > 1 ("+fMutationRate+")");
    }
    _popVirus = new Population(name, nPopulation, 0.0, _fViralDecayRate);
    _popInfected = new Population(name, 0, 0.0, _fInfectedDeathRate);

    _popBody = popBody;
    _epitopes = szEpitopes;
    _mhcs = szMHCs;
    _complexes = new TCRString[_epitopes.length];
    for (int i=0; i<_epitopes.length; i++) {
      _complexes[i] = new TCRString(_epitopes[i],
				    _mhcs[i]);
    }
    _levels = fLevels;
  }

  public int    getID()         { return _nID; }
  public TCRString getString() { return _complexes[0]; }  // returns first epitope
  public TCRString[] getStrings() { return _complexes; }
  public TCRString[] getPeptideStrings() { return _epitopes; }
  public TCRString[] getMHCStrings() { return _mhcs; }
  public double[]    getPeptideLevels() { return _levels; }

  public long getSize() { return _popInfected.getSize(); }
  public long getInfectedSize() { return _popInfected.getSize(); }
  public void setInfectedSize(long nNewPop) { _popInfected.setSize(nNewPop); }
  public void setSize(long nNewPop) { _popInfected.setSize(nNewPop); }
  public void incSize(long nPopInc) { _popInfected.incSize(nPopInc); }
  public void incInfectedSize(long nPopInc) { _popInfected.incSize(nPopInc); }
  public long getVirusSize() { return _popVirus.getSize(); }
  public void setVirusSize(long nNewPop) { _popVirus.setSize(nNewPop); }
  public void incVirusSize(long nPopInc) { _popVirus.incSize(nPopInc); }
  public double getInfectionRate() { return _fInfectionRate; }
  public double getProductionRate() { return _fProductionRate; }
  public double getViralDecayRate() { return _fViralDecayRate; }
  public double getInfectedDeathRate() { return _fInfectedDeathRate; }

  public void clock(KnuthRandom r) {
    if (_popVirus.getSize()>0 || _popInfected.getSize()>0) {
      long numInfected = Probability.RandomFromBinomial(_popBody.getSize(),
							1.0-Math.exp(-_fInfectionRate/Constants.TIMESTEPSPERDAY*_popVirus.getSize()), 
							r);
      long numProduced = Probability.RandomFromPoisson(_popInfected.getSize() * _fProductionRate/Constants.TIMESTEPSPERDAY,
                                                       r);

      // virus and infected cell populations decay
      _popVirus.clock(r);
      _popInfected.clock(r);

      // create mutant viruses
      // note: For efficiency, mutants are created upon infection of target cells,
      // not when viruses are created.  
      if (_fMutationRate>0.0) {
        long numMutated = Probability.RandomFromBinomial(numInfected,
                                                         _fMutationRate,
                                                         r);
        if (numMutated>0) {
          numInfected -= numMutated;
          DriverEvent e = new DriverEvent();
          e.nEventType = DriverEvent.CREATEMUTANTVIRUS;
          e.nParam[0] = 0;
          e.nParam[1] = 1;
          e.nParam[2] = (long)(_levels[0]*100);
          if (_fMutationRate==0.0)
            e.nParam[3] = 0;
          else
            e.nParam[3] = (long)(1/_fMutationRate);
          e.nPopulationNum = getID();
          for (int i=0; i<numMutated; i++)
            _d.processEvent(e);
        }
      }

      // update population sizes
      _popInfected.incSize(numInfected);
      _popBody.incSize(-numInfected);
      _popVirus.incSize(numProduced);
    }
  }

  // Gillespie First Reaction version
  public static void FirstReaction(KnuthRandom rand) {
    long T=1000000, 
      I=0, V=500;
    double lambda = 50000/24.0;
    double death_target = 0.01/24.0;
    double infectivity = 2e-7/24.0;
    double death_infected = 0.7/24.0;
    double production = 100.0/24.0;
    double death_virus = 2.3/24.0;
    double time = 0.0;
    int lasthour=0;
    for (int i=0; lasthour<24*20; i++) {
      double next_lambda = Probability.RandomFromExponential(lambda, rand);
      double next_death_target = Probability.RandomFromExponential(death_target*T, rand);
      double next_infection = Probability.RandomFromExponential(infectivity*T*V, rand);
      double next_death_infected = Probability.RandomFromExponential(death_infected*I, rand);
      double next_production = Probability.RandomFromExponential(production*I, rand);
      double next_death_virus = Probability.RandomFromExponential(death_virus*V, rand);
      /*      System.out.println("         " + next_lambda + " " +
                         next_death_target + " " +
                         next_infection + " " +
                         next_death_infected + " " +
                         next_production + " " +
                         next_death_virus); */
      double first = Math.min(next_lambda,
                         Math.min(next_death_target,
                             Math.min(next_infection,
                                 Math.min(next_death_infected,
                                     Math.min(next_production,
                                         next_death_virus)))));
      // perform first reaction
      if (next_lambda==first) {
        T++;
      } else if (next_death_target==first) {
        T--;
      } else if (next_infection==first) {
        T--;
        I++;
      } else if (next_death_infected==first) {
        I--;
      } else if (next_production==first) {
        V++;
      } else if (next_death_virus==first) {
        V--;
      }
      time += first;
      //print
      if (time>lasthour+1) {
        if (((int)time)%12==0)
          System.out.print(T + " " + I + " " + V + " ");
        //        System.out.println((time/24.0) + " " + T + " " + I + " " + V);
        lasthour++;
      }
    }
  }

  // Gillespie Direct Method version
  public static void Direct(KnuthRandom rand) {
    long T=1000000, 
      I=0, V=500;
    double lambda = 50000/24.0;
    double death_target = 0.01/24.0;
    double infectivity = 2e-7/24.0;
    double death_infected = 0.7/24.0;
    double production = 100.0/24.0;
    double death_virus = 2.3/24.0;
    double time = 0.0;
    int lasthour=0;

    while (lasthour<24*20) {
      double next_lambda = lambda;
      double next_death_target = death_target*T;
      double next_infection = infectivity*T*V;
      double next_death_infected = death_infected*I;
      double next_production = production*I;
      double next_death_virus = death_virus*V;
      double sum = next_lambda+next_death_target+next_infection+next_death_infected+next_production+next_death_virus;
      
      // which reaction
      double r = rand.randomDouble()*sum;
      if (r<next_lambda) {
        T++;
      } else if ((r-=next_lambda)<next_death_target) {
        T--;
      } else if ((r-=next_death_target)<next_infection) {
        T--;
        I++;
      } else if ((r-=next_infection)<next_death_infected) {
        I--;
      } else if ((r-=next_death_infected)<next_production) {
        V++;
      } else {
        V--;
      }
      // when
      r = Probability.RandomFromExponential(sum,rand);
      time += r;
      // print
      if (time>lasthour+1) {
        if (((int)time)%12==0)
          System.out.print(T + " " + I + " " + V + " ");
        //        System.out.println((time/24.0) + " " + T + " " + I + " " + V);
        lasthour++;
      }
    }
      System.out.println();
  }

  // test program
  public static void main(String[] args) {
    KnuthRandom r = new KnuthRandom();
    r.seedRandom(-1);
    //System.out.println("# random seed = " + r.getSeed());
    //    FirstReaction(r);
    //    Direct(r);
    //    if (true)
    //      return;

    Uninfected uninfected = new Uninfected("uninfected", (long)Math.pow(10,6), 
                                           5*Math.pow(10, 4), 0.01);
    TCRString[] ags = new TCRString[1];
    TCRString[] mhcs = new TCRString[1];
    double[] levels = new double[1];
    ags[0] = new TCRString(4, 4);
    mhcs[0] = new TCRString(4, 4);
    levels[0] = 1.0;
    Antigen antigen = new Antigen("virus",
                                  500, 
                                  2e-7,               // infection rate
                                  100,                // production rate
                                  2.3,                // viral decay rate
                                  0.7,                // infected cell death rate
                                  ags, mhcs, levels,
                                  0.0,
                                  uninfected,
                                  (Driver)null);

    // day 6, ehl.agr, 50 naive
    antigen.setInfectedSize(240000);
    antigen.setVirusSize(15000000);

    /*    // day 4, ehl.agr, 50,000 naive
    antigen.setInfectedSize(7000);
    antigen.setVirusSize(430000); */
    antigen.setVirusSize(0);

    antigen.setInfectedSize(1000);

    for (int t=0; t<20*Constants.TIMESTEPSPERDAY; t++) {
      if (t%(Constants.TIMESTEPSPERHOUR)==0)
        System.out.println((t/(double)Constants.TIMESTEPSPERDAY) + " " + uninfected.getSize() + " " + antigen.getInfectedSize() + " " + antigen.getVirusSize() + " ");
      uninfected.clock(r);
      antigen.clock(r);
      double expected = (Constants.CLEARANCE/Constants.TIMESTEPSPERDAY)*1000000*antigen.getInfectedSize() / (8000+1000000+antigen.getInfectedSize());
      long numcleared = Probability.RandomFromPoisson(expected, r);
      antigen.incSize(-numcleared);
      //      System.out.println(expected);
    }

    /*
    for (int t=0; t<=20*Constants.TIMESTEPSPERDAY; t++) {
      if (t%(Constants.TIMESTEPSPERHOUR*12)==0 && t>0)
        System.out.print(uninfected.getSize() + " " + antigen.getInfectedSize() + " " + antigen.getVirusSize() + " ");
      uninfected.clock(r);
      antigen.clock(r);
    }
    */
    System.out.println();
  }
}
