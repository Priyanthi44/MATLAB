/*
 * ManhattanMatchRule.java
 * by Dennis Chao (5/01)
 * Manhattan (or city block) distance match rule for TCRString.
 */

package sim;

import java.util.ArrayList;
import sim.MatchRule;
import sim.TCRString;
import lib.KnuthRandom;
import lib.Probability;

public class ManhattanMatchRule extends MatchRule {
  private long[] _numAtDistance;
  private long _nTotal;
  private long[][][] _distr;
  private long[][][] _distrcdf;
  public ManhattanMatchRule(int nAlphabetSize, 
			    int nLengthMHC,
			    int nNumMHC,
			    int nLengthPeptide,
			    int nNumPeptide,
			    long nNumClones) {
    super(nAlphabetSize, nLengthMHC, nNumMHC, nLengthPeptide, nNumPeptide, nNumClones);

    long[] p = new long[(nAlphabetSize)/2 + 1];
    for (int i=1; i<=(nAlphabetSize-1)/2; i++)
      p[i] = 2;
    p[0] = 1;
    if (nAlphabetSize%2==0)
      p[nAlphabetSize/2] = 1;
    _numAtDistance = Probability.NConvolve(p,_nStringLength);
    _nTotal=0;
    for (int i=0; i<_numAtDistance.length; i++)
      _nTotal += _numAtDistance[i];
    _distr = new long[_nStringLength+1][(nAlphabetSize/2)*_nStringLength+1][nAlphabetSize/2+1];
    _distrcdf = new long[_nStringLength+1][(nAlphabetSize/2)*_nStringLength+1][nAlphabetSize/2+1];
    for (int i=0; i<_distr.length; i++) 
      for (int j=0; j<_distr[i].length; j++)
        for (int k=0; k<_distr[i][j].length; k++)
          _distr[i][j][k] = _distrcdf[i][j][k] = -1;

    for (int i=0; i<=getPositiveCutoff(); i++)
      findDistr(_nStringLength, i);
  }

  public int getMutationUnit() { return 1; }

  public long findDistr(int nLength, int nDistance) {
    if (nDistance==0) {
      _distr[nLength][0][0] = 1;  // only 1 string (000...) possible
      return 1;
    }
    if (nLength==1) {
      for (int i=0; i<=_nAlphabetSize/2; i++)
        _distr[1][nDistance][i] = 0;
      if (nDistance>_nAlphabetSize/2)
        return 0;                 // distance too great - no string possible
      else if (_nAlphabetSize%2==0 && nDistance==_nAlphabetSize/2)
        return _distr[1][nDistance][nDistance] = 1;
      else
        return _distr[1][nDistance][nDistance] = 2;
    }
    long sum=0;
    long bound = Math.min(nDistance,_nAlphabetSize/2);
    for (int i=0; i<=bound; i++) {
      if (_distr[nLength][nDistance][i]<0) {
        _distr[nLength][nDistance][i] = 
          findDistr(nLength-1, nDistance-i);
        if (i!=0 && !(_nAlphabetSize%2==0 && i==_nAlphabetSize/2))
          _distr[nLength][nDistance][i]*=2;
      }
      sum += _distr[nLength][nDistance][i];
    }
    return sum;
  }

  public void printDistr() {
    for (int i=1; i<=_nStringLength; i++) {
      System.out.println(i);
      for (int j=0; j<_distr[i].length; j++) {
        System.out.print(" " + j + ": ");
        for (int k=0; k<_distr[i][j].length; k++) {
          if (_distr[i][j][k]<0)
            System.out.print(".\t" );
          else
            System.out.print(_distr[i][j][k] + "\t" );
        }
        System.out.println();
      }
    }
  }

  public int getDistance(TCRString a, TCRString b) {
    return getDistance(a,b,a.getLength());
  }

  public int getDistance(TCRString a, TCRString b, int len) {
    int dist = 0;
    for (int i=0; i<len; i++) {
      int diff = Math.abs(((int)a.getDigit(i))-((int)b.getDigit(i)));
      if (diff>_nAlphabetSize/2)
        diff = _nAlphabetSize-diff;
      dist += diff;
    }
    return dist;
  }

  public int getMaxDistance() { return _nStringLength*_nAlphabetSize; }

  public double[] getDigitMatchScores() {
    double[] p = new double[(_nAlphabetSize)/2 + 1];
    for (int i=1; i<=(_nAlphabetSize-1)/2; i++)
      p[i] = 2.0/(double)(_nAlphabetSize);
    p[0] = 1.0/(double)(_nAlphabetSize);
    if (_nAlphabetSize%2==0)
      p[_nAlphabetSize/2] = 1.0/(double)(_nAlphabetSize);
    return p;
  }

  public double DistToAffinity(int nDistance) {
    // this is hard-coded and will not work if parameters are changed
    double d = nDistance - 15;
    return 5000+10000*Math.exp(2.0*d);
  }

  public double getExpectedNumClones(int nDistance) {
    if (nDistance<_numAtDistance.length)
      return _nNumClones*(double)_numAtDistance[nDistance]/_nTotal;
    else
      return 0.0;
  }

  private long getDistrcdf(int nStringLength, int dist, int index) {
    if (_distrcdf[nStringLength][dist][0]<0) {
      if (_distr[nStringLength][dist][0]<0)
        findDistr(nStringLength, dist);
      long sum=0;
      for (int i=0; i<_distr[nStringLength][dist].length; i++)
        if (_distr[nStringLength][dist][i]>0)
          sum += _distr[nStringLength][dist][i];
      for (int i=0; i<_distr[nStringLength][dist].length; i++) {
        _distrcdf[nStringLength][dist][i] = sum;
        if (_distr[nStringLength][dist][i]>0)
          sum -= _distr[nStringLength][dist][i];
      }
    }
    return _distrcdf[nStringLength][dist][index];
  }

  public TCRString getRandomStringAt(TCRString center, int dist, KnuthRandom random) {
    TCRString s = new TCRString(center.getAlphabetSize(), center.getLength());
    for (int digit=_nStringLength; digit>0; digit--) {
      int i=0;
      if (dist>0) {
        long r = random.randomInt(getDistrcdf(digit, dist,0));
      //      System.out.print(digit + ": ran="+r + "/" + getDistrcdf(digit,dist,0)+ " ");
        for (i=0; i<_distrcdf[digit][dist].length &&
               getDistrcdf(digit,dist,i)>r; i++)
          ;
        i--;
        //      System.out.print(getDistrcdf(digit,dist,i)+ " ");
        //      System.out.println(", i="+i);
        dist -= i;
        if (random.randomInt(2)==0)
          i = _nAlphabetSize-i;
      }
      s.setDigit(_nStringLength-digit,
                 (byte)((center.getDigit(_nStringLength-digit)+i)%_nAlphabetSize));
    }
    return s;
  }

  public long getNumClonesAt(int nDistance, 
			     KnuthRandom random) {
    return Probability.RandomFromPoisson(getExpectedNumClones(nDistance),
					 random);
  }

  /*
   * main - a little test program
   */
  public static void main(String[] args) {
    int nAlphabetSize = 32;
    int nStringLength = 10;
    MatchRule m = new ManhattanMatchRule(nAlphabetSize, 4, 1, 6, 1, 100);
    byte b[] = new byte[100000];
    ArrayList<TCRString> v = new ArrayList<TCRString>();
    int length = 0;
    try {
      length = System.in.read(b);
    } catch (Exception e) {
    }
    int c=0;
    while (c < length) {
      TCRString s = new TCRString(nAlphabetSize, nStringLength);
      for (int i=0; i<10; i++) {
        byte num = 0;
        while (b[c]>='0' && b[c]<='9') {
          num *= 10;
          num += b[c]-'0';
          c++;
        }
        s.setDigit(i, num);
        while (c < length && (b[c]<'0' || b[c]>'9'))
          c++;
      }
      v.add(s);
    }

    System.out.println("P2");
    System.out.println(v.size() + " " + v.size());
    System.out.println(100);

    for (int i=0; i<v.size(); i++) {
      TCRString s1 = (TCRString)v.get(i);
      //      System.out.println(s1.toString());
      for (int j=0; j<v.size(); j++) {
        TCRString s2 = (TCRString)v.get(j);
        int dist = m.getDistance(s1,s2);
        if (dist>=m.getNegativeCutoff()) {
          dist = 100;
        }
        System.out.print(dist + " ");
      }
      System.out.println();
    }

    /*
    int nAlphabetSize = 16;
    int nStringLength = 4;
    long nNumClones = (long)Math.pow(10,9);
    KnuthRandom random = new KnuthRandom();
    random.seedRandom(467773953);
    MatchRule m = new ManhattanMatchRule(nAlphabetSize, 5, 1, 5, 1, nNumClones);
    TCRString origin = new TCRString(nAlphabetSize, nStringLength);
    int setdist = 6;

    long hist[] = new long[10000];
    for (int i=0; i<hist.length; i++)
      hist[i]=0;
    int maxhist = 0;
    for (int i=0; i<10000; i++) {
      TCRString t = m.getRandomStringAt(origin, 10, random);
      int icount=0;
      for (int radius=0; radius<=setdist; radius++) {
        long numclones = m.getNumClonesAt(radius, random);
        for (int j=0; j<numclones; j++) {
          TCRString s = m.getRandomStringAt(origin, radius, random);
          if (m.getDistance(t, s)<=setdist)
            icount++;
        }
      }
      hist[icount]++;
      if (icount>maxhist)
        maxhist = icount;
    }
    for (int i=0; i<=maxhist; i++) {
      System.out.println(i + " " + hist[i]);
    }
    */
    /*    TCRString t = new TCRString(4, 6);
    ManhattanMatchRule m = null;
    //    MatchRule m = new ManhattanMatchRule(4, 6, 100);
    KnuthRandom random = new KnuthRandom();
    random.seedRandom(467773953);
    random.seedRandom(-1);
    int alphabet=7;
    m = new ManhattanMatchRule(alphabet, 2, 3, 
                               1, 10000, 100000);
    long [][][] grid = new long[alphabet][alphabet][alphabet];
    for (int i=0; i<alphabet; i++)
      for (int j=0; j<alphabet; j++)
        for (int k=0; k<alphabet; k++)
          grid[i][j][k]=0;
    TCRString center = new TCRString(alphabet,3);
    //    center.setDigit(0, (byte)3);
    //    center.setDigit(1, (byte)2);

    for (int i=0; i<12; i++) {
      long n = m.getNumClonesAt(i, random);
      System.err.println(n + " clones at radius " + i);
      for (int j=0; j<n; j++) {
        TCRString a = m.getRandomStringAt(center, i, random);
        //        System.out.println(center.toString() + " : " + a.toString());
        if (m.getDistance(center, a) != i) {
          System.err.println("Uh oh - " + i + " != " + m.getDistance(center, a));
        }
        grid[a.getDigit(0)][a.getDigit(1)][a.getDigit(2)]++;
      }
    }

    System.out.println("P2");
    System.out.println(alphabet*alphabet + " " + alphabet + " 300");
    for (int i=0; i<alphabet; i++) {
      for (int j=0; j<alphabet; j++) {
        for (int k=0; k<alphabet; k++)
          System.out.print(grid[i][j][k] + " ");
      }
      System.out.println();
    }

    //    m.printDistr();
    if (true)
      return;

    m = new ManhattanMatchRule(32, 4, 3, 
                               6, 10000, 100000000);
    m = new ManhattanMatchRule(33, 2, 3, 
                               1, 10000, 100000000);
    //    m.printDistr();
    //    TCRString center = new TCRString(32,3);
    int sum[] = new int[10];
    for (int i=0; i<10; i++)
      sum[i]=0;
    for (int i=0; i<100; i++) {
      TCRString s = m.getRandomStringAt(center, 30, random);
      if (m.getDistance(center, s)!=30)
        System.out.println("uh oh! " + s.toString());
      System.out.println(s.toString());
    }
    //    for (int j=0; j<10; j++)
    //      System.out.println(j + ": " + sum[j]);

    if (true)
      return;

    System.out.println("negative cutoff="+m.getNegativeCutoff()+
                       ";  positive="+m.getPositiveCutoff());

    for (int i=0; i<32*10/2+1; i++) {
      System.out.println(i + " " + m.getExpectedNumClones(i));
    }

    if (true)
      return;

    int dist = 4;
    for (int i=0; i<20; i++) {
      long n = m.getNumClonesAt(i, random);
      System.out.print(n + " clones at radius " + i);
      TCRString a = m.getRandomStringAt(t, i, random);
      if (m.getDistance(a, t) != i) {
	System.err.println("Uh oh - " + dist + " != " + m.getDistance(a,t));
      }
      System.out.println(a.toString());
    }
*/
  }
}
