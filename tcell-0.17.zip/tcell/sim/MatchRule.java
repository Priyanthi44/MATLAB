/*
 * MatchRule.java
 * by Dennis Chao (5/01)
 * interface for TCRString matching rules.
 * 
 * Presumably, the caller will use getNumClonesAt to find the proper
 * number of clones to generate at each distance then call 
 * getRandomStringAt to generate the strings.  
 * This will allow the caller to perform selection on each string
 * and only keep the ones that survive selection.
 */

package sim;

import lib.KnuthRandom;
import lib.Probability;

abstract public class MatchRule {
  protected int _nAlphabetSize;     // cardinality of the alphabet
  protected int _nStringLength;     // length of the strings
  protected int _nLengthMHC;        // length of MHC portion
  protected int _nNumMHC;           // number of MHC types
  protected int _nLengthPeptide;    // length of peptide portion
  protected int _nNumSelfPeptide;       // number of self peptides
  protected long _nNumClones;       // number of clones in simulation (expressed repertoire)
  private int _nPositiveCutoff, _nNegativeCutoff; // thymic selection dists

  public MatchRule(int nAlphabetSize, 
		   int nLengthMHC,
		   int nNumMHC,
		   int nLengthPeptide,
		   int nNumSelfPeptide,
		   long nNumClones) {
    _nAlphabetSize=nAlphabetSize;
    _nLengthMHC = nLengthMHC;
    _nNumMHC = nNumMHC;
    _nLengthPeptide = nLengthPeptide;
    _nNumSelfPeptide = nNumSelfPeptide;
    _nNumClones=nNumClones;
    
    _nStringLength=_nLengthMHC+_nLengthPeptide;
    computeProbabilities(false, 0);
  }

  // getMutationUnit - returns the number of digits a mutation event affects
  abstract public int getMutationUnit();

  // getDistance - returns the distance between strings a and b
  abstract public int getDistance(TCRString a, TCRString b);

  // getDistance - returns the distance between strings a and b 
  // using the first len chars only
  abstract public int getDistance(TCRString a, TCRString b, int len);

  // getMaxDistance - returns the maximum distance between strings
  abstract public int getMaxDistance();

  // getRandomStringAt - returns a random string of a given distance from center
  abstract public TCRString getRandomStringAt(TCRString center, 
				     int dist, 
				     KnuthRandom random);

  // getExpectedNumClones - returns expected number of TCRs at nDistance
  abstract public double getExpectedNumClones(int nDistance);

  // getClonesAt - returns number of TCRs that should be generated at nDistance
  abstract public long getNumClonesAt(int nDistance, 
			     KnuthRandom random);

  // getDigitMatchScores - returns distribution of match scores between digits
  abstract public double[] getDigitMatchScores();

  // getAffinity - returns the affinity between the two strings
  public double getAffinity(TCRString a, TCRString b) {
    return DistToAffinity(getDistance(a, b));
  }

  abstract public double DistToAffinity(int nDistance);

  // getNegativeCutoff - returns the negative thymic selection cutoff
  public int getNegativeCutoff() {
    return _nNegativeCutoff;
  }

  // getPositiveCutoff - returns the negative thymic selection cutoff
  public int getPositiveCutoff() {
    return _nPositiveCutoff;
  }

  /*
   * computeProbabilities - computes the positive and negative selection
   * thresholds and _p_epsilon and _p_epsilonCumulative
   * based on the computations described in
   * _Quantitative impact of MHC on T cell receptor cross-reactivity_
   * by Vincent Detours and Alan S. Perelson.
   * bPrint and stage are for printing intermediate output while debugging.
   */
  public void computeProbabilities(boolean bPrint, 
				   int stage) {
    int nNumSelf = _nNumSelfPeptide/_nNumMHC;  // number of self peptides per MHC

    int _K_n, _K_p; // affinity thresholds for negative and positive slection
    double _fF = 0.0075;  // fraction of clones that survive thymic selection
    //    _fF = 0.03; ///////////////////////////////////////////////////////// BAH
    double _fF_p = _fF/0.37;  // fraction of clones that survive positive selection
    int dmax = _nAlphabetSize-1; // largest possible digit

    if (stage!=0) {
      System.out.println("# alphabet size = " + _nAlphabetSize);
      System.out.println("# MHC types = " + _nNumMHC);
      System.out.println("# MHC length = " + _nLengthMHC);
      System.out.println("# peptide length = " + _nLengthPeptide);
      System.out.println("# TCR length = " + (_nLengthPeptide+_nLengthMHC));
      System.out.println("# self peptides per MHC = " + nNumSelf);
    }
    if (bPrint)
      System.out.println("dmax = " + dmax);

    double[] probDigit = getDigitMatchScores();

    if (bPrint) {
      System.out.println("p_I");
      for (int i=0; i<probDigit.length; i++)
	System.out.println(i + " " + probDigit[i]);
      System.out.println();
    }
    // distribution of MHC match score [eq 4]
    double[] p_gamma = Probability.NConvolve(probDigit, _nLengthMHC);
    if (bPrint) {
      System.out.println("p_gamma");
      for (int i=0; i<p_gamma.length; i++)
	System.out.println(i + " " + p_gamma[i]);
      System.out.println();
    }

    // distribution of best MHC match score
    double[] p_gammaMax = Probability.MaximumOverEvents(p_gamma, 
							_nNumMHC);

    if (bPrint) {
      System.out.println("p_gammaMax");
      for (int i=0; i<p_gammaMax.length; i++)
	System.out.println(i + " " + p_gammaMax[i]);
      System.out.println();
    }    
    // distribution of peptide match score [eq 5]
    double[] p_theta = Probability.NConvolve(probDigit, _nLengthPeptide);

    if (bPrint) {
      System.out.println("p_theta");
      for (int i=0; i<p_theta.length; i++)
	System.out.println(i + " " + p_theta[i]);
      System.out.println();
    }    

    // distribution of best peptide match score
    double[] p_thetaMax = Probability.MaximumOverEvents(p_theta, 
							nNumSelf);

    if (false) { 
      // gamma x theta
      double s = 0.0;
      double s2 = 0.0;
      for (int i=0; i<p_gammaMax.length; i++) { // mhc
        for (int j=0; j<p_thetaMax.length; j++) {  // peptide
          double a = (p_gammaMax[i] * p_thetaMax[j]);
          //          if (a>0.000000043) {
          //if (a>0.0000026) {
          if (a>0.0001) {
            System.out.println(i + " " + j);
            s2 += a;
          }
          s += a;
        }
      }
      System.out.println("sum = " + s2 + "/" + s + "=" + (s2/s));
      System.exit(0);
    }

    if (bPrint) {
      System.out.println("p_thetaMax");
      for (int i=0; i<p_thetaMax.length; i++)
	System.out.println(i + " " + p_thetaMax[i]);
      System.out.println();
    }    

    // maximal match score between random tcr and mhc-peptide complexes [eq 8]
    // note: this is for a single MHC type
    double[] p_delta = Probability.Convolve(p_gamma, p_thetaMax);
    if (bPrint) {
      System.out.println("# p_delta");
      for (int i=0; i<p_delta.length; i++)
	System.out.println(i + " " + p_delta[i]);
      System.out.println();
    }

    double[] p_deltaMax = Probability.MaximumOverEvents(p_delta, _nNumMHC);
    // best match score between random tcr and mhc-peptide complexes [eq 9]
    // note: this appears to be for all self-MHC combinations
    double[] p_omega = p_deltaMax;

    if (stage==1) { // expected distance distribution
      System.out.println("# distance between pre-selection TCR and nearest self-MHC");
      double sum = 0.0;
      for (int i=p_deltaMax.length-1; i>=0; i--) {
	System.out.println((p_deltaMax.length-i-1) + " " + 
			   p_deltaMax[i] + " " + (sum));
	sum += p_deltaMax[i];
      }
      return;
    }

    if (stage==2) { // selection window
      double sum = 0.0;
      for (int i=0; i<p_deltaMax.length; i++) {
        sum += p_deltaMax[i];
	//	System.out.println(i + " " + p_deltaMax[i] + " " + (sum));
	if (sum>0.9 && sum<0.999 && p_deltaMax[i]<0.06)
	  System.out.println(i + " dm=" + p_deltaMax[i] + " sum=" + sum + " =(1-" + (1.0-sum) + ") " + p_deltaMax[i]/(1.0-sum+p_deltaMax[i]));
	//	System.out.println(i + " " + sum);
	//	System.out.println(i + " " + p_deltaMax[i]);
      }
      System.out.println("# mhclen = " + _nLengthMHC +
			 ", num peptides = " +  nNumSelf +
			 ", length peptides = " + _nLengthPeptide);
      System.out.println("# max affinity = " + (p_deltaMax.length-1));
      return;
    }


    /*
double[] m2 = Probability.MaximumOverEvents(p_gamma, 2);
double[] m3 = Probability.MaximumOverEvents(p_gamma, 3);
for (int i=0; i<m2.length; i++)
  m2[i] = (p_gamma[i] + m2[i] + m3[i])/3.0;
double s=0.0;
for (int i=0; i<m2.length; i++)
  s += m2[i];
System.out.println("# " + s);

double[] p = Probability.Convolve(m2, p_thetaMax);
*/

    /*
pretty good
double[] m2 = Probability.MaximumOverEvents(p_theta, nNumPeptides/nNumMHC);
double[] p3 = Probability.Convolve(p_gamma, m2);
double[] p = Probability.MaximumOverEvents(p3, nNumMHC);
*/

double[] m2 = Probability.MaximumOverEvents(p_gamma, 2);
double[] m3 = Probability.MaximumOverEvents(p_gamma, 3);
double[] p2 = Probability.MaximumOverEvents(p_theta, nNumSelf/_nNumMHC);
double[] pm1 = Probability.Convolve(p_gamma, p2);
double[] pm2 = Probability.Convolve(m2, p2);
double[] pm3 = Probability.Convolve(m3, p2);
double[] pm = Probability.MaximumBetweenEvents(pm1, pm2);
double[] p = Probability.MaximumBetweenEvents(pm, pm3);

/*
double[] p2 = Probability.MaximumBetweenEvents(p3, p3);
double[] p = Probability.MaximumBetweenEvents(p3, p2);
*/

double s=0.0;
for (int i=0; i<p.length; i++)
  s += p[i];
//System.out.println("# " + s);

//double[] p = Probability.Convolve(p_gamma, p_thetaMax);

//double[] p = Probability.MaximumOverEvents(p2, nNumPeptides);

/*
      System.out.println("# p_deltaMaxMax");
      for (int i=0; i<p.length; i++)
	System.out.println(p.length-i-1 + " " + 10000*p[i]);
      System.out.println();
*/
    if (bPrint) {
      System.out.println("# p_deltaMax");
      for (int i=0; i<p_deltaMax.length; i++)
	System.out.println(p_deltaMax.length-i-1 + " " + 10000*p_deltaMax[i]);
      System.out.println();
    }

     // selection threshholds [eq 10]
    _K_p = Probability.getDistributionTailBoundary(p_omega,
				       _fF_p);
    _K_n = Probability.getDistributionIntervalUpperBoundary(p_omega,
						_fF, _K_p);
    _nNegativeCutoff = p_omega.length-_K_n-1;
    _nPositiveCutoff = p_omega.length-_K_p-1;
    if (bPrint) {
      System.out.println("# K_p = " + _K_p);
      System.out.println("# K_n = " + _K_n);
    }    

    bPrint=true;//////////////////////////////////////////////////BAH
    if (bPrint)
      System.out.print("# f: old=" + _fF);
    _fF = 0.0;
    for (int i=_K_p; i<=_K_n; i++)
      _fF += p_omega[i];
    if (bPrint)
      System.out.println(" new=" + _fF);

    if (bPrint)
      System.out.print("# f_p: old=" + _fF_p);
    _fF_p = 0.0;
    for (int i=_K_p; i<p_omega.length; i++)
      _fF_p += p_omega[i];
    if (bPrint)
      System.out.println(" new=" + _fF_p);
    bPrint=false;//////////////////////////////////////////////////BAH

    /*
      f=0.0;
      for (int i=_K_n; i<p_deltaMax.length; i++) {
      f += p_deltaMax[i];
      }
      if (bPrint)
      System.out.println("alloreactivity = " + f);
      */

    // best match score of a selected tcr over all self MHCs [eq 12]
    double[] p_phi = new double[p_gammaMax.length];
    for (int k=0; k<p_gammaMax.length; k++) {
      p_phi[k] = 0;
      for (int z=Math.max(0, _K_p-k); z<=Math.min(_K_n-k, p_thetaMax.length-1); z++)
	p_phi[k] += p_thetaMax[z];
      p_phi[k] *= p_gammaMax[k]/_fF;
    }

    if (bPrint) {
      System.out.println("p_phi");
      for (int i=0; i<p_phi.length; i++)
	System.out.println(i + " " + p_phi[i]);
      System.out.println();
    }

    // match scores of selected tcr over all MHCs [eq 13]
    double[] p_eta = new double[p_phi.length];
    for (int k=0; k<p_phi.length; k++) {
      double sum = 0;
      for (int z=0; z<Math.min(_K_p-k, p_thetaMax.length); z++)
	sum += p_thetaMax[z];
      p_eta[k] = (p_phi[k] + ((_nNumMHC-1)/(1-_fF_p))*p_gamma[k]*sum)/
	_nNumMHC;
    }

    if (bPrint) {
      System.out.println("p_eta");
      for (int i=0; i<p_eta.length; i++)
	System.out.println(i + " " + p_eta[i]);
      System.out.println();
    }

    // fraction of clones responding to a foreign peptide [eq 14]
    double _R = 0.0;
    double []et = Probability.Convolve(p_eta, p_theta);
    for (int z=_K_n+1; z<et.length; z++)
      _R += et[z];

    if (stage==3) {

      System.out.println("K_p = " + _K_p);
      System.out.println("K_n = " + _K_n);
      System.out.println("F = " + _fF);
      System.out.println("f_p = " + _fF_p);

      System.out.println("# _R = " + _R);
      System.out.println("# eta*theta");
      double sum = 0.0;
      for (int z=0; z<et.length; z++) {
	sum += et[z];
	System.out.println(z + " " + et[z] + " " + sum);
      }
    }

    if (bPrint)
      System.out.println("_R = " + _R);

    // [eq 15]
    double[] p_epsilon;  // affinity dist of MHC portion 
    p_epsilon = new double[p_eta.length];
    for (int k=0; k<p_epsilon.length; k++) {
      double sum = 0.0;
      for (int z=_K_n-k+1; z<p_theta.length; z++)
	sum += p_theta[z];
      p_epsilon[k] = sum * p_eta[k]/_R;
    }

    if (bPrint) {
      System.out.println("p_epsilon");
      for (int i=0; i<p_epsilon.length; i++)
	System.out.println(i + " " + p_epsilon[i]);
      System.out.println();
    }

    double []p_epsilonCumulative = new double[p_epsilon.length];
    p_epsilonCumulative[0] = p_epsilon[0];
    for (int k=1; k<p_epsilon.length; k++)
      p_epsilonCumulative[k] = p_epsilon[k] + p_epsilonCumulative[k-1];

    // peptide-TCR match scores for activated TCRs conditioned on m [eq 21]
    double p_mu_m[][] = new double[p_gamma.length][p_theta.length];
    for (int m=0; m<p_gamma.length; m++) {
      for (int k=0; k<p_theta.length; k++) {
	if (k+m>_K_n) {
	  double sum = 0.0;
	  for (int z=_K_n-m+1; z<p_theta.length; z++)
	    sum += p_theta[z];
	  p_mu_m[m][k] = p_theta[k] / sum;
	} else
	  p_mu_m[m][k] = 0.0;

	// make this a cumulative probability distribution
	if (k>0)
	  p_mu_m[m][k] += p_mu_m[m][k-1];
      }
    }
  }
}
