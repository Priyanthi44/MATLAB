/*
 * Uninfected.java
 *
 * @author Dennis Chao
 * @version
 * @created Jun 2002
 *
 * Uninfected represents the uninfected susceptible cells in the body.
 * The reason for this separate class is that the growth rate of the 
 * population is NOT proportional to the population size.  This keeps
 * the population from growing exponentially.  The death rate IS 
 * proportional to the population size.  The equilibrium population size
 * is the growth rate/death rate.
 */

package sim;

import lib.KnuthRandom;
import lib.Probability;

public class Uninfected extends Population {
  private TCRString[] _epitopes, _mhcs, _complexes;
  private double _fGrowthRate;

  public Uninfected(String name, 
		 long nPopulation, 
		 double fGrowthRate, 
		 double fDeathRate) {
    super(name, nPopulation, 0.0, fDeathRate);
    _fGrowthRate = fGrowthRate/Constants.TIMESTEPSPERDAY;
  }

  public TCRString getString() { return null; }

  public void clock(KnuthRandom r) {
    long numProduced = Probability.RandomFromPoisson(_fGrowthRate, r);
    super.clock(r);
    incSize(numProduced);
  }
}
