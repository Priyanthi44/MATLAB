/*
 * TCell.java
 *
 * @author Dennis Chao
 * @version
 * @created Jan 2002
 *
 * A TCell is a Population with a TCR.
 * Growth rate should be determined by the population levels of
 * Antigens with matching epitopes.
 *
 * This is now an ugly class because there are six sub-populations
 * for a T cell clone: naive, waiting to become effectors, newly-activated
 * cells that don't require stimulation, unstimulated 
 * effector, stimulated active, and memory.  Because there is so much 
 * migration between these populations, they must be closely linked.
 *
 * The T cell class looks like a single population to the external 
 * world, but it is the aggregate of the six sub-populations.
 */

package sim;

import java.lang.Double;
import java.util.*;
import lib.KnuthRandom;
import lib.Probability;
import sim.Constants;

import sim.HammingMatchRule; // for testing
import driver.Driver;        // for testing

public class TCell extends Population {
  // constants
  static private final int    _nEffectorDelayHours=19; // # hours from stimulated naive->effector
  static private final int    _nMEffectorDelayHours=1; // # hours from stimulated memory->effector
  static private final int    _nMemoryDelayHours=24*7*2;// # hours to become memory
  static private final int    _nMaxDivisions=18;       // max # divisions for an effector cell
  static private final double _fEffectorDeathRate=0.6; // effector death rate in days^-1
  static private final double _fMEffectorDeathRate=0.4;// secondary effector death rate in days^-1
  static private final double _fNaiveToEffector = 1.0; // rate naive cells become effectors in days^-1
  static private final double _fEffectorToMemory=0.02; // rate effector cells become memory
  static private final double _fMemoryToEffector=1.0;  // rate memory cells become Effector
  static private final int    _nBPhaseLength = 5;
  static private final double _fAvgCycleLength = 6.0;

  static private final double _fMemoryDeathRate=0.0; // memory death rate in days^-1
  //  static private final double _fMemoryDeathRate=0.023; // memory death rate in days^-1
  //  static private final double _fMemoryA=0.3;           // memory homeostasis constant
  //  static private final double _fMemoryB=830000;        // memory homeostasis constant
  //  static private final double _fAICDRate=2.0;          // death rate due to AICD in days^-1

  // misc agent variables
  private TCRString     _szTCR;                  // TCR string
  private ArrayList<Antigen>_antigens;               // (pointer to) list of all antigens
  private ArrayList<TCell>  _clones;                 // (pointer to) list of all T cell clones
  private MatchRule     _matchrule;
  private int           _nCrossReactivity;       // a distance, not affinity
  private double[][]    _cachedAffinities;       // stores affinities for epitopes
  private boolean       _bChronic;

  // subpopulations
  private Population    _cellsNaive;             // naive population
  private WaitingCells  _cellsEffectorDelay;     // naive cells waiting to become effectors
  private WaitingCells  _cellsMEffectorDelay;    // memory cells waiting to become effectors
  private WaitingCells  _cellsMemoryDelay;       // cells waiting to become memory
  private TCellCohort[] _cellsEffectorDivCohort; // cells that have divided n times
  private TCellCohort[] _cellsMEffectorDivCohort;// memory-derived effector cells that have divided n times
  private Population    _cellsEffectorDone;      // effector cells at the end of response
  private Population    _cellsMEffectorDone;     // memory-derived Effector cells at the end of response
  private Population    _cellsMemory;            // memory population

  // probabilities
  private double        _fEffectorToMemoryProb;

  public TCell(String name,
	       long nPopulation,
	       TCRString szTCR,
	       ArrayList<Antigen> antigens, 
	       ArrayList<TCell> clones, 
               MatchRule mr,
               boolean bChronic) {
    super(name, nPopulation, 0.0, 0.0);
    _bChronic = bChronic;
    _cellsNaive = new Population(name, nPopulation, 0.0, 0.0);
    _cellsEffectorDelay = new WaitingCells(_nEffectorDelayHours*Constants.TIMESTEPSPERHOUR, _fEffectorDeathRate);
    _cellsMEffectorDelay = new WaitingCells(_nMEffectorDelayHours*Constants.TIMESTEPSPERHOUR, _fMEffectorDeathRate);
    _cellsMemoryDelay = new WaitingCells(_nMemoryDelayHours*Constants.TIMESTEPSPERHOUR, _fMemoryDeathRate);
    _cellsEffectorDivCohort = new TCellCohort[_nMaxDivisions];
    for (int i=0; i<_cellsEffectorDivCohort.length; i++)
      _cellsEffectorDivCohort[i] = new TCellCohort(0, _fAvgCycleLength, _nBPhaseLength, _fEffectorDeathRate);
    _cellsMEffectorDivCohort = new TCellCohort[_nMaxDivisions];
    for (int i=0; i<_cellsMEffectorDivCohort.length; i++)
      _cellsMEffectorDivCohort[i] = new TCellCohort(0, _fAvgCycleLength, _nBPhaseLength, _fMEffectorDeathRate);
    _cellsEffectorDone = new Population(name, 0, 0.0, _fEffectorDeathRate);
    _cellsMEffectorDone = new Population(name, 0, 0.0, _fMEffectorDeathRate);
    _cellsMemory = new Population(name, 0, 0.0, _fMemoryDeathRate);

    _szTCR = szTCR;
    _antigens = antigens;
    _clones = clones;
    _matchrule = mr;
    _nCrossReactivity = _matchrule.getNegativeCutoff();
    _fEffectorToMemoryProb = 1.0-Math.exp(-_fEffectorToMemory/Constants.TIMESTEPSPERDAY);
    _cachedAffinities = new double[100][];
    for (int i=0; i<_cachedAffinities.length; i++) {
      _cachedAffinities[i] = new double[3];
      for (int j=0; j<_cachedAffinities[i].length; j++)
        _cachedAffinities[i][j]=-1.0;
    }
  }

  public TCRString getString() { return _szTCR; }

  // getSize - returns the total number of T cells
  public long getSize() {
    return _cellsNaive.getSize()+
      _cellsEffectorDelay.getSize()+
      _cellsMEffectorDelay.getSize()+
      _cellsMemoryDelay.getSize()+
      getSizeEffector()+
      _cellsMemory.getSize();
  }

  // getSizeNaive - returns the number of unstimulated naive T cells
  public long getSizeNaive() { return _cellsNaive.getSize(); }

  // getSizeEffector - returns the number of T cells capable of clearing infected cells
  public long getSizeEffector() {
    long s = 0;//getSizeWaiting();
    for (int i=0; i<_cellsEffectorDivCohort.length; i++)
      s += _cellsEffectorDivCohort[i].getSize();
    for (int i=0; i<_cellsMEffectorDivCohort.length; i++)
      s += _cellsMEffectorDivCohort[i].getSize();
    s += _cellsEffectorDone.getSize() + _cellsMEffectorDone.getSize();
    return s;
  }

  // getSizeMemory - returns the number of memory cells
  public long getSizeMemory() { return _cellsMemory.getSize(); }

  public void printCohorts() {
    System.out.print("{"+getSize() +"~"+ getSizeNaive()+ "+" + getSizeEffector() + "+" + getSizeMemory()+"}");
    //    for (int i=1; i<_divCohort.length; i++)
    //      System.out.print (_divCohort[i].getSize() + " ");
    System.out.println();
  }

  public double getAffinity(int nAntigen, int nEpitope) {
    Antigen a = (Antigen)_antigens.get(nAntigen);
    try {
      if (_cachedAffinities[nAntigen][nEpitope]<0.0) {
        int dist = _matchrule.getDistance(_szTCR, a.getStrings()[nEpitope]);
        if (dist<_nCrossReactivity)
          _cachedAffinities[nAntigen][nEpitope] = _matchrule.DistToAffinity(dist);
        else
          _cachedAffinities[nAntigen][nEpitope] = 0.0;
      }
      return _cachedAffinities[nAntigen][nEpitope];
    }
    catch (ArrayIndexOutOfBoundsException e) {
      if (_cachedAffinities.length<=nAntigen) {
        double[][] newAffinities = new double[_antigens.size()*2][];
        for (int k=0; k<_cachedAffinities.length; k++)
          newAffinities[k] = _cachedAffinities[k];
        for (int k=_cachedAffinities.length; k<newAffinities.length; k++) {
          newAffinities[k] = new double[3];
          for (int j=0; j<newAffinities[k].length; j++)
            newAffinities[k][j]=-1.0;
        }
        _cachedAffinities = newAffinities;
      }
      if (_cachedAffinities[nAntigen].length<a.getStrings().length) {
        double[] newAffinities = new double[a.getStrings().length];
        for (int k=0; k<_cachedAffinities[nAntigen].length; k++)
          newAffinities[k] = _cachedAffinities[nAntigen][k];
        for (int k=_cachedAffinities[nAntigen].length; k<newAffinities.length; k++)
          newAffinities[k] = -1.0;
        _cachedAffinities[nAntigen] = newAffinities;
      }

      return getAffinity(nAntigen, nEpitope);
    }
  }

  public void clock(KnuthRandom r) {
    if (getSize()>0) {
/*      // total number of effectors (for nonspecific competition)
      long totaleffectors = 0;
      for (int clonenum=0; clonenum<_clones.size(); clonenum++) {
        TCell t = (TCell)_clones.get(clonenum);
        totaleffectors += t.getSizeEffector();
        }*/
      //      if (totaleffectors>Constants.EFFECTORPOOLSIZE)
      //        fDeathMultiplier = Math.exp((totaleffectors-Constants.EFFECTORPOOLSIZE)/Constants.EFFECTORPOOLSIZE);

      //      totaleffectors = 0;
      //      EFFECTORPOOLSIZE

      // calculate stimulation
      double stimulation = 0.0;
      double overstimulation = 0.0;  // excess stimulation for AICD
      for (int antigennum=0; antigennum<_antigens.size(); antigennum++) {
	Antigen a = (Antigen)_antigens.get(antigennum);
	long anum = a.getInfectedSize();
	if (anum>0) {
	  for (int e=0; e<a.getStrings().length; e++) {
            if (getAffinity(antigennum,e)>0.0) {
	      double antigenload = anum * a.getPeptideLevels()[e];
	      stimulation += antigenload/getAffinity(antigennum,e);
              overstimulation += antigenload/(25*getAffinity(antigennum,e));
	    }
	  }
	}
      }
      stimulation = stimulation/(1.0+stimulation);
      overstimulation = overstimulation/(1.0+overstimulation);
      //      System.err.println("stim="+stimulation + "," + overstimulation + " eff="+getSizeEffector());

      // eliminate antigen
      if (stimulation>0.0 && getSizeEffector()>0) {
        for (int antigennum=0; antigennum<_antigens.size(); antigennum++) {
          Antigen a = (Antigen)_antigens.get(antigennum);
          long asize = a.getInfectedSize();
          if (asize>0) {
            double aload = 0.0;
            for (int epitopenum=0; epitopenum<a.getStrings().length; epitopenum++) {
              double affinity = getAffinity(antigennum, epitopenum);
              if (affinity>0.0) {
                double antigenload = asize * a.getPeptideLevels()[epitopenum];
                aload+=antigenload;
                //                System.out.println("ep="+epitopenum+"   inf=" + asize + "  load="+antigenload);
                // compute inter-clonal competition
                double sum=0.0;
                for (int clonenum=0; clonenum<_clones.size(); clonenum++) {
                  TCell t = (TCell)_clones.get(clonenum);
                  double affinity2 = t.getAffinity(antigennum, epitopenum);
                  if (affinity2>0.0) {
                    long tsize = t.getSizeEffector();
                    sum += tsize*((antigenload + affinity)/(antigenload + affinity2));
                  }
                }
                double expected = (Constants.CLEARANCE/Constants.TIMESTEPSPERDAY)*getSizeEffector()*aload / (affinity+aload+sum);
                long numcleared = Probability.RandomFromPoisson(expected, r);
                a.incInfectedSize(-numcleared);
              }
            }
          }
        }
      }
      
      // AICD eliminates effectors converting to memory
      if (_bChronic) {
        double aicdprob = 1.0-Math.exp(-5.0*overstimulation/Constants.TIMESTEPSPERDAY);  // for binomial
        aicdprob = 1.0-Math.exp(-1.0*stimulation/Constants.TIMESTEPSPERDAY);  // for binomial
        _cellsMemoryDelay.subtractCells(aicdprob, r);
      }

      // clocks (growth + death + advance cohort time counters)
      long tomem = _cellsMemoryDelay.clock(r);
      long toeffector = _cellsEffectorDelay.clock(r);
      long tomeffector = _cellsMEffectorDelay.clock(r);
      _cellsEffectorDivCohort[0].addCells(toeffector);
      _cellsMEffectorDivCohort[0].addCells(tomeffector);
      _cellsMemory.incSize(tomem);

      for (int i=0; i<_cellsEffectorDivCohort.length-1; i++)
	_cellsEffectorDivCohort[i+1].addCells(2*_cellsEffectorDivCohort[i].clock(r));
      _cellsEffectorDone.incSize(2*_cellsEffectorDivCohort[_cellsEffectorDivCohort.length-1].clock(r));
      _cellsEffectorDone.clock(r);

      for (int i=0; i<_cellsMEffectorDivCohort.length-1; i++)
	_cellsMEffectorDivCohort[i+1].addCells(2*_cellsMEffectorDivCohort[i].clock(r));
      _cellsMEffectorDone.incSize(2*_cellsMEffectorDivCohort[_cellsMEffectorDivCohort.length-1].clock(r));
      _cellsMEffectorDone.clock(r);

      // recruit (stimulate) naive and memory cells
      long recruit = _cellsMemory.decSize(1.0-Math.exp(-stimulation*_fMemoryToEffector/Constants.TIMESTEPSPERDAY), r);
      _cellsMEffectorDelay.addCells(recruit);
      recruit = _cellsNaive.decSize(1.0-Math.exp(-stimulation*_fNaiveToEffector/Constants.TIMESTEPSPERDAY), r);
      _cellsEffectorDelay.addCells(recruit);

      // AICD eliminates high avidity effectors
      if (_bChronic) {
        double aicdprob = 1.0-Math.exp(-5.0*overstimulation/Constants.TIMESTEPSPERDAY);  // for binomial
        for (int i=0; i<_cellsEffectorDivCohort.length; i++)
          _cellsEffectorDivCohort[i].subtractCells(aicdprob, r);
        for (int i=0; i<_cellsMEffectorDivCohort.length; i++)
          _cellsMEffectorDivCohort[i].subtractCells(aicdprob, r);

        aicdprob = 1.0-Math.exp(-1.0*stimulation/Constants.TIMESTEPSPERDAY);  // for binomial
        _cellsEffectorDone.decSize(aicdprob,r);
        _cellsMEffectorDone.decSize(aicdprob,r);
      }

      // effectors convert to memory
      tomem=0;
      for (int i=_cellsEffectorDivCohort.length-1; i>=0; i--)
	tomem += _cellsEffectorDivCohort[i].subtractCells(_fEffectorToMemoryProb, r);
      for (int i=_cellsMEffectorDivCohort.length-1; i>=0; i--)
	tomem += _cellsMEffectorDivCohort[i].subtractCells(_fEffectorToMemoryProb, r);
      tomem += _cellsEffectorDone.decSize(_fEffectorToMemoryProb, r);
      tomem += _cellsMEffectorDone.decSize(_fEffectorToMemoryProb, r);
      _cellsMemoryDelay.addCells(tomem);

      // memory pool size homeostasis
      //      long totalmemory = 0;
      //      for (int clonenum=0; clonenum<_clones.size(); clonenum++) {
      //        TCell t = (TCell)_clones.get(clonenum);
      //        totalmemory += t.getSizeMemory();
      //      }
      /*      if (totalmemory > Constants.MEMORYPOOLSIZE) {
        long kill = Probability.RandomFromBinomial(totalmemory, 
                   _cellsMemory.getSize()*(1.0-Constants.MEMORYPOOLSIZE/(double)totalmemory), r);
        _cellsMemory.incSize(-kill);
      }
      */
      //      _cellsMemory.setGrowthRate(_fMemoryA*_fMemoryB/(_fMemoryB+totalmemory));
      //      _cellsMemory.clock(r);
    }
  }

  // test program
  public static void main(String[] args) {
    KnuthRandom r = new KnuthRandom();
    r.seedRandom(-1);
    long nRandomSeed = r.getSeed();

    Uninfected uninfected;
    int nNumMHC=3;
    int nNumSelf=30000;
    int nNumAntigens=2;
    TCRString[] szMHC = new TCRString[nNumMHC];

    uninfected = new Uninfected("uninfected", (long)Math.pow(10,6), 
				Math.pow(10, 5), 0.1);
    // Hamming
    long nNumClones = (long)Math.pow(10,8);
    int nAlphabetSize = 3;
    int nMHCLength = 32;
    int nPeptideLength = 48;
    MatchRule mr = new HammingMatchRule(nAlphabetSize,
                                        nMHCLength,
                                        nNumMHC,
                                        nPeptideLength,
                                        nNumSelf,
                                        nNumClones);

    ArrayList<Antigen> antigens = new ArrayList<Antigen>();

    // make random MHC strings
    for (int i=0; i<szMHC.length; i++) {
      szMHC[i] = new TCRString(nAlphabetSize, nMHCLength);
      szMHC[i].Randomize(r);
    }

    /*    // make random self strings and assign MHC to each
    //    ArrayList self = new ArrayList();
    for (int i=0; i<nNumSelf; i++) {
      TCRString s = new TCRString(nAlphabetSize, nPeptideLength);
      s.Randomize(r);
      self.add(new SelfAntigen("Self"+i, 0, 0.0, 0.0, s, szMHC[i%szMHC.length]));
      }*/

    // LCMV
    TCRString[] ags = new TCRString[1];
    TCRString[] mhcs = new TCRString[1];
    ags[0] = new TCRString(nAlphabetSize, nPeptideLength);
    mhcs[0] = szMHC[0];
    double[] levels = new double[2];
    levels[0] = 1.0;
    levels[1] = 0.1;
    antigens.add(new Antigen("Virus", 1000, 
			     2*Math.pow(10, -7), // infection rate
			     350,              // production rate
			     5.0,              // viral decay rate
			     0.7,              // infected cell death rate
			     ags, mhcs, levels,
                             0.0,
			     uninfected,
                             (Driver)null));

    ArrayList<TCRString> tcrstrings;

    // make 1 TCR
    tcrstrings = new ArrayList<TCRString>();
    tcrstrings.add(mr.getRandomStringAt(((Antigen)antigens.get(0)).getStrings()[0],
                                        mr.getNegativeCutoff()-1,
                                        r)); 
    ArrayList<TCell> tcells = new ArrayList<TCell>();

    for (int i=0; i<tcrstrings.size(); i++) {
      tcells.add(new TCell("TCR " + i,
			   25,
			   (TCRString)(tcrstrings.get(i)),
			   antigens,
			   tcells,
			   mr,
                           false));
    }

    for (int t=0; t<Constants.TIMESTEPSPERDAY*64; t++) {
      uninfected.clock(r);
      System.out.print((t/Constants.TIMESTEPSPERDAY) + " " + uninfected.getSize() + " " );
      for (int j=0; j<antigens.size(); j++) {
        Antigen p = (Antigen)(antigens.get(j));
        System.out.print(p.getInfectedSize() + " " + p.getVirusSize() + " ");
        p.clock(r);
      }
      for (int j=0; j<tcells.size(); j++) {
        TCell p = (TCell)(tcells.get(j));
        System.out.print(p.getSize() + " " );
        System.out.print(" " + p.getSizeNaive() + " " +
                p.getSizeEffector() + " " +
                p.getSizeMemory() + " ");  
        p.clock(r);
      }
      System.out.println();
      if (t==Constants.TIMESTEPSPERDAY*28)
        ((Antigen)(antigens.get(0))).setVirusSize(5000);
    }
  }
}
