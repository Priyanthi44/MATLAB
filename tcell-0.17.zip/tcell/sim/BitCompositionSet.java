/* TCRBitCompositionSet.java */

/*
 * for xor match rule. 
 * Implements BIT_COMPOSITION_SET from Vincent Detours' _A fast algorithm 
 * for simulating T cell immune response models with realistic size 
 * repertoires_
 *
 * Note: This will only work for strings with 128 digits or fewer!
 * 
 * written by Dennis Chao (3/01)
 */

package sim;
 
import java.util.*;
import lib.*;

public class BitCompositionSet
{
  private byte[][] _bcs;          // the array of bit compositions
  private long[] _bcsNumStrings;  // the number of possible strings in each bc
  private long _nTotalNumStrings; // the total number of possible strings

  private int _nNumBits;          // actually, the number of bits-1
  private int _nNumDigits;        // number of digits per string
  private int _nRadius;           // distance of strings from origin

  /*
   * BitCompositionSet - constructor
   * I hope the arguments are self-explanatory.
   */
  BitCompositionSet(int nNumBits, 
		    int nNumDigits, 
		    int nRadius) {
    if (nNumDigits>128) {
      System.err.println("BitCompositionSet will not work with more than 128 digits.  You requested " + nNumDigits + ".");
      System.exit(-1);
    }
    BitCompositionNode _tree = new BitCompositionNode((byte)-1);
    _nNumBits = nNumBits-1;  // note that _nNumBits is # bits-1
    _nNumDigits = nNumDigits;
    _nRadius = nRadius;

    // recursively generate all bit compositions
    Vector<BitCompositionNode> leaves = new Vector<BitCompositionNode>();
    BitCompositionSetRecursion(_nNumBits, nNumDigits, nRadius, 0, 
			       _tree, leaves);

    // transfer information from tree to arrays of ints
    _bcs = new byte[leaves.size()][];
    _bcsNumStrings = new long[leaves.size()];

    int bcsindex = 0;
    _nTotalNumStrings = 0;
    for (Enumeration eleaves = leaves.elements(); 
	 eleaves.hasMoreElements(); ) {
      BitCompositionNode node = (BitCompositionNode) eleaves.nextElement();
      BitCompositionNode topnode = node;
      int n=1;
      _bcs[bcsindex] = new byte[_nNumBits+1];
      int index = 0;
      while (node.getParent()!=null) {
	_bcs[bcsindex][index++] = node.getNumber();
	n *= Combination(nNumDigits, node.getNumber());
	node = node.getParent();
      }
      _bcsNumStrings[bcsindex] = n;
      bcsindex++;
      _nTotalNumStrings += n;
    }
  }

  /* 
   * getRandomBitComposition - returns a random bit composition from the 
   * right probability distribution.
   */
  byte[] getRandomBitComposition(KnuthRandom r) {
    long randnum = r.randomInt(_nTotalNumStrings);

    for (int i=0; i<_bcs.length; i++) {
      randnum -= _bcsNumStrings[i];
      if (randnum<=0)
	return _bcs[i];
    }
    System.err.println("getRandomBitComposition - error");
    return null;
  }

  /*
   * print - prints out a bit composition set for testing purposes.
   */
  void print() {
    System.out.println("Partitions for length=" + _nNumDigits + 
		       " radius=" + _nRadius + " and bits=" + _nNumBits);
    double cdf = 0.0;

    for (int i=0; i<_bcs.length; i++) {
      cdf += (_bcsNumStrings[i]/(double)_nTotalNumStrings);
      System.out.print(_bcsNumStrings[i] + "   " + cdf + "   ");
      for (int j=0; j<=_nNumBits; j++)
	System.out.print(_bcs[i][j] + ", ");
      System.out.println();
    }
    System.out.println();
  }

  /*
   * BitCompositionSetRecursion - recursive function called by 
   * BitCompositionSet to generate all bit compositions.
   * vLeaf is used to store a vector of terminal leaves.
   */
  private void BitCompositionSetRecursion(int nNumBits, 
					  int nNumDigits, 
					  int nRadius,
					  int nDepth,   // misnamed
					  BitCompositionNode tree,
					  Vector<BitCompositionNode> vLeaf) {
    if (nNumBits==0) {
      vLeaf.addElement(tree.addChild((byte)(nRadius-nDepth)));  // add leaf
    } else {
      int bound1 = 0;
      int bound2 = 0;
      bound1 = nRadius-nDepth;
      for (int i=0; i<nNumBits; i++) {
	int temp;
	temp = nRadius/(1<<i);
	if (temp>nNumDigits)
	  temp = nNumDigits;
	bound1 -= (1<<i) * temp;
      }
      // following really should be bound1/=(1<<nNumBits), but it needs 
      // to be rounded up.
      bound1 = (bound1 + (1<<nNumBits)-1)/(1<<nNumBits);
      if (bound1<0)
	bound1=0;
      bound2 = (nRadius-nDepth)/(1<<nNumBits);
      if (bound2>nNumDigits)
	bound2 = nNumDigits;
      for (int n=bound1; n<=bound2; n++) {
	BitCompositionNode child = tree.addChild((byte)n);
	BitCompositionSetRecursion(nNumBits-1, nNumDigits, nRadius, 
				   nDepth + (1<<nNumBits)*n,
				   child, vLeaf);
      }
    }
  }

  /*
   * Combination - computes C(n,k) recursively to avoid giant factorials
   */
  int Combination(int n, int k) {
    if (k==0)
      return 1;
    if (n==k)
      return 1;
    if (k>n) {
      System.err.println("Combo error: " + n + "," + k);
      return 0; // actually, an error
    }
    return Combination(n-1, k) + Combination(n-1, k-1);
  }

  /*
   * main - a test program for BitCompositionSet
   */
  public static void main(String[] args) 
  {
    //    BitCompositionSet t = new BitCompositionSet(1,3,3);
    //BitCompositionSet t = new BitCompositionSet(2,3,4);
    KnuthRandom r = new KnuthRandom();
    r.seedRandom(-1);
    // length = l, sum to r
    BitCompositionSet t = new BitCompositionSet(8, 23, 23*255);
    t.print();
    t = new BitCompositionSet(8, 3, 1);
    t.print();
    t = new BitCompositionSet(8, 12, 9);
    t.print();
    t = new BitCompositionSet(8, 3, 3);
    t.print();

    System.out.println("Testing random bit composition for 7,12,9:");
    t = new BitCompositionSet(8, 12, 9);
    int[] hist = new int[11];
    for (int i=0; i<1000000; i++) {
      byte[] bcs = t.getRandomBitComposition(r);
      if (bcs[0]==9)
	hist[0]++;
      else if (bcs[0]==7)
	hist[1]++;
      else if (bcs[0]==5 && bcs[1]==2)
	hist[2]++;
      else if (bcs[0]==3 && bcs[1]==3)
	hist[3]++;
      else if (bcs[0]==1 && bcs[1]==4)
	hist[4]++;
      else if (bcs[0]==5 && bcs[1]==0)
	hist[5]++;
      else if (bcs[0]==3 && bcs[1]==1)
	hist[6]++;
      else if (bcs[0]==1 && bcs[1]==2)
	hist[7]++;
      else if (bcs[0]==1 && bcs[1]==0 && bcs[2]==2)
	hist[8]++;
      else if (bcs[0]==1 && bcs[1]==0 && bcs[2]==0)
	hist[9]++;
      else
	hist[10]++;
    }
    int sum = 0;
    for (int i=0; i<=10; i++) {
      sum += hist[i];
    }
    double cdf = 0.0;
    for (int i=0; i<=10; i++) {
      cdf += (hist[i]/(double)sum);
      System.out.println((hist[i]/(double)sum) + " " + cdf);
    }

    t = new BitCompositionSet(8, 8, 1782);
    t.print();
  }
};
