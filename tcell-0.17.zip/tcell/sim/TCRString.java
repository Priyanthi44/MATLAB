/*
 * TCRString.java
 * by Dennis Chao (5/01)
 * Strings for use in the T cell simulation.
 */

package sim;

import java.io.*;
import lib.KnuthRandom;

public class TCRString {
  protected int _nAlphabetSize; // number of digits in alphabet
  protected int _nLength;       // number of digits in this string
  protected byte [] _data;      // contents of the string

  public TCRString() {
  }

  public TCRString(int nAlphabetSize, int nLength) {
    _nAlphabetSize = nAlphabetSize;
    _nLength = nLength;
    _data = new byte[_nLength];
    for (int i=0; i<_nLength; i++)
      _data[i] = 0;
  }

  public TCRString(TCRString a, TCRString b) {
    _nAlphabetSize = b.getAlphabetSize();
    _nLength = a.getLength() + b.getLength();
    _data = new byte[_nLength];
    for (int i=0; i<a.getLength(); i++)
      _data[i] = a.getDigit(i);
    for (int i=0; i<b.getLength(); i++)
      _data[a.getLength()+i] = b.getDigit(i);
  }

  public String toString() {
    String s = new String();
    if (_nAlphabetSize<10) {
      for (int i=0; i<_nLength; i++)
	s += _data[i];
    } else {
      s += _data[0];
      for (int i=1; i<_nLength; i++) {
	s += "," + _data[i];
      }
    }
    return s;
  }

  public int getLength() { return _nLength; }
  public int getAlphabetSize() { return _nAlphabetSize; }

  public byte getDigit(int pos) {
    if (pos<_nLength)
      return _data[pos];
    else
      return 0;
  }

  public void setDigit(int pos, byte b) {
    if (pos<_nLength)
      _data[pos] = b;
  }

  public void Randomize(KnuthRandom r) {
    for (int i=0; i<_nLength; i++)
      _data[i] = (byte)(r.randomInt(_nAlphabetSize));
  }
}
