/*
 * HammingMatchRule.java
 * by Dennis Chao (5/01)
 * Hamming distance match rule for TCRString.
 */

package sim;

import java.util.ArrayList;
import sim.MatchRule;
import sim.TCRString;
import lib.KnuthRandom;
import lib.Probability;

public class HammingMatchRule extends MatchRule {
  public HammingMatchRule(int nAlphabetSize, 
			  int nLengthMHC,
			  int nNumMHC,
			  int nLengthPeptide,
			  int nNumPeptide,
			  long nNumClones) {
    super(nAlphabetSize, nLengthMHC, nNumMHC, nLengthPeptide, nNumPeptide, nNumClones);
  }

  // getExpectedNumClones - returns expected # of clones at given distance.
  // caching results might be better, but I don't think it's important.
  public double getExpectedNumClones(int nDistance) {
    return _nNumClones *
      Probability.Binomial(_nStringLength,
			   (_nAlphabetSize-1)/(double)_nAlphabetSize,
			   nDistance);
  }

  public int getMutationUnit() { return 8; }

  public int getMaxDistance() { return _nStringLength; }

  public int getDistance(TCRString a, TCRString b) {
    int dist = 0;
    for (int i=a.getLength()-1; i>=0; i--) {
      if (a.getDigit(i)!=b.getDigit(i)) {
	dist++;
      }
    }
    return dist;
  }

  public int getDistance(TCRString a, TCRString b, int len) {
    int dist = 0;
    for (int i=len-1; i>=0; i--) {
      if (a.getDigit(i)!=b.getDigit(i)) {
	dist++;
      }
    }
    return dist;
  }

  public double[] getDigitMatchScores() {
    double[] p = new double[2];
    p[0] = (_nAlphabetSize-1)/(double)(_nAlphabetSize);
    p[1] = 1.0 - p[0]; //1.0/(double)(_nAlphabetSize);
    return p;
  }

  public double DistToAffinity(int nDistance) {
    // this is hard-coded and will not work if parameters are changed
    double d = nDistance - 31;
    return 5000+5000*Math.exp(2.0*d);
  }

  public TCRString getRandomStringAt(TCRString center, 
				     int dist, 
				     KnuthRandom random) {
    TCRString s = new TCRString(center.getAlphabetSize(), center.getLength());

    // choose dist digits to change
    for (int i=0; i<dist; i++) {
      int r = 0;
      while (s.getDigit(r=random.randomInt(center.getLength())) == 1)
	;
      s.setDigit(r, (byte)1);
    }

    // changes chosen digits (uniform distribution)
    for (int i=0; i<s.getLength(); i++) {
      if (s.getDigit(i)==0) {
	s.setDigit(i,center.getDigit(i));
      } else {
	byte r = (byte)(random.randomInt(s.getAlphabetSize()-1));
	if (r<center.getDigit(i)) {
	  s.setDigit(i,r);
	} else {
	  s.setDigit(i,(byte)(r+1));
	}
      }
    }

    return s;
  }

  /*
   * getNumClonesAt - It is too difficult to compute the binomial term
   * suggested in Derek's dissertation.  Instead, use the Poisson 
   * approximation.
   */
  public long getNumClonesAt(int nDistance, 
			     KnuthRandom random) {
    return Probability.RandomFromPoisson(getExpectedNumClones(nDistance),
					 random);
  }

  /*
   * main - a little test program
   */
  public static void main(String[] args) {
    int nAlphabetSize = 4;
    int nStringLength = 16;
    long nNumClones = (long)Math.pow(10,6);
    KnuthRandom random = new KnuthRandom();
    random.seedRandom(467773953);
    MatchRule m = new HammingMatchRule(nAlphabetSize, 6, 3, 10, 100, nNumClones);
    TCRString origin = new TCRString(nAlphabetSize, nStringLength);

    int setdist = 6;

    long hist[] = new long[100000];
    for (int i=0; i<hist.length; i++)
      hist[i]=0;
    int maxhist = 0;
    for (int i=0; i<10000; i++) {
      TCRString t = m.getRandomStringAt(origin, 8, random);
      int icount=0;
      for (int radius=0; radius<=setdist; radius++) {
        long numclones = m.getNumClonesAt(radius, random);
        for (int j=0; j<numclones; j++) {
          TCRString s = m.getRandomStringAt(origin, radius, random);
          if (m.getDistance(t, s)<=setdist)
            icount++;
        }
      }
      hist[icount]++;
      if (icount>maxhist)
        maxhist = icount;
    }
    for (int i=0; i<=maxhist; i++) {
      System.out.println(i + " " + hist[i]);
    }

    /*
    int nAlphabetSize = 4;
    int nStringLength = 125;
    long nNumClones = (long)Math.pow(10,8);
    MatchRule m = null;
    //    MatchRule m = new HammingMatchRule(nAlphabetSize, nStringLength, nNumClones);
    TCRString t = new TCRString(nAlphabetSize, nStringLength);
    KnuthRandom random = new KnuthRandom();
    random.seedRandom(467773953);
    long sumpredict = 0;
    long sum = 0;

    // test lazy predictions
    int maxdist = nStringLength;
    if (maxdist>nStringLength)
      maxdist = nStringLength+1;

    System.out.println("# Predicted:");
    for (int i=0; i<maxdist; i++)
      System.out.println(i + " " + ((HammingMatchRule)m).getExpectedNumClones(i));

    System.out.println("# Poisson:");
    for (int i=0; i<maxdist; i++) {
	long n = m.getNumClonesAt(i, random);
	System.out.println(i + " " + n);
	sumpredict += n;
    }
    // use eager evaluation
    long []dists = new long[maxdist];
    for (int i=0; i<maxdist; i++)
      dists[i]=0;
    TCRString origin = new TCRString(nAlphabetSize, nStringLength);
    TCRString s = new TCRString(nAlphabetSize, nStringLength);
    //    System.out.println("o -> " + origin.toString());
    for (long i=0; i<nNumClones; i++) {
      s.Randomize(random);
      int d = m.getDistance(origin, s);
      if (d<maxdist)
	dists[d]++;
    }
    sum = 0;
    System.out.println("# Actual (eager):");
    for (int i=0; i<maxdist; i++) {
      System.out.println(i + " " + dists[i]);
      sum += dists[i];
    }
    System.out.println(sum + " total clones");
    */
    /*
    for (int i=0; i<8; i++) {
	long n = m.getNumClonesAt(i, random);
	System.out.println(n + " clones at radius " + i);
	sum += n;
	for (int j=0; j<n; j++) {
	  TCRString a = m.getRandomStringAt(t, i, random);
	  if (m.getDistance(a, t) != i) {
	    System.out.println("Uh oh - " + i + " != " + m.getDistance(a,t));
	  }
	}
      } 
      catch (Error e) {
	System.err.println(e.toString());
	
      }
    }
    System.out.println(sum + " total clones");
    */
  }
}
