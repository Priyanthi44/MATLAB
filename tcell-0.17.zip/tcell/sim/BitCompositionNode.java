/* BitCompositionNode */

/* for use with BitCompositionSet (xor match rule)
   The purpose of this class is to store data representing bit composition
   sets.
   Each BitCompositionNode contains its depth in the tree, its branch
   number, and a reference to its parent.
   Note that the leaves of the tree are at level 0.

   written by Dennis Chao (3/01)
 */

package sim;

public class BitCompositionNode
{
  private BitCompositionNode _pParent;
  private byte _nNumber;  // ordinal number of this branch

  public BitCompositionNode (byte nNumber) {
    _pParent = null;
    _nNumber = nNumber;
  }

  public byte getNumber() {
    return _nNumber;
  }

  public BitCompositionNode getParent() {
    return _pParent;
  }

  public BitCompositionNode addChild(byte nNumber) {
    BitCompositionNode child = new BitCompositionNode(nNumber);
    child._pParent = this;
    return child;
  }
};
