/*
 * Population.java
 *
 * @author Dennis Chao
 * @version
 * @created Jan 2002
 *
 * Generic class that has a population size and a growth rate. 
 */

package sim;

import lib.KnuthRandom;
import lib.Probability;

public class Population implements Clockable {
  protected long _nPopulation;   // population size
  protected double _fGrowthRate; // population growth rate (in days^-1)
  protected double _fGrowthProb; // probability that an individual will 
                                 // reproduce in one hour (Poisson process)
  protected double _fDeathRate;  // population death rate (in days^-1)
  protected double _fDeathProb;  // probability that an individual will 
                                 // die in one hour (Poisson process)
  private String _name;          // name of population

  private static final long _MAXPOP = Long.MAX_VALUE/2;

  public Population(String name, long nPopulation, double fGrowthRate,
		    double fDeathRate) {
    _nPopulation = nPopulation;
    setGrowthRate(fGrowthRate);
    setDeathRate(fDeathRate);
    _name = name;
  }

  public long getSize() { return _nPopulation; }
  public TCRString getString() { return null; }
  public void setGrowthRate(double d) { 
    _fGrowthRate = d;
    _fGrowthProb = Math.exp(-_fGrowthRate/Constants.TIMESTEPSPERDAY); // for negative binomial
  }
  public void setDeathRate(double d) { 
    _fDeathRate = d;
    _fDeathProb = 1.0-Math.exp(-_fDeathRate/Constants.TIMESTEPSPERDAY);  // for binomial
  }
  public double getGrowthRate() { return _fGrowthRate; }
  public double getDeathRate()  { return _fDeathRate; }
  public String getName()       { return _name; }

  public void setSize(long nNewPop) { 
    if (nNewPop<0) {
      _nPopulation = 0;
      System.err.println("ERROR in class Population: Population underflow");
    } else if (nNewPop>_MAXPOP) {
      _nPopulation = _MAXPOP;
      System.err.println("ERROR in class Population: Population overflow");
    } else
      _nPopulation = nNewPop; 
  }

  public void incSize(long nPopInc) {
    setSize(_nPopulation + nPopInc);
  }

  // decSize - kills members of the population with probability fProb
  // returns number of members killed.
  public long decSize(double fProb, KnuthRandom r) {
    long n = Probability.RandomFromBinomial(_nPopulation,
                                            fProb, r);
    _nPopulation-=n;
    return n;
  }

  // clock - advance population time step
  public void clock(KnuthRandom r) {
    if (_nPopulation>0) {
      long nReproduced;
      long nDied;
      if (_fGrowthProb>0.0)
        nReproduced = Probability.RandomFromNegativeBinomial(_nPopulation,
                                                             _fGrowthProb,
                                                             r);
      else
        nReproduced = 0;

      if (_fDeathProb>0.0)
        nDied = Probability.RandomFromBinomial(_nPopulation,
                                               _fDeathProb,
                                               r);
      else
        nDied = 0;

      incSize(nReproduced-nDied);
    }
  }

  // clock - advance population time step
  public void clock(KnuthRandom r, double fDeathMultiplier) {
    if (fDeathMultiplier==1.0) {
      clock(r);      
    } else if (_nPopulation>0) {
      double temp = getDeathRate();
      setDeathRate(temp*fDeathMultiplier);
      clock(r);
      setDeathRate(temp);
    }
  }

  // test program
  public static void main(String[] args) {
    KnuthRandom r = new KnuthRandom();
    r.seedRandom(-1);
    Population []p = new Population[20];
    int popinit = 1;
    for (int i=0; i<20; i++) {
      p[i] = new Population("test", popinit, 3.0, 0.0);
    }
    for (int j=0; j<2*Constants.TIMESTEPSPERDAY; j++) {
      System.out.print(j + " " +
		       popinit*Math.exp(3.0/Constants.TIMESTEPSPERDAY*j) + " " );
      for (int i=0; i<20; i++) {
	System.out.print(p[i].getSize() + " ");
	p[i].clock(r);
      }
      System.out.println();
    }
  }
}
