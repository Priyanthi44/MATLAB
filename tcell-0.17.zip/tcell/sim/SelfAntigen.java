/*
 * SelfAntigen.java
 *
 * @author Dennis Chao
 * @version
 * @created Jan 2002
 *
 * A SelfAntigen is a Population with one epitope.
 */

package sim;

public class SelfAntigen extends Population {
  private TCRString _szEpitope;
  private TCRString _szMHC;
  private TCRString _szComplex;

  public SelfAntigen(String name, 
		 long nPopulation, double fGrowthRate, double fDeathRate,
		 TCRString szEpitope, TCRString szMHC) {
    super(name, nPopulation, fGrowthRate, fDeathRate);
    _szEpitope = szEpitope;
    _szMHC = szMHC;
    _szComplex = new TCRString(_szEpitope, szMHC);
  }

  public TCRString getString() { return _szComplex; }
  public TCRString getPeptideString() { return _szEpitope; }
  public TCRString getMHCString() { return _szMHC; }
}
