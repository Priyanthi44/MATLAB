/*
 * TCellCohort.java
 *
 * @author Dennis Chao
 * @version
 * @created Jul 2002
 *
 * Population in which a cell must wait n hours in phase "B" before dividing.
 * Cells start in "A" phase, in which there is a constant probability of 
 * transitioning to the beginning of B phase.
 * 
 * Note that the clock function returns the number of cells that are done
 * waiting.
 */

package sim;

import lib.KnuthRandom;
import lib.Probability;

public class TCellCohort {
  private Population   _APhase;      // cells in A phase
  private WaitingCells _BPhase;      // cells in B phase

  private double       _fCycleTime;  // cell cycle time in hours
  private double       _fBPhaseProb; // per time step probability for transitioning from A to B phase
  private double       _fDeathRate;  // population death rate (in days^-1)

  public TCellCohort(long nPopulation, 
                     double fCycleTime, // in hours
                     int nDelay,        // B phase in hours
                     double fDeathRate) { // in day^-1
    _fCycleTime = fCycleTime;
    _fDeathRate = fDeathRate;
    _fBPhaseProb = 1.0-Math.exp(-1.0/((fCycleTime-nDelay)*Constants.TIMESTEPSPERHOUR));
    _APhase = new Population("", nPopulation, 0.0, _fDeathRate);
    _BPhase = new WaitingCells(nDelay*Constants.TIMESTEPSPERHOUR, _fDeathRate);
  }

  public long getSize() { 
    return _APhase.getSize() + _BPhase.getSize();
  }

  // addCells - adds cells to A phase
  public void addCells(long nPopInc) {
    if (nPopInc>0)
      _APhase.incSize(nPopInc);
  }

  // subtractCells - removes cells with probability fProb and returns # of removed cells
  public long subtractCells(double fProb, KnuthRandom r) {
    if (getSize()>0) {
      long n = Probability.RandomFromBinomial(_APhase.getSize(),
                                              fProb, r);
      _APhase.incSize(-n);
      return n+_BPhase.subtractCells(fProb,r);
    } else
      return 0;
  }

  // clock - advances population one time step
  // returns the number of cells that replicated.
  public long clock(KnuthRandom r) {
    // A phase death
    _APhase.clock(r);
    // B phase death and progression in queue.  Cells leaving B phase replicate.
    long nReproduced = _BPhase.clock(r);

    // stochastic transition from A phase to B phase
    if (_APhase.getSize()>0) {
      long n = Probability.RandomFromBinomial(_APhase.getSize(),
                                              _fBPhaseProb,
                                              r);
      if (n>0) {
        _APhase.incSize(-n);
        _BPhase.addCells(n);
      }
    }

    return nReproduced;
  }
	
  // test program
  public static void main(String[] args) {
    double cycletime = 6.0;
    int delay = 5;
    double deathrate = 0.6;
    long n0 = 10;
    int runlength=7*Constants.TIMESTEPSPERDAY;
    double ganrate = 0.0;
    KnuthRandom r = new KnuthRandom();
    r.seedRandom(-1);

    // compute r using Ganusov 2000
    for (double d=0.05; d<0.25; d+=0.00005) {
      double da = 0.6/24;  // death
      double lambda = 1/(cycletime-delay);
      double delta = 5.0;  // delay

      ganrate=(2*lambda*Math.exp(-delta*(d+da))-(lambda+da));
      if (ganrate<d)
        break;
    }

    System.out.println("# Expected growth rate: " + ganrate);
    TCellCohort []t = new TCellCohort[runlength/delay+1];
    for (int i=0; i<t.length; i++)
      t[i] = new TCellCohort(0, cycletime, delay, deathrate);
    t[0].addCells(n0);
    for (int step=0; step<runlength; step++) {
      for (int i=0; i<t.length; i++) {
        long numreproduced = t[i].clock(r);
        if (i+1<t.length)
          t[i+1].addCells(2*numreproduced);
      }
      long sum = 0;
      for (int i=0; i<t.length; i++)
        sum += t[i].getSize();
      System.out.println((step/Constants.TIMESTEPSPERDAY) + " " + 
                         sum + " " + n0*Math.exp(ganrate*step/Constants.TIMESTEPSPERHOUR));
    }
  }
}
