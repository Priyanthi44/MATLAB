/*
 * PeptideString.java
 * by Dennis Chao (5/01)
 * Strings for use in the T cell simulation.
 */

package sim;

import java.util.*;
import java.io.*;
import sim.TCRString;

public class PeptideString extends TCRString {
  TCRString _szMHC;
  TCRString _szPeptide;

  public PeptideString(int nAlphabetSize, int nLength) {
    super (nAlphabetSize, nLength);
    _data = new byte[_nLength];
    for (int i=0; i<_nLength; i++) {
      _data[i] = 0;
    }
    System.out.println(_nAlphabetSize + " " + _nLength);
  }

  /*
   * main - a little test program
   */
  public static void main(String[] args) {
    PeptideString a = new PeptideString(3,6);

  }

}
