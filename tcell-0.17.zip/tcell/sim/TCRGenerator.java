/*
 * TCRGenerator.java
 */

package sim;

import java.lang.System;
import java.util.*;
import java.io.*;
import java.math.*;

import lib.Probability;
import lib.KnuthRandom;
import driver.Driver;

public class TCRGenerator
{
  public static ArrayList lazyt(TCRString[] szMHC,
				ArrayList<SelfAntigen> self,
				ArrayList<Antigen> antigens,
				long nNumClones,
				MatchRule mr,
				KnuthRandom r) {
    ArrayList<TCRString> tcr = new ArrayList<TCRString>(); // list of T cell receptors
    int nNumMHC = szMHC.length;
    int nNumSelf = self.size();
    int nNumAntigens = antigens.size();
    int nNegative = mr.getNegativeCutoff(); // negative selection cutoff
    int nPositive = mr.getPositiveCutoff(); // positive selection cutoff
    int nLengthTCR = ((Antigen)antigens.get(0)).getString().getLength();
    int nCrossReactivity = nNegative;

    int nKilledByNegative = 0;
    int nKilledByPositive = 0;
    int nKilledByOverlap = 0;
    int nTotalGenerated = 0;
    int nSurvive = 0;

    System.out.println("# alphabet size = " + szMHC[0].getAlphabetSize());
    System.out.println("# MHC length = " + szMHC[0].getLength());
    System.out.println("# MHC types = " + nNumMHC);
    System.out.println("# TCR length = " + 
		       ((Antigen)antigens.get(0)).getString().getLength());
    System.out.println("# TCR clones = " + nNumClones);
    System.out.println("# self peptides = " + nNumSelf);
    System.out.println("# negative selection cutoff = " + nNegative);
    System.out.println("# positive selection cutoff = " + nPositive);
    System.out.println("# cross-reactive cutoff = " + nCrossReactivity);

    ArrayList<Antigen> finishedantigens = new ArrayList<Antigen>();
    for (int a=0; a<nNumAntigens; a++) {
      ArrayList<TCRString> t = addAntigen((Antigen)antigens.get(a),
                                          szMHC,
                                          self,
                                          finishedantigens,
                                          nNumClones,
                                          mr,
                                          r);
      tcr.addAll(t);
      finishedantigens.add((Antigen)antigens.get(a));
    }
    System.out.println("# total TCRs: " + tcr.size());
    return tcr;
  }

  public static ArrayList<TCRString> addAntigen(Antigen newAntigen,
                                     TCRString[] szMHC,
                                     ArrayList self,
                                     ArrayList antigens,
                                     long nNumClones,
                                     MatchRule mr,
                                     KnuthRandom r) {
    ArrayList<TCRString> tcr = new ArrayList<TCRString>(); // vector of t cell receptors
    int nNumMHC = szMHC.length;
    int nNumSelf = self.size();
    int nNumAntigens = antigens.size();
    int nNegative = mr.getNegativeCutoff(); // negative selection cutoff
    int nPositive = mr.getPositiveCutoff(); // positive selection cutoff
    int nLengthTCR = newAntigen.getString().getLength();
    int nCrossReactivity = nNegative;
    int nKilledByNegative = 0;
    int nKilledByPositive = 0;
    int nKilledByOverlap = 0;
    int nTotalGenerated = 0;
    int nSurvive = 0;

    for (int e=0; e<newAntigen.getStrings().length; e++) {
      System.out.println("# peptide-MHC " + e + " " + newAntigen.getStrings()[e]);
      // generate TCRs around this MHC-antigen pair
      for (int distance=0; distance<nCrossReactivity; distance++) {
        long nNumAtRadius = mr.getNumClonesAt(distance, r);
        for (long clone=0; clone<nNumAtRadius; clone++) {
          // generate a TCR
          TCRString t = mr.getRandomStringAt((TCRString)(newAntigen.getStrings()[e]), 
                                             distance, r);
          
          // is this within an old MHC-antigen pair?
          // if so, then throw it out.
          boolean bFound = false;
          for (int j=0; j<nNumAntigens && !bFound; j++) {
            for (int k=0; k<((Antigen)antigens.get(j)).getStrings().length; k++) {
              if (mr.getDistance(t, (TCRString)((Antigen)antigens.get(j)).getStrings()[k])<nCrossReactivity) {
                nKilledByOverlap++;
                bFound=true;
                break;
              }
            }
          }
          // check against other epitopes on new antigen
          for (int k=0; k<e; k++) {
            if (mr.getDistance(t, (TCRString)(newAntigen.getStrings()[k]))<nCrossReactivity) {
              nKilledByOverlap++;
              bFound=true;
              break;
            }
          }

          if (!bFound) {
            nTotalGenerated++;
            boolean bPositive = false;
            boolean bNegative = false;

            // subject TCR to positive and negative selection against all MHC-self pairs
            for (int nself=0; nself<nNumSelf && !bNegative; nself++) {
              int dist = mr.getDistance(t, (TCRString)((SelfAntigen)self.get(nself)).getString());
              if (dist<nNegative) {
                nKilledByNegative++;
                bNegative = true;
                break;
              } else if (dist<=nPositive) {
                bPositive = true;
              }
            }
            if (!bNegative) {
              if (!bPositive) {
                nKilledByPositive++;
              } else {
                tcr.add(t);
                nSurvive++;
              }
            }
          }
        }
      }
    }
    System.out.println("# random TCRs generated: " + nTotalGenerated);
    System.out.println("# TCRs surviving selection: " + nSurvive);
    System.out.println("# killed in positive selection: " + nKilledByPositive);
    System.out.println("# killed in negative selection: " + nKilledByNegative);
    System.out.println("# killed by overlap: " + nKilledByOverlap);
    return tcr;
  }

  public static ArrayList lazytDebug(TCRString[] szMHC,
                                     ArrayList<SelfAntigen> self,
                                     ArrayList<Antigen> antigens,
                                     long nNumClones,
                                     MatchRule mr,
                                     KnuthRandom r) {
    ArrayList<TCRString> tcr = new ArrayList<TCRString>(); // list of T cell receptors
    int nNumMHC = szMHC.length;
    int nNumSelf = self.size();
    int nNumAntigens = antigens.size();
    int nNegative = mr.getNegativeCutoff(); // negative selection cutoff
    int nPositive = mr.getPositiveCutoff(); // positive selection cutoff
    int nLengthTCR = ((Antigen)antigens.get(0)).getString().getLength();
    int nCrossReactivity = nNegative;

    int nKilledByNegative = 0;
    int nKilledByPositive = 0;
    int nKilledByOverlap = 0;
    int nTotalGenerated = 0;
    int nSurvive = 0;

    System.out.println("# alphabet size = " + szMHC[0].getAlphabetSize());
    System.out.println("# MHC length = " + szMHC[0].getLength());
    System.out.println("# MHC types = " + nNumMHC);
    System.out.println("# TCR length = " + 
		       ((Antigen)antigens.get(0)).getString().getLength());
    System.out.println("# TCR clones = " + nNumClones);
    System.out.println("# self peptides = " + nNumSelf);
    System.out.println("# negative selection cutoff = " + nNegative);
    System.out.println("# positive selection cutoff = " + nPositive);
    System.out.println("# cross-reactive cutoff = " + nCrossReactivity);

    ArrayList<Antigen> finishedantigens = new ArrayList<Antigen>();
    for (int a=0; a<nNumAntigens; a++) {
      ArrayList<TCRString> t = addAntigenDebug((Antigen)antigens.get(a),
                                               szMHC,
                                               self,
                                               finishedantigens,
                                               nNumClones,
                                               mr,
                                               r);
      tcr.addAll(t);
      finishedantigens.add((Antigen)antigens.get(a));
    }
    System.out.println("# total TCRs: " + tcr.size());
    return tcr;
  }

  public static ArrayList<TCRString> addAntigenDebug(Antigen newAntigen,
                                     TCRString[] szMHC,
                                     ArrayList self,
                                     ArrayList antigens,
                                     long nNumClones,
                                     MatchRule mr,
                                     KnuthRandom r) {
    ArrayList<TCRString> tcr = new ArrayList<TCRString>(); // vector of t cell receptors
    int nNumMHC = szMHC.length;
    int nNumSelf = self.size();
    int nNumAntigens = antigens.size();
    int nNegative = mr.getNegativeCutoff(); // negative selection cutoff
    int nPositive = mr.getPositiveCutoff(); // positive selection cutoff
    int nLengthTCR = newAntigen.getString().getLength();
    int nCrossReactivity = nNegative;
    int nKilledByNegative = 0;
    int nKilledByPositive = 0;
    int nTotalGenerated = 0;
    int nSurvive = 0;

    // Debug using only the first epitope
    ArrayList<TCRString> pos = new ArrayList<TCRString>(); // vector of t cell receptors
    ArrayList<TCRString> neg = new ArrayList<TCRString>(); // vector of t cell receptors
    int nLengthPeptide = ((SelfAntigen)self.get(0)).getPeptideString().getLength();
    for (int e=0; e<1; e++) {
      System.out.println("# peptide-MHC " + e + " " + newAntigen.getStrings()[e]);
      // generate TCRs around this MHC-antigen pair
      for (int distance=0; distance<nCrossReactivity; distance++) {
        long nNumAtRadius = mr.getNumClonesAt(distance, r);
        for (long clone=0; clone<nNumAtRadius; clone++) {
          // generate a TCR
          TCRString t = mr.getRandomStringAt((TCRString)(newAntigen.getStrings()[e]), 
                                             distance, r);
          nTotalGenerated++;
          boolean bPositive = false;
          boolean bNegative = false;
              
          int closest = 10000000;
          int closestself = 10000000;

          // subject TCR to positive and negative selection against all MHC-self pairs
          for (int nself=0; nself<nNumSelf; nself++) {
            int dist = mr.getDistance(t, (TCRString)((SelfAntigen)self.get(nself)).getString());
            //                if (bDebug & dist<closest) {
            //                  closest = dist;
            //                  closestself = dist - mr.getDistance(t, (TCRString)((SelfAntigen)self.get(nself)).getString(), nLengthPeptide);
            //                }
            if (dist<nNegative) {
              bNegative = true;
            }
            if (dist<=nPositive) {
              bPositive = true;
            }
          }
          if (!bNegative) {
            if (!bPositive) {
              pos.add(t);
              nKilledByPositive++;
            } else {
              tcr.add(t);
              nSurvive++;
            }
            //            }
            /*            } else {
                          //////////////////////////
                          int pdist = mr.getDistance(t, (TCRString)(newAntigen.getStrings()[e]), nLengthPeptide);
                          System.out.print(closest + " " + closestself + " " + distance + " " + (distance-pdist) + " ");
            */
          } else {
            nKilledByNegative++;
            neg.add(t);
          }
        }
      }
    }
    //      int pdist = mr.getDistance(t, (TCRString)(newAntigen.getStrings()[e]), nLengthPeptide);
    //      System.out.print(distance + " " + pdist + "  ");

    for (int k=0; k<pos.size(); k++) {
      TCRString t = ((TCRString)pos.get(k));
      int closest = 10000000;
      int closestself = 10000000;

      // subject TCR to positive and negative selection against all MHC-self pairs
      for (int nself=0; nself<nNumSelf; nself++) {
        int dist = mr.getDistance(t, (TCRString)((SelfAntigen)self.get(nself)).getString());
        if (dist<closest) {
          closest = dist;
          closestself = dist - mr.getDistance(t, (TCRString)((SelfAntigen)self.get(nself)).getString(), nLengthPeptide);
        }
      }
        
      int distance = mr.getDistance(t, (TCRString)(newAntigen.getStrings()[0]));
      int pdist = mr.getDistance(t, (TCRString)(newAntigen.getStrings()[0]), nLengthPeptide);
      System.out.print(closest + " " + closestself + " " + distance + " " + (distance-pdist) + " ");
    }
    System.out.println();
    for (int k=0; k<neg.size(); k++) {
      TCRString t = ((TCRString)neg.get(k));
      int closest = 10000000;
      int closestself = 10000000;

      // subject TCR to positive and negative selection against all MHC-self pairs
      for (int nself=0; nself<nNumSelf; nself++) {
        int dist = mr.getDistance(t, (TCRString)((SelfAntigen)self.get(nself)).getString());
        if (dist<closest) {
          closest = dist;
          closestself = dist - mr.getDistance(t, (TCRString)((SelfAntigen)self.get(nself)).getString(), nLengthPeptide);
        }
      }
        
      int distance = mr.getDistance(t, (TCRString)(newAntigen.getStrings()[0]));
      int pdist = mr.getDistance(t, (TCRString)(newAntigen.getStrings()[0]), nLengthPeptide);
      System.out.print(closest + " " + closestself + " " + distance + " " + (distance-pdist) + " ");
    }
    System.out.println();
    for (int k=0; k<tcr.size(); k++) {
      TCRString t = ((TCRString)tcr.get(k));
      int closest = 10000000;
      int closestself = 10000000;

      // subject TCR to positive and negative selection against all MHC-self pairs
      for (int nself=0; nself<nNumSelf; nself++) {
        int dist = mr.getDistance(t, (TCRString)((SelfAntigen)self.get(nself)).getString());
        if (dist<closest) {
          closest = dist;
          closestself = dist - mr.getDistance(t, (TCRString)((SelfAntigen)self.get(nself)).getString(), nLengthPeptide);
        }
      }
        
      int distance = mr.getDistance(t, (TCRString)(newAntigen.getStrings()[0]));
      int pdist = mr.getDistance(t, (TCRString)(newAntigen.getStrings()[0]), nLengthPeptide);
      System.out.print(closest + " " + closestself + " " + distance + " " + (distance-pdist) + " ");
    }
    System.out.println();

    System.out.println("# random TCRs generated: " + nTotalGenerated);
    System.out.println("# TCRs surviving selection: " + nSurvive);
    System.out.println("# killed in positive selection: " + nKilledByPositive);
    System.out.println("# killed in negative selection: " + nKilledByNegative);
        
    return tcr;
  }

  public static ArrayList eagert(TCRString[] szMHC, 
				 ArrayList self,
 				 long nNumClones,
				 MatchRule mr,
				 KnuthRandom r) {
    ArrayList<TCRString> tcr = new ArrayList<TCRString>(); // vector of t cell receptors
    int nNumMHC = szMHC.length;
    int nNumSelf = self.size();
    int nLengthTCR = ((SelfAntigen)(self.get(0))).getString().getLength();
    int nLengthMHC = szMHC[0].getLength();
    int nAlphabetSize = ((SelfAntigen)(self.get(0))).getString().getAlphabetSize();
    int nNegative = mr.getNegativeCutoff(); // negative selection cutoff
    int nPositive = mr.getPositiveCutoff(); // positive selection cutoff
    int nCrossReactivity = nNegative;

    /*
    System.out.println("# alphabet size = " + szMHC[0].getAlphabetSize());
    System.out.println("# MHC length = " + nLengthMHC);
    System.out.println("# TCR length = " + 
		       ((SelfAntigen)self.get(0)).getString().getLength());
    System.out.println("# num MHCs = " + nNumMHC);
    System.out.println("# TCR clones = " + nNumClones);
    System.out.println("# self peptides = " + nNumSelf);
    System.out.println("# negative selection cutoff = " + nNegative);
    System.out.println("# positive selection cutoff = " + nPositive);
    System.out.println("# cross-reactive cutoff = " + nCrossReactivity);
    */
    //    for (int i=0; i<nNumMHC; i++) {
    //      System.out.println("# MHC " + i + " " + szMHC[i].toString());
    //    }

    for (int i=0; i<nNumClones; i++) {
      TCRString t = new TCRString(nAlphabetSize, nLengthTCR);
      t.Randomize(r);
      boolean bPositive = false;
      boolean bNegative = false;
      // subject TCR to positive and negative selection against all MHC-self pairs
      for (int nself=0; nself<nNumSelf && !bNegative; nself++) {
	int dist = mr.getDistance(t, ((SelfAntigen)self.get(nself)).getString());
	if (dist<nNegative) {
	  bNegative = true;
	  break;
	} else if (dist<=nPositive) {
	  bPositive = true;
	}
      }

      if (bPositive && !bNegative) {
	tcr.add(t);
      }
    }
    return tcr;
  }

  public static ArrayList computerandom(TCRString[] szMHC, 
					ArrayList<SelfAntigen> self,
					ArrayList<Antigen> antigens,
					long nNumClones,
					MatchRule mr,
					int nCrossReactivity,
					KnuthRandom r) {
    ArrayList<TCRString> tcr = new ArrayList<TCRString>(); // vector of t cell receptors
    int nNumMHC = szMHC.length;
    int nNumSelf = self.size();
    int nNumAntigens = antigens.size();
    int nLengthTCR = ((Antigen)(antigens.get(0))).getString().getLength();
    int nLengthMHC = szMHC[0].getLength();
    int nAlphabetSize = ((Antigen)(antigens.get(0))).getString().getAlphabetSize();
    int nNegative = 36;         // negative selection cutoff
    int nPositive = 36;         // positive selection cutoff

    /*    System.out.println("# alphabet size = " + szMHC[0].getAlphabetSize());
    System.out.println("# MHC length = " + nLengthMHC);
    System.out.println("# TCR length = " + 
		       ((Antigen)antigens.get(0)).getString().getLength());
    System.out.println("# num MHCs = " + nNumMHC);
    System.out.println("# TCR clones = " + nNumClones);
    System.out.println("# antigens = " + nNumAntigens);
    System.out.println("# self peptides = " + nNumSelf);
    System.out.println("# negative selection cutoff = " + nNegative);
    System.out.println("# positive selection cutoff = " + nPositive);
    System.out.println("# cross-reactive cutoff = " + nCrossReactivity);
    */

    for (int i=0; i<nNumMHC; i++) {
      System.out.println("# MHC " + i + " " + szMHC[i].toString());
    }

    long count = 0;

    for (int i=0; i<nNumClones; i++) {
      if (i%10000 == 0)
	System.err.println(i + " clones");
      TCRString t = new TCRString(nAlphabetSize, nLengthTCR);
      t.Randomize(r);
      boolean bPositive = false;
      boolean bNegative = false;
      // subject TCR to positive and negative selection against all MHC-self pairs
      int nearest = nLengthTCR+1;
      int nearestmhc = nLengthTCR+1;
      for (int nself=0; nself<nNumSelf && !bNegative; nself++) {
	int dist = mr.getDistance(t, ((SelfAntigen)self.get(nself)).getString());
	if (dist<nearest) {
	  nearest = dist;
	  //nearestmhc = mr.getDistance(t, ((Antigen)self.get(nself)).getString(), 
	  //			    nLengthMHC);
	}
	if (dist<nNegative) {
	  bNegative = true;
	  break;
	} else if (dist<=nPositive) {
	  bPositive = true;
	}
      }

      if (bPositive && !bNegative) {
	count++;
	tcr.add(t);
      }
    }

    System.out.println("# number surviving TCRS: " + tcr.size());

    long []dists = new long[nLengthTCR+1];
    for (int i=0; i<dists.length; i++)
      dists[i]=0;

    for (int i=0; i<nNumAntigens; i++) {
      // generate TCRs around this MHC-epitope pair
      int mindist = nLengthTCR+1;
      for (int j=0; j<tcr.size(); j++) {
	int d = mr.getDistance(((Antigen)antigens.get(i)).getString(), 
			       (TCRString)tcr.get(j));
	if (d<mindist)
	  mindist = d;
      }
      dists[mindist]++;
    }

    System.out.println("# dists from random antigens to nearest TCR");
    for (int i=0; i<nLengthTCR+1; i++)
      System.out.println(i + " " + (dists[i]/(double)nNumAntigens));
    return tcr;
  }


  /*
   * main - a little test program
   */
  public static void main(String[] args) {
    int nNumMHC=3;
    int nNumSelf=30000;
    int nNumAntigens=1000;
    long nNumClones = 25*(long)Math.pow(10,7);
    KnuthRandom r = new KnuthRandom();
    r.seedRandom(-1);

    TCRString[] szMHC = new TCRString[nNumMHC];
    ArrayList<SelfAntigen> self = new ArrayList<SelfAntigen>();
    ArrayList<Antigen> antigens = new ArrayList<Antigen>();

    int matchrule=2;
    int nAlphabetSize;
    int nMHCLength;
    int nPeptideLength;
    MatchRule mr;
    if (matchrule==0) {
      nNumClones = 8*(long)Math.pow(10,7);
      nAlphabetSize = 3;
      nMHCLength = 32;
      nPeptideLength = 48;
      mr = new HammingMatchRule(nAlphabetSize,
                                nMHCLength,
                                nNumMHC,
                                nPeptideLength,
                                nNumSelf,
                                nNumClones);
    } else if (matchrule==1) {
      nNumClones = 25*(long)Math.pow(10,7);
      nAlphabetSize = 32;
      nMHCLength = 4;
      nPeptideLength = 6;
      mr = new ManhattanMatchRule(nAlphabetSize,
                                  nMHCLength,
                                  nNumMHC,
                                  nPeptideLength,
                                  nNumSelf,
                                  nNumClones);
    } else {
      nNumClones = 25*(long)Math.pow(10,7);
      nAlphabetSize = 128;
      nMHCLength = 4;
      nPeptideLength = 6;


      //      nAlphabetSize = 128; ////////////////BAH
      //      nMHCLength = 7;
      //      nPeptideLength = 5;

      mr = new XorMatchRule(nAlphabetSize,
                            nMHCLength,
                            nNumMHC,
                            nPeptideLength,
                            nNumSelf,
                            nNumClones);
    }
    
    for (int i=0; i<szMHC.length; i++) {
      szMHC[i] = new TCRString(nAlphabetSize, nMHCLength);
      szMHC[i].Randomize(r);
    }
    for (int i=0; i<nNumSelf; i++) {
      TCRString s = new TCRString(nAlphabetSize, nPeptideLength);
      s.Randomize(r);
      self.add(new SelfAntigen("Self"+i, 0, 0.0, 0.0, s, szMHC[i%szMHC.length]));
    }


    TCRString ag = new TCRString(nAlphabetSize, nPeptideLength);
    ag.Randomize(r);
    TCRString[] ags = new TCRString[1];
    ags[0] = ag;
    TCRString[] mhcs = new TCRString[1];
    mhcs[0] = szMHC[r.randomInt(szMHC.length)];

/*
    // make the antigen a self peptide
    ags[0] = (self.get(0)).getPeptideString();
    mhcs[0] = szMHC[0];
*/

    antigens.add(new Antigen("Ag", 0, 0.0, 0.0, 0.0, 0.0, ags, 
                             mhcs, (double[])null, 0.0, (Population)null,
                             (Driver)null));
    TCRString es = ((Antigen)(antigens.get(0))).getStrings()[0];
    TCRString ep = ((Antigen)(antigens.get(0))).getPeptideStrings()[0];
    int mindist = mr.getMaxDistance();
    int mindistp = mr.getMaxDistance();
    for (int i=0; i<nNumSelf; i++) {
      TCRString s = ((SelfAntigen)(self.get(i))).getString();
      int dist = mr.getDistance(s, es);
      if (dist<mindist) {
        mindist = dist;
        TCRString sp = ((SelfAntigen)(self.get(i))).getPeptideString();
        mindistp = mr.getDistance(sp, ep);
      }
    }
    ArrayList tcr = 
      TCRGenerator.lazytDebug(szMHC, self, antigens, nNumClones, mr, r);
    /*    System.out.print(mindist + " " + mindistp + " ");
    for (int i=0; i<tcr.size(); i++) {
      TCRString t = (TCRString)(tcr.get(i));
      int d = mr.getDistance(t, es);
      int d2 = mr.getDistance(t, ep, ep.getLength());
      System.out.print((d-d2) + " ");
    }
    System.out.println();
    */

    /*    
    for (int i=0; i<nNumAntigens; i++) {
      TCRString ag = new TCRString(nAlphabetSize, nPeptideLength);
      ag.Randomize(r);
      TCRString[] ags = new TCRString[1];
      ags[0] = ag;
      TCRString[] mhcs = new TCRString[1];
      mhcs[0] = szMHC[i%szMHC.length];
      antigens.add(new Antigen("Ag"+i, 0, 0.0, 0.0, 0.0, 0.0, ags, 
                               mhcs, (double[])null, 0.0, (Population)null,
                               (Driver)null));
    }
    */
    //    ArrayList tcr = 
    //      TCRGenerator.lazyt(szMHC, self, antigens, nNumClones, mr, r);

    /*    TCRString newantigen = ((Antigen)antigens.get(0)).getString();
    newantigen.setDigit(0,(byte)0);

    for (int i=0; i<tcr.size(); i++) {
      TCRString t = (TCRString)(tcr.get(i));
      int d = mr.getDistance(t, newantigen);
      if (d < mr.getNegativeCutoff()) {
        System.out.print(d + " ");
      }
    }
    System.out.println();
    */

    /*
    for (int i=0; i<tcr.size(); i++) {
      TCRString t = (TCRString)(tcr.get(i));
      int d = mr.getDistance(t, ((Antigen)antigens.get(0)).getString());
      System.out.print(d + " ");
      for (int j=0; j<t.getLength(); j++) {
        int d2 = 0;
        if (j>0)
          d2 = mr.getDistance(t, ((Antigen)antigens.get(0)).getString(), j);
        int d3 = mr.getDistance(t, ((Antigen)antigens.get(0)).getString(), j+1);
        System.out.print(d3-d2 + " ");
      }
      System.out.println();
    }
    */

    /*
    int hist[] = new int[1000];
    for (int i=0; i<hist.length; i++)
      hist[i]=0;
    int maxhist = 0;
    for (int i=0; i<tcr.size(); i++) {
      TCRString t = (TCRString)(tcr.get(i));
      int d = mr.getDistance(t, ((Antigen)antigens.get(0)).getString());
      if (d>maxhist)
        maxhist=d;
      hist[d]++;
      //      System.out.println(d + ": " + t.toString());
    }
    for (int i=0; i<=maxhist; i++)
      System.out.print(i + " " + hist[i] + " ");
    System.out.println();
    */

    /*
    ArrayList tcr = new ArrayList();
    long tcrinc = 1000000;
    for (int k=0; k<100; k++) {
      ArrayList newtcr = 
        TCRGenerator.eagert(szMHC, self, tcrinc, mr, r);
      tcr.addAll(newtcr);
      long count = 0;
      for (int i=0; i<antigens.size(); i++) {
        boolean bFound = false;
        TCRString a = ((Antigen)antigens.get(i)).getString();
        for (int j=0; j<tcr.size() && !bFound; j++) {
          TCRString t = (TCRString)(tcr.get(j));
          int d = mr.getDistance(t, a);
          if (d < mr.getNegativeCutoff()) {
            bFound=true;
            count++;
            break;
          }
        }
      }
      System.out.println(((k+1)*tcrinc) + " " + tcr.size() + " " + count);
    }
    */
    /*
    ArrayList tcr = new ArrayList();
    long tcrinc = 5000000;
    //    for (int k=0; k<nNumClones/tcrinc; k++) {
    for (int k=0; true; k++) {
      ArrayList newtcr = 
        TCRGenerator.eagert(szMHC, self, tcrinc, mr, r);
      tcr.addAll(newtcr);
      long count = 0;
      for (int i=0; i<antigens.size(); i++) {
        boolean bFound = false;
        TCRString a = ((Antigen)antigens.get(i)).getString();
int tcount = 0;
        for (int j=0; j<tcr.size(); j++) {
          TCRString t = (TCRString)(tcr.get(j));
          int d = mr.getDistance(t, a);
          if (d < mr.getNegativeCutoff()) {
            bFound=true;
            tcount++;
          }
        }
        if (tcount>=10)
count++;
      }
      System.out.println(((k+1)*tcrinc) + " " + tcr.size() + " " + count);
    }
    */
  }
}

