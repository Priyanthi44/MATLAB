/*
 * WaitingCells.java
 *
 * @author Dennis Chao
 * @version
 * @created Jan 2003
 *
 * A population of cells may need to wait for n timesteps before progressing
 * to a new state.
 * Note that the clock function returns the number of cells that are done
 * waiting.
 */

package sim;

import lib.KnuthRandom;
import lib.Probability;

public class WaitingCells {
  private double _fDeathRate;    // population death rate (in days^-1)
  private double _fDeathProb;    // probability that an individual will die in one time step (Poisson process)
  private long[] _pop;           // stores T cell subpopulations
  private long   _nCachedTotal;  // total number of cells
  private int    _nClock;        // points to "beginning" of _pop array

  public WaitingCells(int nSteps,
                      double fDeathRate) {
    _pop = new long[nSteps];
    for (int i=0; i<_pop.length; i++)
      _pop[i]=0;
    setDeathRate(fDeathRate);
    _nCachedTotal=-1;
    _nClock=0;
  }

  // setDeathRate - sets the death rate in days^-1
  public void setDeathRate(double d) { 
    _fDeathRate = d;
    _fDeathProb = 1.0-Math.exp(-d/Constants.TIMESTEPSPERDAY);  // for binomial
  }

  // getDeathRate - the death rate in days^-1
  public double getDeathRate() { 
    return _fDeathRate;
  }

  // getSize - returns total number of cells
  public long getSize() { 
    if (_nCachedTotal>=0)
      return _nCachedTotal;
    else {
      long s = 0;
      for (int i=0; i<_pop.length; i++)
        s += _pop[i];
      return s;
    }
  }

  // getSize(n) - returns number of cells in a given cohort
  public long getSize(int nCohort) { 
    return _pop[(_nClock+nCohort)%_pop.length];
  }
  /*  // getLastCohortSize - returns number of cells that are 
  public long getLastCohortSize() {
    return _pop[(_nClock+_pop.length-1)%_pop.length];
    }*/

  // addCells - adds n cells to the first cohort (longest wait)
  public void addCells(long n) {
    _pop[_nClock] += n;
    if (_nCachedTotal>0)
      _nCachedTotal += n;
    else
      _nCachedTotal = n;
  }

  // subtractCells - removes cells with probability fProb and returns number of cells removed
  public long subtractCells(double fProb, KnuthRandom r) {
    long total=0;
    if (_nCachedTotal>0) {
      for (int i=0; i<_pop.length && _nCachedTotal>0; i++) {
        long sub = Probability.RandomFromBinomial(_pop[i],
                                                  fProb, r);
        _pop[i]-=sub;
        total+=sub;
        _nCachedTotal-=sub;
      }
    }
    return total;
  }

  // clock - advances cell populations one time step
  public long clock(KnuthRandom r) {
    // Random cell death
    if (_fDeathProb>0.0) {
      for (int i=0; i<_pop.length && _nCachedTotal>0; i++) {
        if (_pop[i]>0) {
          long n = Probability.RandomFromBinomial(_pop[i],
                                                  _fDeathProb,
                                                  r);
          _pop[i] -= n;
          _nCachedTotal -= n;
        }
      }
    }

    // move cells through time steps
    int finalstage = (_nClock+_pop.length-1)%_pop.length;
    long nReady = _pop[finalstage];
    _nCachedTotal-=nReady;
    _pop[finalstage] = 0;
    _nClock = finalstage;
    return nReady;
  }
}
