/*
 * Clockable.java
 *
 * @author Dennis Chao
 * @version
 * @created Jan 2002
 *
 * Abstract class for simulation classes that can be "clocked".
 */

package sim;

import lib.KnuthRandom;

public interface Clockable {
  public void clock(KnuthRandom r);
}
