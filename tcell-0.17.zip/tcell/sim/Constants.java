/*
 * Constants.java
 *
 * @author Dennis Chao
 * @version
 * @created September 2003
 *
 * simulation constants
 * make sure that 60 is evenly divisible by TIMESTEPMINUTES.
 */

package sim;

public class Constants {
  // simulation constants
  public static final int VERSIONMAJOR = 0;                   // major revision number
  public static final int VERSIONMINOR = 17;                  // minor revision number
  public static final int TIMESTEPMINUTES = 10;                  // length of timestep in minutes
  public static final int TIMESTEPSPERHOUR = 60/TIMESTEPMINUTES; // number of timesteps in one hour
  public static final int TIMESTEPSPERDAY = 24*TIMESTEPSPERHOUR; // number of timesteps in one day

  // virus infection model constants
  public static final double DELTA_T = 0.1;    // target cell death rate (day^-1)
  public static final double LAMBDA = 100000;  // target cell production rate (cells/day)
  public static final long   T_0    = 1000000; // target cell starting population (cells)

  // T cell constants
  public static final int NUMMHC = 3;          // number of MHC types
  public static final int NUMSELF = 30000;     // number of self peptides
  public static final double CLEARANCE = 12.0; // T cell clearance rate (day^-1)
}
